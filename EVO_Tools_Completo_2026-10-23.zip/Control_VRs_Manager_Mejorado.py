from __future__ import annotations

import copy
import os
import re
import shutil
import tempfile
import traceback
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from uuid import uuid4
from zipfile import ZipFile

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, range_boundaries


ACTIVE_STATES = {"SI", "HO", "AGT"}
GROUP_TO_CARS = {"L&F": ("L", "F"), "L": ("L",), "F": ("F",), "T": ("T",)}
CAR_NAMES = {"L": "Leon", "F": "Formentor", "T": "Terramar"}
RELEASE_PATTERN = re.compile(r"^(?:VR\s*)?(\d{1,3})(?:\.0)?(?:\s+(SI|HO|AGT))?$", re.I)

# Matriz configurable: hoja -> PV -> coche -> {VR concreta: HW, "DEFAULT": HW}
HARDWARE_MATRIX = {
    "GW EVO": {
        "PV7": {
            "L": {"DEFAULT": "005 (A)"},
            "F": {"DEFAULT": "005 (A)"},
            "T": {"DEFAULT": "005 (A)"},
        },
        "PV7.1": {
            "L": {"DEFAULT": "005 (A) H08 (B)"},
            "F": {"DEFAULT": "005 (A) H08 (B)"},
            "T": {"DEFAULT": "005 (A)"},
        },
        "PV9": {
            "L": {"DEFAULT": "005 (A) H08 (B)"},
            "F": {"DEFAULT": "005 (A) H08 (B)"},
            "T": {"DEFAULT": "005 (A)"},
        },
        "PV11": {
            "L": {"DEFAULT": "005 (A)"},
            "F": {"DEFAULT": "005 (A)"},
            "T": {"DEFAULT": "005 (A)"},
        },
    },
    "BCM EVO": {
        "PV7": {
            "L": {"DEFAULT": "238 (B)"},
            "F": {"DEFAULT": "238 (B)"},
            "T": {"DEFAULT": "026 (A)"},
        },
        "PV7.1": {
            "L": {"DEFAULT": "238 (B)"},
            "F": {"DEFAULT": "238 (B)"},
            "T": {"DEFAULT": "026 (A)"},
        },
        "PV9": {
            "L": {"DEFAULT": "238 (B)"},
            "F": {"DEFAULT": "238 (B)"},
            "T": {"DEFAULT": "H26 (A)"},
        },
        "PV11": {
            "L": {24: "003/005", 28: "003/005", 38: "007", "DEFAULT": "007"},
            "F": {24: "003/005", 28: "003/005", 38: "007", "DEFAULT": "007"},
            "T": {24: "-", 28: "-", 34: "005", 38: "007", "DEFAULT": "007"},
        },
    },
}


@dataclass(frozen=True)
class VRPlan:
    car: str
    pv: str
    vr: int
    state: str
    sops: tuple[str, ...]


@dataclass
class Analysis:
    plans: list[VRPlan]
    ignored_no: int
    ignored_blank: int
    unknown_states: list[str]
    duplicates_grouped: int


def clean(value: object) -> str:
    if value is None:
        return ""
    text = str(value).replace("\xa0", " ").strip()
    return re.sub(r"[ \t]+", " ", text)


def normalize_state(value: object) -> str:
    return clean(value).upper().replace("Í", "I")


def normalize_pv(value: object) -> str:
    return clean(value).upper().replace(" ", "")


def vr_number(value: object) -> int | None:
    match = RELEASE_PATTERN.fullmatch(clean(value))
    return int(match.group(1)) if match else None


def merge_state(current: str, incoming: str) -> str:
    # Si dos SOP coinciden: Homologation tiene prioridad, despues AGT y despues SI.
    priority = {"SI": 1, "AGT": 2, "HO": 3}
    return incoming if priority.get(incoming, 0) > priority.get(current, 0) else current


def read_planning(path: str | Path) -> Analysis:
    # Se necesita acceso aleatorio a celdas: read_only seria mucho mas lento aqui.
    workbook = load_workbook(path, data_only=False)
    try:
        return analyze_planning(workbook)
    finally:
        workbook.close()


def analyze_planning(workbook) -> Analysis:
    if "VRs EVO" not in workbook.sheetnames:
        raise ValueError("No existe la hoja 'VRs EVO'.")
    ws = workbook["VRs EVO"]

    vr_columns = []
    for col in range(4, ws.max_column + 1):
        number = vr_number(ws.cell(2, col).value)
        if number is not None:
            vr_columns.append((col, number))
    if not vr_columns:
        raise ValueError("No se encontraron cabeceras VR en la fila 2 de 'VRs EVO'.")

    merged: dict[tuple[str, str, int], dict] = {}
    ignored_no = 0
    ignored_blank = 0
    unknown = set()
    active_occurrences = 0

    for row in range(3, ws.max_row + 1):
        pv = normalize_pv(ws.cell(row, 1).value)
        sop = clean(ws.cell(row, 2).value)
        group = clean(ws.cell(row, 3).value).upper().replace(" ", "")
        if not pv or group not in GROUP_TO_CARS:
            continue

        for col, number in vr_columns:
            state = normalize_state(ws.cell(row, col).value)
            if not state:
                ignored_blank += 1
                continue
            if state == "NO":
                ignored_no += 1
                continue
            if state not in ACTIVE_STATES:
                unknown.add(state)
                continue

            for car in GROUP_TO_CARS[group]:
                active_occurrences += 1
                key = (car, pv, number)
                if key not in merged:
                    merged[key] = {"state": state, "sops": set()}
                else:
                    merged[key]["state"] = merge_state(merged[key]["state"], state)
                if sop:
                    merged[key]["sops"].add(sop)

    plans = [
        VRPlan(car, pv, number, value["state"], tuple(sorted(value["sops"])))
        for (car, pv, number), value in merged.items()
    ]
    plans.sort(key=lambda plan: (-plan.vr, plan.pv, plan.car))
    return Analysis(
        plans=plans,
        ignored_no=ignored_no,
        ignored_blank=ignored_blank,
        unknown_states=sorted(unknown),
        duplicates_grouped=max(0, active_occurrences - len(plans)),
    )


def parse_release(value: object) -> tuple[int | None, str]:
    match = RELEASE_PATTERN.fullmatch(clean(value))
    if not match:
        return None, "INVALID"
    return int(match.group(1)), (match.group(2) or "SI").upper()


def release_value(number: int, state: str) -> object:
    return f"{number:02d} {state}" if state in {"HO", "AGT"} else number


def hardware_for(sheet: str, pv: str, car: str, number: int) -> str:
    config = HARDWARE_MATRIX.get(sheet, {}).get(pv, {}).get(car, {})
    return clean(config.get(number, config.get("DEFAULT", "")))


def find_existing(ws, plan: VRPlan) -> int | None:
    return index_existing(ws).get((plan.car, normalize_pv(plan.pv), plan.vr))


def index_existing(ws) -> dict[tuple[str, str, int], int]:
    """Crea un indice y detiene la operacion ante claves repetidas o VR ambiguas."""
    index = {}
    for row in range(2, ws.max_row + 1):
        car = clean(ws.cell(row, 1).value).upper()
        pv = normalize_pv(ws.cell(row, 2).value)
        if car not in CAR_NAMES or not pv.startswith("PV"):
            continue
        value = ws.cell(row, 4).value
        number, _ = parse_release(value)
        if number is None:
            raise ValueError(f"{ws.title}, fila {row}: VR no valida ({value!r}).")
        key = (car, pv, number)
        if key in index:
            raise ValueError(
                f"{ws.title}: {car} {pv} VR{number} esta duplicada "
                f"en las filas {index[key]} y {row}. Revisa el Excel."
            )
        index[key] = row
    return index


def compare(path: str | Path) -> dict:
    workbook = load_workbook(path, data_only=False)
    try:
        return compare_workbook(workbook)
    finally:
        workbook.close()


def compare_workbook(workbook) -> dict:
    analysis = analyze_planning(workbook)
    result = {"analysis": analysis, "sheets": {}, "conflicts": []}

    for sheet_name in ("GW EVO", "BCM EVO"):
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"No existe la hoja '{sheet_name}'.")
        ws = workbook[sheet_name]
        missing, existing = [], []
        existing_index = index_existing(ws)
        for plan in analysis.plans:
            row = existing_index.get((plan.car, plan.pv, plan.vr))
            if row is None:
                missing.append(plan)
            else:
                existing.append(plan)
                _, current_state = parse_release(ws.cell(row, 4).value)
                if current_state != plan.state:
                    result["conflicts"].append((sheet_name, row, plan, current_state))
        result["sheets"][sheet_name] = {"missing": missing, "existing": existing}
    return result


def copy_style(ws, source_row: int, target_row: int, max_col: int) -> None:
    ws.row_dimensions[target_row].height = ws.row_dimensions[source_row].height
    for col in range(1, max_col + 1):
        source = ws.cell(source_row, col)
        target = ws.cell(target_row, col)
        target._style = copy.copy(source._style)


def insertion_row(ws, number: int) -> int:
    last = 1
    for row in range(2, ws.max_row + 1):
        current, _ = parse_release(ws.cell(row, 4).value)
        if current is None:
            continue
        last = row
        if current < number:
            return row
    return last + 1


def nearest_style_row(ws, target_row: int, plan: VRPlan) -> int:
    best_row = None
    best_distance = 999
    for row in range(2, ws.max_row + 1):
        if row == target_row:
            continue
        if clean(ws.cell(row, 1).value).upper() != plan.car or clean(ws.cell(row, 2).value) != plan.pv:
            continue
        number, _ = parse_release(ws.cell(row, 4).value)
        if number is not None and abs(number - plan.vr) < best_distance:
            best_row = row
            best_distance = abs(number - plan.vr)
    return best_row or max(2, target_row - 1)


def refresh_filter(ws) -> None:
    if ws.auto_filter.ref:
        min_col, min_row, max_col, _ = range_boundaries(ws.auto_filter.ref)
        ws.auto_filter.ref = f"{get_column_letter(min_col)}{min_row}:{get_column_letter(max_col)}{ws.max_row}"


def insertion_risks(workbook, sheet_names: list[str]) -> list[str]:
    """Detecta estructuras que insert_rows no reajusta automaticamente."""
    risks = []
    for name in sheet_names:
        ws = workbook[name]
        affected = []
        if ws.tables:
            affected.append("tablas")
        if ws._charts or ws._images:
            affected.append("graficos/imagenes")
        if ws.merged_cells.ranges:
            affected.append("celdas combinadas")
        if ws.conditional_formatting or ws.data_validations.dataValidation:
            affected.append("formatos o validaciones por rango")
        if any(cell.data_type == "f" for cell in ws._cells.values()):
            affected.append("formulas")
        if affected:
            risks.append(f"{name}: {', '.join(affected)}")
    if workbook.defined_names:
        risks.append("El libro contiene nombres definidos que pueden referirse a filas desplazadas")
    return risks


def save_in_place(workbook, path: str | Path) -> tuple[Path, Path]:
    """Valida el nuevo libro, guarda una copia recuperable y sustituye el original."""
    target = Path(path).resolve()
    if target.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError("Solo se admiten archivos .xlsx o .xlsm.")
    fd, temporary_name = tempfile.mkstemp(prefix=f".{target.stem}_tmp_", suffix=target.suffix, dir=target.parent)
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        workbook.save(temporary)
        with ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError("El archivo Excel generado no ha superado la comprobacion ZIP.")
            if target.suffix.lower() == ".xlsm":
                with ZipFile(target) as original:
                    vba_parts = [n for n in original.namelist() if n.lower().endswith("vbaproject.bin")]
                    for name in vba_parts:
                        if name not in archive.namelist() or original.read(name) != archive.read(name):
                            raise ValueError("No se ha conservado intacto el proyecto VBA del Excel.")
        test_book = load_workbook(temporary, read_only=True, keep_vba=target.suffix.lower() == ".xlsm")
        try:
            if test_book.sheetnames != workbook.sheetnames:
                raise ValueError("Han cambiado las hojas del Excel al guardar.")
        finally:
            test_book.close()

        backup = target.with_name(
            f"{target.stem}_backup_{datetime.now():%Y%m%d_%H%M%S}_{uuid4().hex[:6]}{target.suffix}"
        )
        shutil.copy2(target, backup)
        os.replace(temporary, target)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return target, backup


def synchronize(path: str | Path, allow_risky_insertions: bool = False) -> tuple[Path, dict]:
    workbook = load_workbook(path, keep_vba=str(path).lower().endswith(".xlsm"))
    comparison = compare_workbook(workbook)
    stats = {"created": {}, "hardware_pending": [], "conflicts": comparison["conflicts"], "backup": None}

    changed_sheets = [
        name for name in ("GW EVO", "BCM EVO") if comparison["sheets"][name]["missing"]
    ]
    risks = insertion_risks(workbook, changed_sheets) if changed_sheets else []
    if risks and not allow_risky_insertions:
        raise ValueError(
            "INSERT_RISK: El Excel contiene elementos que pueden verse afectados "
            "al insertar filas:\n" + "\n".join(f"- {risk}" for risk in risks)
        )

    if not changed_sheets:
        for name in ("GW EVO", "BCM EVO"):
            stats["created"][name] = 0
        return Path(path).resolve(), stats

    for sheet_name in ("GW EVO", "BCM EVO"):
        ws = workbook[sheet_name]
        created = 0
        for plan in comparison["sheets"][sheet_name]["missing"]:
            row = insertion_row(ws, plan.vr)
            ws.insert_rows(row, 1)
            source = nearest_style_row(ws, row, plan)
            copy_style(ws, source, row, min(ws.max_column, 12))

            # Solo se rellenan los campos conocidos. PP queda vacio.
            ws.cell(row, 1).value = plan.car
            ws.cell(row, 2).value = plan.pv
            ws.cell(row, 3).value = None
            ws.cell(row, 4).value = release_value(plan.vr, plan.state)
            ws.cell(row, 5).value = None
            ws.cell(row, 6).value = None
            hw = hardware_for(sheet_name, plan.pv, plan.car, plan.vr)
            ws.cell(row, 7).value = hw or None
            for col in range(8, min(ws.max_column, 12) + 1):
                ws.cell(row, col).value = None

            if not hw:
                stats["hardware_pending"].append((sheet_name, plan))
            created += 1
        refresh_filter(ws)
        stats["created"][sheet_name] = created

    output, backup = save_in_place(workbook, path)
    stats["backup"] = backup
    return output, stats


MODEL_TO_CAR = {"Leon": "L", "Formentor": "F", "Terramar": "T"}
ECU_TO_SHEET = {"GW": "GW EVO", "BCM": "BCM EVO"}


def compose_name_version(name: str, version: str) -> str:
    name = clean(name)
    version = clean(version)
    if name and version:
        return f"{name} / {version}"
    return name or version


def assign_piece_data(
    path: str | Path,
    pv: str,
    model: str,
    vr: str,
    ecu: str,
    sw: str = "",
    zdc_name: str = "",
    zdc_version: str = "",
    swap_name: str = "",
    swap_version: str = "",
) -> tuple[Path, int, str, Path]:
    """Actualiza la fila exacta Coche + PV + VR en GW EVO o BCM EVO.

    Solo modifica los campos no vacios para no borrar informacion existente.
    En GW, nombre y version de SWAP se almacenan juntos en la columna SWAP.
    """
    pv = normalize_pv(pv)
    model = clean(model)
    ecu = clean(ecu).upper()
    number = vr_number(vr)
    if model not in MODEL_TO_CAR:
        raise ValueError("Selecciona un modelo valido.")
    if ecu not in ECU_TO_SHEET:
        raise ValueError("Selecciona GW o BCM.")
    if not pv or number is None:
        raise ValueError("PV y VR son obligatorios.")
    if not any(clean(v) for v in (sw, zdc_name, zdc_version, swap_name, swap_version)):
        raise ValueError("Introduce al menos un dato para actualizar.")
    if ecu == "BCM" and (clean(swap_name) or clean(swap_version)):
        raise ValueError("SWAP solo esta disponible para GW.")

    workbook = load_workbook(path, keep_vba=str(path).lower().endswith(".xlsm"))
    sheet_name = ECU_TO_SHEET[ecu]
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"No existe la hoja '{sheet_name}'.")
    ws = workbook[sheet_name]
    car = MODEL_TO_CAR[model]
    plan = VRPlan(car=car, pv=pv, vr=number, state="SI", sops=())
    row = index_existing(ws).get((plan.car, pv, number))
    if row is None:
        raise ValueError(
            f"No existe la combinacion {model} / {pv} / VR{number:02d} en '{sheet_name}'. "
            "Sincroniza primero el Control de VRs."
        )

    changes = 0
    values = {
        8: clean(sw),
        9: clean(zdc_name),
        10: clean(zdc_version),
    }
    if ecu == "GW":
        values[11] = compose_name_version(swap_name, swap_version)

    for col, value in values.items():
        if value and ws.cell(row, col).value != value:
            cell = ws.cell(row, col)
            cell.value = value
            cell.data_type = "s"  # No interpretar nombres de pieza como formulas
            changes += 1

    if changes == 0:
        raise ValueError("Los datos introducidos ya coinciden con los del Excel.")
    output, backup = save_in_place(workbook, path)
    return output, row, sheet_name, backup


class ControlVRsApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Control de VRs EVO")
        self.geometry("1100x820")
        self.minsize(980, 700)
        self.excel_path = tk.StringVar()
        self.assign_pv = tk.StringVar(value="PV9")
        self.assign_model = tk.StringVar(value="Formentor")
        self.assign_vr = tk.StringVar(value="42")
        self.assign_ecu = tk.StringVar(value="GW")
        self.assign_sw = tk.StringVar()
        self.assign_zdc = tk.StringVar()
        self.assign_zdc_version = tk.StringVar()
        self.assign_swap = tk.StringVar()
        self.assign_swap_version = tk.StringVar()
        self.status = tk.StringVar(value="Selecciona Control VRs.xlsx y analiza la planificacion.")
        self.build_ui()

    def build_ui(self):
        root = ttk.Frame(self, padding=14)
        root.pack(fill="both", expand=True)

        file_frame = ttk.LabelFrame(root, text="Archivo", padding=10)
        file_frame.pack(fill="x")
        ttk.Label(file_frame, text="Control de VRs:").grid(row=0, column=0, sticky="w")
        ttk.Entry(file_frame, textvariable=self.excel_path).grid(row=0, column=1, padx=8, sticky="ew")
        ttk.Button(file_frame, text="Seleccionar...", command=self.choose_file).grid(row=0, column=2)
        file_frame.columnconfigure(1, weight=1)

        actions = ttk.Frame(root)
        actions.pack(fill="x", pady=10)
        ttk.Button(actions, text="Analizar planificacion", command=self.analyze).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Sincronizar GW EVO y BCM EVO", command=self.sync).pack(side="left")
        ttk.Label(actions, text="El Excel seleccionado se modifica directamente.", foreground="#9a4d00").pack(side="right")

        assign = ttk.LabelFrame(root, text="Asignar SW, ZDC y SWAP a una VR", padding=10)
        assign.pack(fill="x", pady=(0, 10))

        ttk.Label(assign, text="PV:").grid(row=0, column=0, sticky="w")
        ttk.Entry(assign, textvariable=self.assign_pv, width=9).grid(row=0, column=1, padx=(5, 12), sticky="w")
        ttk.Label(assign, text="Modelo:").grid(row=0, column=2, sticky="w")
        ttk.Combobox(assign, textvariable=self.assign_model, values=list(MODEL_TO_CAR), state="readonly", width=13).grid(row=0, column=3, padx=(5, 12), sticky="w")
        ttk.Label(assign, text="VR:").grid(row=0, column=4, sticky="w")
        ttk.Entry(assign, textvariable=self.assign_vr, width=7).grid(row=0, column=5, padx=(5, 12), sticky="w")
        ttk.Label(assign, text="Pieza:").grid(row=0, column=6, sticky="w")
        ecu_box = ttk.Combobox(assign, textvariable=self.assign_ecu, values=list(ECU_TO_SHEET), state="readonly", width=8)
        ecu_box.grid(row=0, column=7, padx=(5, 12), sticky="w")
        ecu_box.bind("<<ComboboxSelected>>", lambda _event: self.update_swap_state())

        ttk.Label(assign, text="SW:").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(assign, textvariable=self.assign_sw, width=20).grid(row=1, column=1, columnspan=2, padx=(5, 12), pady=(8, 0), sticky="ew")
        ttk.Label(assign, text="ZDC:").grid(row=1, column=3, sticky="w", pady=(8, 0))
        ttk.Entry(assign, textvariable=self.assign_zdc, width=18).grid(row=1, column=4, columnspan=2, padx=(5, 12), pady=(8, 0), sticky="ew")
        ttk.Label(assign, text="Version ZDC:").grid(row=1, column=6, sticky="w", pady=(8, 0))
        ttk.Entry(assign, textvariable=self.assign_zdc_version, width=10).grid(row=1, column=7, padx=(5, 12), pady=(8, 0), sticky="w")

        ttk.Label(assign, text="SWAP:").grid(row=2, column=0, sticky="w", pady=(8, 0))
        self.swap_entry = ttk.Entry(assign, textvariable=self.assign_swap, width=20)
        self.swap_entry.grid(row=2, column=1, columnspan=2, padx=(5, 12), pady=(8, 0), sticky="ew")
        ttk.Label(assign, text="Version SWAP:").grid(row=2, column=3, sticky="w", pady=(8, 0))
        self.swap_version_entry = ttk.Entry(assign, textvariable=self.assign_swap_version, width=12)
        self.swap_version_entry.grid(row=2, column=4, padx=(5, 12), pady=(8, 0), sticky="w")
        ttk.Button(assign, text="Asignar datos", command=self.assign_data).grid(row=2, column=7, padx=(5, 12), pady=(8, 0), sticky="e")
        ttk.Label(assign, text="Los campos vacios no borran datos existentes. SWAP solo se aplica a GW.").grid(row=3, column=0, columnspan=8, pady=(8, 0), sticky="w")
        assign.columnconfigure(1, weight=1)
        assign.columnconfigure(4, weight=1)

        info = ttk.LabelFrame(root, text="Resultados", padding=8)
        info.pack(fill="both", expand=True)
        self.preview = tk.Text(info, wrap="word", font=("Consolas", 10))
        scroll = ttk.Scrollbar(info, orient="vertical", command=self.preview.yview)
        self.preview.configure(yscrollcommand=scroll.set)
        self.preview.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        ttk.Label(root, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x", pady=(10, 0))

    def update_swap_state(self):
        state = "normal" if self.assign_ecu.get() == "GW" else "disabled"
        self.swap_entry.configure(state=state)
        self.swap_version_entry.configure(state=state)
        if state == "disabled":
            self.assign_swap.set("")
            self.assign_swap_version.set("")

    def assign_data(self):
        try:
            if not self.excel_path.get():
                raise ValueError("Selecciona primero el Excel.")
            output, row, sheet, backup = assign_piece_data(
                self.excel_path.get(),
                self.assign_pv.get(),
                self.assign_model.get(),
                self.assign_vr.get(),
                self.assign_ecu.get(),
                self.assign_sw.get(),
                self.assign_zdc.get(),
                self.assign_zdc_version.get(),
                self.assign_swap.get(),
                self.assign_swap_version.get(),
            )
            text = (
                "DATOS ASIGNADOS\n\n"
                f"Hoja: {sheet}\n"
                f"Fila: {row}\n"
                f"PV: {self.assign_pv.get()}\n"
                f"Modelo: {self.assign_model.get()}\n"
                f"VR: {self.assign_vr.get()}\n"
                f"Pieza: {self.assign_ecu.get()}\n\n"
                f"Excel modificado directamente:\n{output}\n\n"
                f"Copia de seguridad:\n{backup}"
            )
            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", text)
            self.status.set(f"Datos asignados en {sheet}, fila {row}.")
            messagebox.showinfo("Datos asignados", f"Informacion actualizada en {sheet}, fila {row}.")
        except PermissionError:
            messagebox.showerror("Excel abierto", "Cierra el Excel en Microsoft Excel y vuelve a intentarlo.")
        except Exception as exc:
            self.show_error(exc)

    def choose_file(self):
        path = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xlsm"), ("Todos", "*.*")])
        if path:
            self.excel_path.set(path)

    def analyze(self):
        try:
            if not self.excel_path.get():
                raise ValueError("Selecciona primero el Excel.")
            result = compare(self.excel_path.get())
            analysis = result["analysis"]
            state_counts = {state: sum(1 for p in analysis.plans if p.state == state) for state in ACTIVE_STATES}
            lines = [
                f"Planificaciones tecnicas unicas: {len(analysis.plans)}",
                f"SI: {state_counts['SI']} | HO: {state_counts['HO']} | AGT: {state_counts['AGT']}",
                f"Duplicados agrupados por SOP: {analysis.duplicates_grouped}",
                f"NO ignorados: {analysis.ignored_no}",
                f"Estados desconocidos: {', '.join(analysis.unknown_states) if analysis.unknown_states else 'Ninguno'}",
                "",
            ]
            total_missing = 0
            for sheet_name in ("GW EVO", "BCM EVO"):
                data = result["sheets"][sheet_name]
                total_missing += len(data["missing"])
                lines.append(f"{sheet_name}: {len(data['existing'])} existentes | {len(data['missing'])} pendientes")
                for plan in data["missing"]:
                    hw = hardware_for(sheet_name, plan.pv, plan.car, plan.vr) or "HW PENDIENTE"
                    lines.append(f"  + {plan.car} {CAR_NAMES[plan.car]:9} | {plan.pv:5} | VR{plan.vr:02d} {plan.state:3} | {hw}")
                lines.append("")

            if result["conflicts"]:
                lines.append("DISCREPANCIAS DE ESTADO (se conservan para revision manual):")
                for sheet, row, plan, current in result["conflicts"]:
                    lines.append(f"  ! {sheet} fila {row}: {plan.car} {plan.pv} VR{plan.vr:02d}; VRs EVO={plan.state}, detalle={current}")

            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", "\n".join(lines))
            self.status.set(f"Analisis completado. Filas pendientes: {total_missing}")
        except Exception as exc:
            self.show_error(exc)

    def sync(self):
        try:
            if not self.excel_path.get():
                raise ValueError("Selecciona primero el Excel.")
            if not messagebox.askyesno("Sincronizar", "Se modificara directamente el Excel seleccionado. ¿Continuar?"):
                return
            try:
                output, stats = synchronize(self.excel_path.get())
            except ValueError as exc:
                if not str(exc).startswith("INSERT_RISK:"):
                    raise
                if not messagebox.askyesno(
                    "Elementos complejos en Excel",
                    f"{str(exc).removeprefix('INSERT_RISK:').strip()}\n\n"
                    "openpyxl no actualiza todas las dependencias al insertar filas. "
                    "Se creara una copia de seguridad. ¿Quieres continuar asumiendo "
                    "que deberas comprobar formulas, tablas y referencias despues?",
                ):
                    return
                output, stats = synchronize(self.excel_path.get(), allow_risky_insertions=True)
            lines = [
                "SINCRONIZACION COMPLETADA",
                "",
                f"GW EVO:  {stats['created']['GW EVO']} filas creadas",
                f"BCM EVO: {stats['created']['BCM EVO']} filas creadas",
                f"Hardware pendiente: {len(stats['hardware_pending'])}",
                f"Discrepancias conservadas: {len(stats['conflicts'])}",
                "",
                f"Excel modificado directamente:\n{output}",
            ]
            if stats["backup"]:
                lines.append(f"\nCopia de seguridad:\n{stats['backup']}")
            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", "\n".join(lines))
            self.status.set("Sincronizacion completada.")
            messagebox.showinfo("Control de VRs", "GW EVO y BCM EVO se han sincronizado.")
        except PermissionError:
            messagebox.showerror("Excel abierto", "Cierra el Excel en Microsoft Excel y vuelve a intentarlo.")
        except Exception as exc:
            self.show_error(exc)

    def show_error(self, exc: Exception):
        self.status.set(f"Error: {exc}")
        messagebox.showerror("Error", f"{exc}\n\n{traceback.format_exc(limit=3)}")


if __name__ == "__main__":
    ControlVRsApp().mainloop()
