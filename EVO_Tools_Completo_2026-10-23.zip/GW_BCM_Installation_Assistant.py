"""GW / BCM Installation Assistant 0.3.8 — versión integrada en EVO Tools.

Un solo módulo con los modelos, lectores ODIS, matrices, validador,
planificador, monitor y panel Tkinter. Las matrices se incluyen en el .py.
La preparación de ODIS nunca pulsa Starts flashing.
"""
from __future__ import annotations

import ctypes
import html
import json
import os
import queue
import re
import sys
import threading
import time
import traceback
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from html.parser import HTMLParser
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Any

APP_NAME = "GW / BCM Installation Assistant"
APP_VERSION = "0.3.9-evo"
CHANGELOG = [
    ("0.2.x", "Reports ODIS, matrices GW/BCM, selección de software y detección de ODIS Engineering."),
    ("0.3.0", "Arquitectura compactada y soporte para report extendido."),
    ("0.3.2", "Aislamiento de datos por dirección ECU para evitar mezclar GW y BCM."),
    ("0.3.3", "Ruta PV9 P181 a R181 y changelog de primera ejecución."),
    ("0.3.6", "Motor de preparación ODIS hasta PRE-FLASH."),
    ("0.3.8", "Calibración de Diagnostic Entry y detección del selector de archivos."),
    ("0.3.8-evo", "Integración con EVO Tools: panel único Tkinter, validaciones más conservadoras y matrices incorporadas."),
    (APP_VERSION, "El changelog deja de abrirse automáticamente y se consulta desde el botón inferior derecho de EVO Tools."),
]

@dataclass(slots=True)
class ECUInfo:
    address: str
    name: str
    description: str = ""
    part_number: str = ""
    sw: str = "-"
    hw: str = "-"
    vendor: str = "UNKNOWN"

@dataclass(slots=True)
class VehicleContext:
    vin: str = "-"
    report_path: str = ""
    ecus: dict[str, ECUInfo] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    @property
    def gw(self): return self.ecus.get("0019")
    @property
    def bcm(self): return self.ecus.get("0009")

@dataclass(slots=True)
class ExtendedECUProfile:
    address: str
    name: str = ""
    application: str = ""
    fbl: str = ""
    hsm_bl: str = ""
    hsm_fw: str = ""
    marvell: list[str] = field(default_factory=list)
    modules: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

@dataclass(slots=True)
class ExtendedReport:
    vin: str = "-"
    profiles: dict[str, ExtendedECUProfile] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

class ComponentType(str, Enum):
    APPLICATION = "APPLICATION"
    FBL = "FBL"
    FBL_INTERMEDIATE = "FBL_INTERMEDIATE"
    HSM_BOOTLOADER = "HSM_BOOTLOADER"
    HSM_FIRMWARE = "HSM_FIRMWARE"
    MARVELL = "MARVELL"
    UNKNOWN = "UNKNOWN"

class ValidationState(str, Enum):
    VALID = "VALID"
    WARNING = "WARNING"
    BLOCKED = "BLOCKED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"

@dataclass(slots=True)
class SoftwareArtifact:
    path: str
    file_name: str
    extension: str
    part_number: str = ""
    software_version: str = ""
    component_type: ComponentType = ComponentType.UNKNOWN
    environment: str = "UNKNOWN"
    variant: str = ""
    container_version: str = ""
    suffix: str = ""
    ecu_hint: str = "UNKNOWN"

@dataclass(slots=True)
class TransitionPreview:
    ecu: str
    current_sw: str
    target_sw: str
    status: str
    documented: bool
    rule_id: str = ""
    message: str = ""
    requirements: list[dict[str, Any]] = field(default_factory=list)
    artifacts: dict[str, str] = field(default_factory=dict)
    source: dict[str, Any] = field(default_factory=dict)

@dataclass(slots=True)
class SoftwareSelection:
    ecu: str
    current_sw: str
    target_sw: str
    transition: TransitionPreview
    artifact: SoftwareArtifact | None = None
    state: ValidationState = ValidationState.REVIEW_REQUIRED
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

@dataclass(slots=True)
class PlanStep:
    order: int
    action: str
    title: str
    component: str = ""
    current: str = ""
    target: str = ""
    blocking: bool = False
    notes: str = ""

@dataclass(slots=True)
class InstallationPlan:
    ecu: str
    current_sw: str
    target_sw: str
    status: str
    rationale: str
    preconditions: list[str] = field(default_factory=list)
    steps: list[PlanStep] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

class _Visible(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip = 0
    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.skip += 1
        elif not self.skip and tag in ("p", "div", "tr", "td", "th", "br", "li"):
            self.parts.append("\n")
    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.skip:
            self.skip -= 1
        elif not self.skip and tag in ("p", "div", "tr", "td", "th", "li"):
            self.parts.append("\n")
    def handle_data(self, data):
        if not self.skip and data.strip():
            self.parts.append(data.strip())

def visible_text(path: str | Path) -> str:
    path = Path(path)
    if not path.is_file() or path.stat().st_size > 30_000_000:
        raise ValueError("El report no existe o supera el límite de 30 MB")
    raw = path.read_bytes()
    text = None
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            pass
    parser = _Visible()
    parser.feed(text if text is not None else raw.decode("utf-8", errors="replace"))
    return re.sub(r"\n{2,}", "\n", html.unescape("\n".join(parser.parts)).replace("\xa0", " "))

VIN_PATTERN = re.compile(r"\b[A-HJ-NPR-Z0-9]{17}\b", re.I)

class ODISReportParser:
    HEADER = re.compile(r"(?m)^ECU:\s*([0-9A-F]{4})\s*-\s*([^\n]+)", re.I)
    def parse(self, path: str | Path) -> VehicleContext:
        text = visible_text(path)
        vin = VIN_PATTERN.search(text)
        ctx = VehicleContext(vin.group(0) if vin else "-", str(Path(path).resolve()))
        hits = list(self.HEADER.finditer(text))
        for index, hit in enumerate(hits):
            block = text[hit.start():hits[index + 1].start() if index + 1 < len(hits) else len(text)]
            address = hit.group(1).upper()
            info = self._ecu(address, hit.group(2).strip(), block)
            if address not in ctx.ecus or (ctx.ecus[address].sw == "-" and info.sw != "-"):
                ctx.ecus[address] = info
        if not ctx.ecus:
            ctx.warnings.append("No se encontraron bloques ECU reales.")
        if ctx.gw is None and ctx.bcm is None:
            ctx.warnings.append("El report no contiene 0019 Gateway ni 0009 BCM.")
        return ctx
    @staticmethod
    def _ecu(address, name, block):
        def val(label):
            match = re.search(rf"(?mi)^{re.escape(label)}\s*$\n\s*([^\n]+)", block)
            return match.group(1).strip() if match else "-"
        part = val("VW/Audi part number")
        if part == "-":
            part = val("Part number")
        upper = block.upper()
        vendor = "AUMOVIO" if ("AUMOVIO" in upper or "CONTINENTAL" in upper) else "BOSCH" if "BOSCH" in upper else "UNKNOWN"
        return ECUInfo(address, name, f"{address} - {name}", part, val("Software version"), val("Hardware version"), vendor)

class ExtendedReportParser:
    HEADER = ODISReportParser.HEADER
    VERSION = re.compile(r"^(?:[A-Z]?[0-9]{3,4}|----)$")
    def parse(self, path: str | Path) -> ExtendedReport:
        text = visible_text(path)
        vin = VIN_PATTERN.search(text)
        result = ExtendedReport(vin.group(0) if vin else "-")
        hits = list(self.HEADER.finditer(text))
        for index, hit in enumerate(hits):
            block = text[hit.start():hits[index + 1].start() if index + 1 < len(hits) else len(text)]
            if "Versions of software module" not in block:
                continue
            section = block[block.find("Versions of software module"):]
            end = section.find("AUTOSAR Standard application software identification")
            section = section[:end if end > 0 else 7000]
            lines = [line.strip() for line in section.splitlines() if line.strip()]
            fbl, apps = "", []
            for j, line in enumerate(lines[:-1]):
                if line == "Bootloader" and self.VERSION.match(lines[j + 1]):
                    fbl = lines[j + 1]
                if line == "Application" and self.VERSION.match(lines[j + 1]):
                    apps.append(lines[j + 1])
            app = apps[0] if apps else ""
            values = [x for x in apps if x not in ("----", app)]
            counts = Counter(values)
            address = hit.group(1).upper()
            result.profiles[address] = ExtendedECUProfile(
                address, hit.group(2).strip(), app, fbl,
                next((x for x in values if x in ("0016", "0100")), ""),
                next((x for x in values if x in ("1924", "1933")), ""),
                sorted(x for x in counts if x in ("4004", "4005", "5001")), apps,
            )
        if not result.profiles:
            result.warnings.append("No se encontraron bloques F1AB.")
        return result

# Datos de origen incrustados al generar este módulo: no hacen falta JSON externos.
GW_MATRIX = json.loads('{\n  "schema_version": "2.1",\n  "matrix_name": "GW Update Matrix ODIS Aumovio - MY24/MY48 integrated",\n  "ecu": "0019",\n  "ecu_name": "Gateway",\n  "source_workbook": "GW_Update_Matrix_ODIS_Aumovio.xlsx",\n  "policy": {\n    "same_version_result": "SAME",\n    "unknown_transition_result": "REVIEW_REQUIRED",\n    "block_unknown_transition": true,\n    "explicit_rules_override_automatic_rules": true,\n    "numeric_same_family": {\n      "enabled": true,\n      "comparison": "integer",\n      "higher_result": "UPGRADE",\n      "lower_result": "DOWNGRADE",\n      "same_result": "SAME",\n      "message_upgrade": "Incremento de SW dentro de la misma familia numerica.",\n      "message_downgrade": "SW anterior detectada dentro de la misma familia numerica."\n    }\n  },\n  "rules": [\n    {\n      "id": "MY24_2027_TO_2181",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY24-2027 IS13 "\n      },\n      "from": [\n        "A110",\n        "C110",\n        "EA10",\n        "E110",\n        "G110",\n        "H110",\n        "J110"\n      ],\n      "to": [\n        "N180",\n        "P180",\n        "Q180",\n        "R180",\n        "T180",\n        "U180",\n        "V180",\n        "X180",\n        "Y180",\n        "N181",\n        "P181"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "requirements": {\n        "bootloader": true,\n        "fbl_update": true,\n        "target_fbl": "0014",\n        "hsm_update": false,\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1933",\n        "target_marvell_fw": [\n          "5001"\n        ]\n      },\n      "message": "Upgrade valido. Requiere actualizacion del BootLoader/FBL a 0014."\n    },\n    {\n      "id": "MY40_2028_STAGE_1",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY40-2028 IS14"\n      },\n      "from": [\n        "A110",\n        "C110",\n        "EA10",\n        "E110",\n        "G110"\n      ],\n      "to": [\n        "N220"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "target_fbl": "0013",\n        "hsm_update": false,\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1933",\n        "target_marvell_fw": [\n          "4006"\n        ]\n      },\n      "message": "Upgrade valido hacia N220 sin actualizacion de FBL."\n    },\n    {\n      "id": "MY40_2028_TO_2220",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY40-2028 IS14"\n      },\n      "from": [\n        "N220"\n      ],\n      "to": [\n        "P220",\n        "Q220"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "SAME_BRANCH",\n      "requirements": {\n        "bootloader": true,\n        "fbl_update": true,\n        "target_fbl": "0014",\n        "hsm_update": true,\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1937",\n        "target_marvell_fw": [\n          "6002"\n        ]\n      },\n      "message": "Upgrade valido. Requiere actualizacion del BootLoader/FBL y HSM."\n    },\n    {\n      "id": "MY24_2026_R06_009_TO_A100",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY24-2026 IS12",\n        "row": 6\n      },\n      "from": [\n        "W093",\n        "X093",\n        "C094",\n        "E094"\n      ],\n      "to": [\n        "A100",\n        "B100"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "SAME_BRANCH",\n      "from_components": {\n        "fbl": "0009",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "3005"\n        ]\n      },\n      "to_components": {\n        "fbl": "0009",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4000"\n        ]\n      },\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": true,\n        "target_fbl": "0009",\n        "target_hsm_bl": "0016",\n        "target_hsm_fw": "1924",\n        "target_marvell_fw": [\n          "4000"\n        ]\n      },\n      "artifacts": {\n        "application_pdx": "FL_5QS907530H_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido a la rama A100/B100; actualiza Marvell FW a 4000."\n    },\n    {\n      "id": "MY24_2026_R08_A100_TO_2101",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY24-2026 IS12",\n        "row": 8\n      },\n      "from": [\n        "A100",\n        "B100"\n      ],\n      "to": [\n        "C101",\n        "E101",\n        "G101",\n        "H101",\n        "J101",\n        "L101",\n        "2101",\n        "B102",\n        "C102",\n        "E102",\n        "G102",\n        "J102",\n        "K102"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "from_components": {\n        "fbl": "0009",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4000"\n        ]\n      },\n      "to_components": {\n        "fbl": "0011",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4000",\n          "4001",\n          "4002"\n        ]\n      },\n      "requirements": {\n        "bootloader": true,\n        "fbl_update": true,\n        "hsm_update": false,\n        "marvell_update": true,\n        "target_fbl": "0011",\n        "target_hsm_bl": "0016",\n        "target_hsm_fw": "1924",\n        "target_marvell_fw": [\n          "4000",\n          "4001",\n          "4002"\n        ]\n      },\n      "artifacts": {\n        "fbl_pdx": "FL_5QS907530F_0011_FBLUPDATERDEV_V001_E.pdx",\n        "application_pdx": "FL_5QS907530H_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido; requiere actualizacion FBL a 0011."\n    },\n    {\n      "id": "MY24_2026_R10_2101_TO_L102",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY24-2026 IS12",\n        "row": 10\n      },\n      "from": [\n        "C101",\n        "E101",\n        "G101",\n        "H101",\n        "J101",\n        "L101",\n        "2101",\n        "B102",\n        "C102",\n        "E102",\n        "G102",\n        "J102",\n        "K102"\n      ],\n      "to": [\n        "L102",\n        "N102",\n        "P102",\n        "R102",\n        "T102",\n        "U102",\n        "V102"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "from_components": {\n        "fbl": "0011",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4000",\n          "4001",\n          "4002"\n        ]\n      },\n      "to_components": {\n        "fbl": "0012",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4002",\n          "4003"\n        ]\n      },\n      "requirements": {\n        "bootloader": true,\n        "fbl_update": true,\n        "hsm_update": false,\n        "marvell_update": true,\n        "target_fbl": "0012",\n        "target_hsm_bl": "0016",\n        "target_hsm_fw": "1924",\n        "target_marvell_fw": [\n          "4002",\n          "4003"\n        ]\n      },\n      "artifacts": {\n        "fbl_pdx": "FL_5QS907530H_0012_FBLUPDATERDEV_V001_E.pdx",\n        "application_pdx": "FL_5QS907530H_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido; requiere actualizacion FBL a 0012."\n    },\n    {\n      "id": "MY24_2026_R12_L102_TO_W102",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY24-2026 IS12",\n        "row": 12\n      },\n      "from": [\n        "L102",\n        "N102",\n        "P102",\n        "R102",\n        "T102",\n        "U102",\n        "V102"\n      ],\n      "to": [\n        "W102"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "SAME_BRANCH",\n      "from_components": {\n        "fbl": "0012",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4002",\n          "4003"\n        ]\n      },\n      "to_components": {\n        "fbl": "0013",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4004"\n        ]\n      },\n      "requirements": {\n        "bootloader": true,\n        "fbl_update": true,\n        "hsm_update": false,\n        "marvell_update": true,\n        "target_fbl": "0013",\n        "target_hsm_bl": "0016",\n        "target_hsm_fw": "1924",\n        "target_marvell_fw": [\n          "4004"\n        ]\n      },\n      "artifacts": {\n        "fbl_pdx": "FL_5QS907530H_0013_FBLUPDATERDEV_V001_E.pdx",\n        "application_pdx": "FL_5QS907530H_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido; requiere actualizacion FBL a 0013."\n    },\n    {\n      "id": "MY24_2026_R14_W102_TO_2105",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY24-2026 IS12",\n        "row": 14\n      },\n      "from": [\n        "W102"\n      ],\n      "to": [\n        "X102",\n        "Y102",\n        "Z102",\n        "A103",\n        "C103",\n        "E103",\n        "G103",\n        "H103",\n        "J103",\n        "K103",\n        "L103",\n        "2103",\n        "A104",\n        "B104",\n        "C104",\n        "2104",\n        "A105",\n        "B105",\n        "2105"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "from_components": {\n        "fbl": "0013",\n        "hsm_bl": "0016",\n        "hsm_fw": "1924",\n        "marvell_fw": [\n          "4004"\n        ]\n      },\n      "to_components": {\n        "fbl": "0013",\n        "hsm_bl": "0100",\n        "hsm_fw": "1933",\n        "marvell_fw": [\n          "4004",\n          "4005"\n        ]\n      },\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": true,\n        "marvell_update": true,\n        "target_fbl": "0013",\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1933",\n        "target_marvell_fw": [\n          "4004",\n          "4005"\n        ]\n      },\n      "artifacts": {\n        "hsm_bl_pdx": "FL_5QS907530H_0100_HSMBLUDEV_V001_E.pdx",\n        "application_pdx": "FL_5QS907530H_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido; requiere actualizacion HSM BL a 0100 y HSM FW a 1933."\n    },\n    {\n      "id": "MY48_2026_R06_A110_TO_N140",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY48-2026 IS12.PV71",\n        "row": 6\n      },\n      "from": [\n        "A110",\n        "C110",\n        "EA10",\n        "E110",\n        "G110",\n        "H110",\n        "J110"\n      ],\n      "to": [\n        "N140",\n        "P140"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "from_components": {\n        "fbl": "0013",\n        "hsm_bl": "0100",\n        "hsm_fw": "1933",\n        "marvell_fw": [\n          "4005"\n        ]\n      },\n      "to_components": {\n        "fbl": "0013",\n        "hsm_bl": "0100",\n        "hsm_fw": "1933",\n        "marvell_fw": [\n          "4005"\n        ]\n      },\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": false,\n        "target_fbl": "0013",\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1933",\n        "target_marvell_fw": [\n          "4005"\n        ]\n      },\n      "artifacts": {\n        "application_pdx": "FL_5QS907530H_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido hacia N140/P140 sin cambio de FBL ni HSM."\n    },\n    {\n      "id": "MY48_2026_R08_N140_TO_2142",\n      "enabled": true,\n      "source": {\n        "type": "workbook",\n        "sheet": "MY48-2026 IS12.PV71",\n        "row": 8\n      },\n      "from": [\n        "N140",\n        "P140"\n      ],\n      "to": [\n        "R140",\n        "2140",\n        "N141",\n        "2141",\n        "N142",\n        "2142"\n      ],\n      "result": "UPGRADE",\n      "transition_type": "FAMILY_CHANGE",\n      "from_components": {\n        "fbl": "0013",\n        "hsm_bl": "0100",\n        "hsm_fw": "1933",\n        "marvell_fw": [\n          "4005"\n        ]\n      },\n      "to_components": {\n        "fbl": "0013",\n        "hsm_bl": "0100",\n        "hsm_fw": "1933",\n        "marvell_fw": [\n          "5001"\n        ]\n      },\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": true,\n        "target_fbl": "0013",\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1933",\n        "target_marvell_fw": [\n          "5001"\n        ]\n      },\n      "artifacts": {\n        "application_pdx": "FL_5QS907530M_xxxx_HMCDEV_V001.pdx"\n      },\n      "message": "Upgrade valido hacia la rama 214x; actualiza Marvell FW a 5001."\n    }\n  ],\n  "manual_overrides": [\n    {\n      "id": "MANUAL_C181_TO_P181",\n      "enabled": true,\n      "source": {\n        "type": "manual",\n        "confirmed_by": "project_criteria"\n      },\n      "from": "C181",\n      "to": "P181",\n      "result": "UPGRADE",\n      "transition_type": "SAME_BRANCH",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false\n      },\n      "message": "Upgrade valido confirmado por criterio de proyecto."\n    },\n    {\n      "id": "MANUAL_P181_TO_0181",\n      "enabled": true,\n      "source": {\n        "type": "manual",\n        "confirmed_by": "project_criteria"\n      },\n      "from": "P181",\n      "to": "0181",\n      "result": "UPGRADE",\n      "transition_type": "SAME_BRANCH",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false\n      },\n      "message": "Upgrade valido confirmado por criterio de proyecto."\n    },\n    {\n      "id": "MANUAL_GW_Q180_TO_N181_20261016143608",\n      "enabled": true,\n      "source": {\n        "type": "manual",\n        "vehicle": "El Enchufado",\n        "vin": "VSSPVSKM1VR000022",\n        "validated_at": "2026-10-16T14:36:08"\n      },\n      "from": "Q180",\n      "to": "N181",\n      "result": "UPGRADE",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": false\n      },\n      "allow_excel_update": true,\n      "message": "UPGRADE GW confirmado manualmente."\n    },\n    {\n      "id": "MANUAL_GW_N181_TO_Q180_20261016144836",\n      "enabled": true,\n      "source": {\n        "type": "manual",\n        "vehicle": "El Enchufado",\n        "vin": "VSSPVSKM1VR000022",\n        "validated_at": "2026-10-16T14:48:36"\n      },\n      "from": "N181",\n      "to": "Q180",\n      "result": "DOWNGRADE",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": false\n      },\n      "allow_excel_update": true,\n      "message": "DOWNGRADE GW confirmado manualmente."\n    },\n    {\n      "id": "MANUAL_P181_TO_R181",\n      "enabled": true,\n      "from": "P181",\n      "to": "R181",\n      "result": "UPGRADE",\n      "requirements": {\n        "target_fbl": "0014",\n        "target_hsm_bl": "0100",\n        "target_hsm_fw": "1933",\n        "target_marvell_fw": [\n          "5001"\n        ]\n      },\n      "message": "Upgrade PV9 P181 a R181 documentado; sin cambio de FBL, HSM ni Marvell."\n    }\n  ],\n  "review_workflow": {\n    "status": "REVIEW_REQUIRED",\n    "table_label": "Revisar manualmente",\n    "block_excel_update": true,\n    "allow_manual_decision": true,\n    "allowed_manual_results": [\n      "UPGRADE",\n      "DOWNGRADE",\n      "VALID_WITH_BOOTLOADER",\n      "VALID_WITH_FBL",\n      "VALID_WITH_HSM",\n      "KEEP_PENDING"\n    ],\n    "manual_decisions_target": "manual_overrides"\n  }\n}')
BCM_MATRIX = json.loads('{\n  "schema_version": "1.0",\n  "ecu": "BCM MQB Evo Continental 37w Baseline",\n  "source": {\n    "file": "BCM_Update_Matrix_ODIS_Aumovio.pptx",\n    "matrix_date": "2026-08-19",\n    "scope": "ODIS flash update paths, application SW, Bootloader/FBL, HSM and intermediate software dependencies"\n  },\n  "identifier_readout": {\n    "bootloader_and_hsm_identifier": "0xF1AB"\n  },\n  "global_rules": {\n    "optional_steps": {\n      "green_arrows": "Steps may be skipped or are equivalent, subject to target compatibility.",\n      "latest_dependency_preferred": true,\n      "dependency_types": [\n        "BOOTLOADER",\n        "FBL",\n        "HSM",\n        "INTERMEDIATE_SW"\n      ]\n    },\n    "first_x6xx_to_x7xx_bootloader_transition": {\n      "required": true,\n      "sequence": [\n        "FBLUINT",\n        "FBLU"\n      ],\n      "subsequent_transitions": [\n        "FBLU"\n      ]\n    },\n    "fds_affected_bcm": {\n      "applies_to": [\n        "BCM delivered before PV4",\n        "PV4 BCM produced before 2024-02-01"\n      ],\n      "issue": "Incorrect FDS identifier prevents writing Bootloader dataset 0x7100 (MDK).",\n      "required_sequence": [\n        "X709",\n        "0709",\n        "TARGET_BOOTLOADER_OR_SW"\n      ],\n      "possible_symptoms": [\n        "Digital vehicle key cluster message",\n        "DTC: implausible dataset"\n      ]\n    },\n    "mdk_initialization": {\n      "condition": "Vehicle equipped with MDK",\n      "intermediate_software": "M345",\n      "install_once_per_bcm": true,\n      "wait_after_flash_seconds": 60,\n      "then_flash_target_software": true\n    },\n    "hsm_0016": {\n      "aliases": [\n        "16",\n        "0016",\n        "1.0.16"\n      ],\n      "install_once_per_bcm": true,\n      "severity_if_repeated": "CRITICAL",\n      "risk": "BCM may be damaged or rendered unusable"\n    },\n    "hsm_0100": {\n      "aliases": [\n        "100",\n        "0100"\n      ],\n      "requires_installed": "0016",\n      "install_once_per_bcm": true,\n      "severity_if_repeated": "CRITICAL",\n      "risk": "BCM may be damaged or rendered unusable"\n    }\n  },\n  "container_naming_from_sw_0365": {\n    "production_hardware": "H26",\n    "development_hardware": "H25",\n    "production": {\n      "fbl": "FL_5WA937084AN_0365_FBLU0711PRD_V001_S.odx",\n      "fbl_intermediate": "FL_5WA937084AN_0365_FBLUINT0711PRD_V001_S.odx",\n      "hsm_bootloader": "FL_5WA937084AN_0365_HSMBL0016PRD_V001_S.odx",\n      "application": "FL_5WA937084AN_0365_APPPRD_V001_S.odx"\n    },\n    "development": {\n      "fbl": "FL_5WA937084AN_0365_FBLU0711DEV_V001_E.odx",\n      "fbl_intermediate": "FL_5WA937084AN_0365_FBLUINT0711DEV_V001_E.odx",\n      "hsm_bootloader": "FL_5WA937084AN_0365_HSMBL0016DEV_V001_E.odx",\n      "application": "FL_5WA937084AN_0365_APPDEV_V001_E.odx"\n    },\n    "validation_rule": "Do not mix PRD/DEV container variants or incompatible suffix types."\n  },\n  "known_component_versions": {\n    "bootloaders": [\n      "X602",\n      "X604",\n      "X702",\n      "X703",\n      "X705",\n      "X706",\n      "X709",\n      "0709",\n      "6710",\n      "0711"\n    ],\n    "hsm": [\n      "1.0.08",\n      "1.0.09",\n      "1.0.12",\n      "1.0.15",\n      "1.0.16",\n      "0100"\n    ],\n    "intermediate_software": [\n      "M246",\n      "M345"\n    ]\n  },\n  "application_families": {\n    "PV2_PV3": {\n      "applications_observed": [\n        "0240",\n        "X242",\n        "0244",\n        "0246",\n        "0247",\n        "0248",\n        "0260",\n        "0261",\n        "0262",\n        "0263",\n        "0280",\n        "U282",\n        "2X82",\n        "X282",\n        "0283",\n        "0289",\n        "1290"\n      ],\n      "bootloaders_observed": [\n        "X602",\n        "X604"\n      ],\n      "hsm_observed": [\n        "1.0.08",\n        "1.0.09",\n        "1.0.12"\n      ],\n      "notes": [\n        "M246 may be required for distance/kilometre initialization in the indicated path."\n      ]\n    },\n    "PV4": {\n      "applications_observed": [\n        "Y300",\n        "0304",\n        "C306",\n        "D306",\n        "E306",\n        "3D06",\n        "3E06",\n        "B307",\n        "3B07",\n        "X307",\n        "Y307",\n        "B320",\n        "C320",\n        "X320",\n        "X321",\n        "B322",\n        "D322",\n        "0325",\n        "0326"\n      ],\n      "bootloaders_observed": [\n        "X702",\n        "X703",\n        "X705",\n        "X706",\n        "X709",\n        "0709"\n      ],\n      "hsm_observed": [\n        "1.0.15"\n      ]\n    },\n    "PV5": {\n      "applications_observed": [\n        "X340",\n        "0341",\n        "B342",\n        "C342",\n        "D342",\n        "E342",\n        "X342",\n        "Z342",\n        "B343",\n        "C343",\n        "X343",\n        "C344",\n        "D344",\n        "X344",\n        "Y344",\n        "B345",\n        "0350"\n      ],\n      "bootloaders_observed": [\n        "X706",\n        "X709",\n        "0709",\n        "6710",\n        "0711"\n      ],\n      "hsm_observed": [\n        "1.0.15"\n      ],\n      "conditional_dependencies": [\n        "M345 for MDK vehicles"\n      ]\n    },\n    "PV7": {\n      "applications_observed": [\n        "B360",\n        "X360",\n        "B361",\n        "C361",\n        "X361",\n        "X362",\n        "X364",\n        "B365",\n        "36C5",\n        "D365",\n        "E365",\n        "3F65",\n        "3G65",\n        "0365",\n        "0366",\n        "0369",\n        "0381"\n      ],\n      "bootloaders_observed": [\n        "0711"\n      ],\n      "hsm_observed": [\n        "1.0.15",\n        "1.0.16"\n      ],\n      "conditional_dependencies": [\n        "M345 for MDK vehicles"\n      ]\n    },\n    "PV9": {\n      "applications_observed": [\n        "B400",\n        "0402"\n      ],\n      "bootloaders_observed": [\n        "0711"\n      ],\n      "hsm_observed": [\n        "0100"\n      ],\n      "prerequisites": [\n        "HSM 0016 must be installed before HSM 0100"\n      ]\n    }\n  },\n  "transitions": {\n    "X307": {\n      "Y307": {\n        "status": "COMPATIBLE_BIDIRECTIONAL",\n        "upgrade_allowed": true,\n        "downgrade_allowed": true,\n        "requirements": []\n      },\n      "B320": {\n        "status": "UPGRADE",\n        "upgrade_allowed": true,\n        "downgrade_allowed": false,\n        "requirements": []\n      },\n      "X320": {\n        "status": "UPGRADE",\n        "upgrade_allowed": true,\n        "downgrade_allowed": false,\n        "requirements": [\n          {\n            "type": "BOOTLOADER",\n            "target": "X706",\n            "mandatory": true\n          }\n        ]\n      },\n      "0326": {\n        "status": "UPGRADE",\n        "upgrade_allowed": true,\n        "downgrade_allowed": false,\n        "requirements": [\n          {\n            "type": "BOOTLOADER_SEQUENCE",\n            "targets": [\n              "X709",\n              "0709"\n            ],\n            "mandatory": true\n          }\n        ],\n        "explicitly_skippable": [\n          "X706"\n        ]\n      },\n      "X340": {\n        "status": "UPGRADE",\n        "upgrade_allowed": true,\n        "downgrade_allowed": false,\n        "requirements": []\n      }\n    },\n    "0381": {\n      "0402": {\n        "status": "UPGRADE",\n        "upgrade_allowed": true,\n        "downgrade_allowed": false,\n        "requirements": [\n          {\n            "type": "BOOTLOADER",\n            "target": "0711",\n            "mandatory": false,\n            "rule": "May be replaced by a later compatible target dependency"\n          },\n          {\n            "type": "HSM",\n            "target": "0100",\n            "mandatory": true,\n            "requires_installed": "0016",\n            "install_once_per_bcm": true\n          }\n        ]\n      }\n    }\n  },\n  "validation": {\n    "explicit_transitions_source_verified": [\n      "X307->Y307",\n      "X307->B320",\n      "X307->X320",\n      "X307->0326",\n      "X307->X340"\n    ],\n    "diagram_derived_entries_require_engineering_review": [\n      "0381->0402",\n      "application_families"\n    ],\n    "unknown_transition_policy": "Do not infer downgrade. Return UNKNOWN_REVIEW_REQUIRED unless an explicit reverse path or family rule exists."\n  },\n  "manual_overrides": [\n    {\n      "id": "MANUAL_BCM_Y591_TO_0591_20261016143607",\n      "enabled": true,\n      "source": {\n        "type": "manual",\n        "vehicle": "El Enchufado",\n        "vin": "VSSPVSKM1VR000022",\n        "validated_at": "2026-10-16T14:36:07"\n      },\n      "from": "Y591",\n      "to": "0591",\n      "result": "UPGRADE",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": false\n      },\n      "allow_excel_update": true,\n      "message": "UPGRADE BCM confirmado manualmente."\n    },\n    {\n      "id": "MANUAL_BCM_0591_TO_Y591_20261016144833",\n      "enabled": true,\n      "source": {\n        "type": "manual",\n        "vehicle": "El Enchufado",\n        "vin": "VSSPVSKM1VR000022",\n        "validated_at": "2026-10-16T14:48:33"\n      },\n      "from": "0591",\n      "to": "Y591",\n      "result": "DOWNGRADE",\n      "requirements": {\n        "bootloader": false,\n        "fbl_update": false,\n        "hsm_update": false,\n        "marvell_update": false\n      },\n      "allow_excel_update": true,\n      "message": "DOWNGRADE BCM confirmado manualmente."\n    }\n  ]\n}')

class MatrixRepository:
    def __init__(self):
        self.cache = {"GW": GW_MATRIX, "BCM": BCM_MATRIX}
    def load(self, ecu):
        if ecu.upper() not in self.cache:
            raise ValueError("Solo se admiten GW y BCM")
        return self.cache[ecu.upper()]

class TransitionService:
    def __init__(self, repo=None):
        self.repo = repo or MatrixRepository()
    @staticmethod
    def n(value):
        return str(value or "").strip().upper()
    def targets(self, ecu, current):
        ecu, current = ecu.upper(), self.n(current)
        data = self.repo.load(ecu)
        targets = set()
        for override in data.get("manual_overrides", []):
            if override.get("enabled", True) and self.n(override.get("from")) == current:
                targets.add(self.n(override.get("to")))
        if ecu == "BCM":
            targets.update(data.get("transitions", {}).get(current, {}))
        else:
            for rule in data.get("rules", []):
                if rule.get("enabled", True) and current in map(self.n, rule.get("from", [])):
                    targets.update(map(self.n, rule.get("to", [])))
        return sorted(x for x in targets if x)
    @staticmethod
    def _requirements(req):
        if isinstance(req, list):
            return [dict(item) for item in req if isinstance(item, dict)]
        if not isinstance(req, dict):
            return []
        result = []
        for typ, target_key, mandatory_key in (("FBL", "target_fbl", "fbl_update"), ("HSM_BL", "target_hsm_bl", "hsm_update"), ("HSM_FW", "target_hsm_fw", "hsm_update"), ("MARVELL", "target_marvell_fw", "marvell_update")):
            target = req.get(target_key)
            mandatory = bool(req.get(mandatory_key))
            if mandatory or target:
                result.append({"type": typ, "target": target, "mandatory": mandatory})
        return result
    @classmethod
    def _make(cls, ecu, current, target, source, status_key="result"):
        return TransitionPreview(
            ecu, current, target, source.get(status_key, "UPGRADE"), True,
            source.get("id", ""), source.get("message", ""),
            cls._requirements(source.get("requirements", [])),
            dict(source.get("artifacts", {})), dict(source),
        )
    def preview(self, ecu, current, target):
        ecu, current, target = ecu.upper(), self.n(current), self.n(target)
        data = self.repo.load(ecu)
        if not current or not target or current == "-":
            return TransitionPreview(ecu, current, target, "REVIEW_REQUIRED", False, message="No consta SW actual u objetivo.")
        if current == target:
            return TransitionPreview(ecu, current, target, "SAME", True, message="La versión objetivo coincide con la actual.")
        for rule in data.get("manual_overrides", []):
            if rule.get("enabled", True) and self.n(rule.get("from")) == current and self.n(rule.get("to")) == target:
                return self._make(ecu, current, target, rule)
        if ecu == "BCM":
            rule = data.get("transitions", {}).get(current, {}).get(target)
            if rule:
                result = self._make(ecu, current, target, rule, "status")
                # La propia matriz exige revisión para rutas derivadas de diagramas.
                if f"{current}->{target}" in data.get("validation", {}).get("diagram_derived_entries_require_engineering_review", []):
                    result.documented = False
                    result.status = "REVIEW_REQUIRED"
                    result.message = "Ruta derivada de diagrama: revisión técnica obligatoria. " + result.message
                return result
        else:
            for rule in data.get("rules", []):
                if rule.get("enabled", True) and current in map(self.n, rule.get("from", [])) and target in map(self.n, rule.get("to", [])):
                    return self._make(ecu, current, target, rule)
        return TransitionPreview(ecu, current, target, "REVIEW_REQUIRED", False, message="Ruta no documentada; no se permite preparar automáticamente.")

class SoftwareArtifactParser:
    @classmethod
    def parse(cls, path):
        p = Path(path)
        if not p.is_file():
            raise FileNotFoundError(p)
        artifact = cls.parse_name(p.name)
        artifact.path = str(p.resolve())
        return artifact
    @staticmethod
    def parse_name(name):
        p = Path(name)
        ext = p.suffix.lower()
        if ext not in (".pdx", ".odx"):
            raise ValueError("El software debe ser PDX u ODX")
        tokens = [token.upper() for token in p.stem.split("_")]
        joined = "_".join(tokens)
        var = next((x for x in tokens if any(k in x for k in ("HMC", "APP", "FBL", "HSM", "MARVELL"))), "")
        if "FBLUINT" in joined:
            typ = ComponentType.FBL_INTERMEDIATE
        elif "FBL" in joined:
            typ = ComponentType.FBL
        elif "HSMBL" in joined:
            typ = ComponentType.HSM_BOOTLOADER
        elif "HSMFW" in joined:
            typ = ComponentType.HSM_FIRMWARE
        elif "MARVELL" in joined:
            typ = ComponentType.MARVELL
        elif "HMC" in joined or "APP" in joined:
            typ = ComponentType.APPLICATION
        else:
            typ = ComponentType.UNKNOWN
        env = "PROD" if ("PROD" in joined or "PRD" in joined or tokens[-1:] == ["S"]) else "DEV" if ("DEV" in joined or tokens[-1:] == ["E"]) else "UNKNOWN"
        hint = "GW" if "5QS907530" in joined or "HMC" in joined else "BCM" if "5WA937" in joined else "UNKNOWN"
        return SoftwareArtifact(
            str(p), p.name, ext,
            tokens[1] if len(tokens) > 1 and tokens[0] == "FL" else "",
            tokens[2] if len(tokens) > 2 and tokens[0] == "FL" else "",
            typ, env, var,
            next((x for x in tokens if re.fullmatch(r"V\d{3,}", x)), ""),
            tokens[-1] if tokens[-1:] and tokens[-1] in ("S", "E") else "",
            hint,
        )

class SelectionValidator:
    @staticmethod
    def validate(ecu, info, tr, artifact):
        selection = SoftwareSelection(ecu, info.sw, tr.target_sw, tr, artifact)
        if not tr.documented or tr.status in ("REVIEW_REQUIRED", "UNKNOWN_REVIEW_REQUIRED", "SAME", "BLOCKED"):
            selection.errors.append(tr.message or "Transición sin confirmación documental")
            selection.state = ValidationState.REVIEW_REQUIRED
            return selection
        if not artifact:
            selection.errors.append("Selecciona el contenedor de aplicación para verificar la SW.")
        else:
            if artifact.component_type != ComponentType.APPLICATION:
                selection.errors.append("El archivo principal no es de tipo APPLICATION.")
            if not re.fullmatch(r"[A-Z0-9]{3,5}", artifact.software_version.upper()) or artifact.software_version.upper() != tr.target_sw:
                selection.errors.append("La SW del nombre del archivo no coincide con la versión objetivo; revisa el archivo.")
            if artifact.ecu_hint != ecu:
                selection.errors.append("No se puede confirmar que el archivo corresponda a la ECU seleccionada.")
            if info.part_number not in ("", "-") and artifact.part_number and info.part_number.upper() != artifact.part_number.upper():
                selection.warnings.append("La referencia de pieza del archivo difiere de la ECU; verificar compatibilidad de hardware.")
            if artifact.environment not in ("PROD", "DEV"):
                selection.errors.append("Entorno PROD/DEV desconocido.")
            expected = "S" if artifact.environment == "PROD" else "E"
            # Algunos contenedores GW .pdx no tienen sufijo; la ausencia exige revisión.
            if artifact.suffix and artifact.suffix != expected:
                selection.errors.append("Entorno y sufijo del archivo incompatibles.")
        if tr.requirements:
            mandatory = [r.get("type", "?") for r in tr.requirements if r.get("mandatory", False)]
            if mandatory:
                selection.warnings.append("Dependencias obligatorias pendientes de verificar: " + ", ".join(mandatory))
        if ecu == "BCM":
            selection.warnings.append("Comprobar FDS, MDK y HSM de un solo uso según historial real de BCM.")
        selection.state = ValidationState.BLOCKED if selection.errors else ValidationState.WARNING if selection.warnings else ValidationState.VALID
        return selection

class PlannerEngine:
    MAP = {"BOOTLOADER": "fbl", "FBL": "fbl", "HSM_BL": "hsm_bl", "HSM_FW": "hsm_fw", "MARVELL": "marvell"}
    def build(self, selection, profile=None):
        plan = InstallationPlan(selection.ecu, selection.current_sw, selection.target_sw,
                                "BLOCKED" if selection.state in (ValidationState.BLOCKED, ValidationState.REVIEW_REQUIRED) else "REVIEW_REQUIRED" if selection.warnings else "READY",
                                selection.transition.message,
                                ["Alimentación estabilizada", "Report previo guardado", "ECU, entorno y archivo verificados"],
                                selection.warnings[:])
        def add(action, title, comp="", current="", target="", blocking=False, notes=""):
            plan.steps.append(PlanStep(len(plan.steps) + 1, action, title, comp, str(current or ""), str(target or ""), blocking, notes))
        add("READ", "Leer identificadores actuales")
        for req in selection.transition.requirements:
            comp = req.get("type", "UNKNOWN")
            field = self.MAP.get(comp)
            actual = getattr(profile, field, "") if profile and field else ""
            target = req.get("targets", req.get("target", ""))
            present = actual if not isinstance(actual, list) else ", ".join(actual)
            target_text = ", ".join(str(x) for x in target) if isinstance(target, list) else str(target or "")
            if comp == "BOOTLOADER_SEQUENCE":
                add("MANUAL_CONFIRMATION", "Verificar secuencia completa de bootloader", comp, present, target_text, True,
                    "Secuencia de transición que no debe omitirse ni automatizarse.")
                continue
            # Una comparación de versiones no acredita que un HSM de un solo uso no haya sido ya instalado.
            is_match = bool(actual and target and (
                (actual == target) or
                (isinstance(actual, list) and isinstance(target, list) and bool(set(actual) & set(target))) or
                (isinstance(target, list) and isinstance(actual, str) and actual in target)
            ))
            action = "VERIFY" if is_match else "MANUAL_CONFIRMATION" if not target or not actual else "FLASH" if req.get("mandatory") else "VERIFY"
            add(action, f"{action} {comp}", comp, present, target_text, action == "MANUAL_CONFIRMATION" or (comp.startswith("HSM") and action == "FLASH"),
                "Verificar historial e intervención autorizada" if comp.startswith("HSM") else "")
        add("FLASH", "Instalar aplicación (solo tras verificación manual)", "APPLICATION",
            selection.current_sw, selection.artifact.file_name if selection.artifact else selection.target_sw,
            not bool(selection.artifact))
        add("VALIDATE", "Leer estado final y guardar report")
        if any(step.blocking for step in plan.steps):
            plan.status = "REVIEW_REQUIRED" if plan.status == "READY" else plan.status
        return plan

@dataclass(slots=True)
class Snapshot:
    ready: bool = False
    handle: int = 0
    pid: int = 0
    title: str = ""
    process: str = ""
    message: str = "ODIS Engineering no detectado"

@dataclass(slots=True)
class FlashCheck:
    ready: bool
    details: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

class Monitor:
    def snapshot(self):
        if os.name != "nt":
            return Snapshot(message="La detección de ODIS solo está disponible en Windows")
        from ctypes import wintypes
        windows = []
        user32 = ctypes.windll.user32
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def callback(handle, _):
            length = user32.GetWindowTextLengthW(handle)
            title = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(handle, title, length + 1)
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(handle, ctypes.byref(pid))
            low = title.value.lower()
            if user32.IsWindowVisible(handle) and "engineering" in low and ("odis" in low or "offboard diagnostic" in low):
                windows.append((int(handle), title.value, int(pid.value)))
            return True
        ref = callback_type(callback)
        user32.EnumWindows(ref, 0)
        if not windows:
            return Snapshot(message="ODIS Engineering no está abierto")
        handle, title, pid = windows[0]
        try:
            import psutil
            process = psutil.Process(pid).name()
        except Exception:
            process = "PID no accesible"
        return Snapshot(True, handle, pid, title, process, "Ventana ODIS Engineering detectada")

class UIA:
    @staticmethod
    def window(handle):
        from pywinauto import Desktop
        return Desktop(backend="uia").window(handle=handle)
    @staticmethod
    def controls(handle):
        window = UIA.window(handle).wrapper_object()
        result = []
        for item in [window, *window.descendants()]:
            try:
                info = item.element_info
                result.append((str(info.name or ""), str(info.control_type or ""), item.is_enabled(), item.is_visible()))
            except Exception:
                pass
        return result

class AutonomousEngine:
    """Automatiza navegación hacia PRE-FLASH; JAMÁS pulsa Starts flashing."""
    def __init__(self, snapshot, ecu, path, protocol, calibration=(0.0, 0.0), progress=None, stop_event=None):
        if not snapshot.ready or ecu not in ("GW", "BCM") or not Path(path).is_file():
            raise ValueError("ODIS, ECU o archivo no válidos")
        self.s = snapshot
        self.ecu = ecu
        self.path = str(Path(path).resolve())
        self.protocol = protocol
        self.calibration = calibration
        self.progress = progress or (lambda _: None)
        self.stop_event = stop_event or threading.Event()
        self.w = UIA.window(snapshot.handle)
    def run(self, timeout=240):
        end = time.monotonic() + timeout
        last = ""
        attempts = {}
        while time.monotonic() < end:
            if self.stop_event.is_set():
                raise RuntimeError("Preparación cancelada antes de completar PRE-FLASH")
            file_dialog = self.find_file_dialog()
            controls = UIA.controls(self.s.handle)
            state = "FILE" if file_dialog is not None else self.state(controls)
            if state != last:
                self.progress("Estado ODIS: " + state)
                last = state
            if state == "READY":
                return self.validate(controls)
            if state == "CRITICAL":
                raise RuntimeError("ODIS muestra una confirmación crítica; proceso detenido")
            action = {"INITIAL": self.diagnostic, "PROTOCOL": self.select_protocol,
                      "ECUS": self.select_ecu_flash, "FLASH": self.open_file,
                      "FILE": self.fill_file}.get(state)
            if action:
                attempts[state] = attempts.get(state, 0) + 1
                if attempts[state] > 3:
                    raise RuntimeError(f"ODIS no ha avanzado desde {state}; detener para evitar clics repetidos")
                action()
            else:
                time.sleep(.7)
            time.sleep(.8)
        raise TimeoutError("Tiempo agotado en estado " + last)
    @staticmethod
    def state(controls):
        names = [item[0] for item in controls]
        if any(n == "Confirmation" and t == "Window" for n, t, *_ in controls):
            return "CRITICAL"
        if any(n in ("Abrir", "Open") and t == "Window" for n, t, *_ in controls):
            return "FILE"
        if any(n == "Vehicle information selection" and t == "Window" for n, t, *_ in controls):
            return "PROTOCOL"
        if "Loading/unloading the package" in names:
            return "LOADING"
        if any(n.lower().startswith("flash container:") for n in names) and any(n.lower().startswith("session:") for n in names):
            return "READY"
        if "VEH - FL" in names and "Local flash file" in names:
            return "FLASH"
        if any(re.match(r"^042\s*-\s*Flashing$", n) for n in names):
            return "ECUS"
        return "INITIAL"
    def diagnostic(self):
        for typ in ("Button", "Pane", "Text"):
            try:
                control = self.w.child_window(title="Diagnostic Entry", control_type=typ)
                control.wait("visible enabled", 3)
                wrapper = control.wrapper_object()
                target = wrapper.parent() if typ == "Text" else wrapper
                target.set_focus()
                target.click_input()
                self.progress(f"Diagnostic Entry pulsado mediante {typ}")
                return
            except Exception:
                pass
        x_ratio, y_ratio = self.calibration
        if 0 < x_ratio < 1 and 0 < y_ratio < 1:
            from pywinauto import mouse
            rect = self.w.rectangle()
            x, y = rect.left + int(rect.width() * x_ratio), rect.top + int(rect.height() * y_ratio)
            self.w.set_focus()
            mouse.click(coords=(x, y))
            self.progress("Diagnostic Entry pulsado mediante calibración")
            return
        raise RuntimeError("Diagnostic Entry no disponible; calibra primero la posición")
    def select_protocol(self):
        dialog = self.w.child_window(title="Vehicle information selection", control_type="Window")
        dialog.child_window(title=self.protocol, control_type="ListItem").select()
        dialog.child_window(title="OK", control_type="Button").click_input()
        self.progress("Protocolo seleccionado")
    def select_ecu_flash(self):
        address = "0019" if self.ecu == "GW" else "0009"
        self.w.child_window(title_re=rf"^{address}\s*-", control_type="TreeItem").select()
        self.w.child_window(title_re=r"^042\s*-\s*Flashing$", control_type="TreeItem").double_click_input()
        self.progress("ECU y 042 - Flashing seleccionados")
    def open_file(self):
        self.w.child_window(title="Local flash file", control_type="Button").click_input()
    def find_file_dialog(self):
        try:
            from pywinauto import Desktop
            for title in ("Abrir", "Open"):
                dialog = Desktop(backend="uia").window(title=title)
                if dialog.exists(timeout=.2) and dialog.is_visible():
                    # Evita escribir la ruta en un cuadro Abrir de otra aplicación.
                    if int(dialog.wrapper_object().process_id()) == self.s.pid:
                        return dialog
        except Exception:
            pass
        return None
    def fill_file(self):
        dialog = self.find_file_dialog()
        if dialog is None:
            raise RuntimeError("El selector de Windows no está disponible")
        field = dialog.child_window(auto_id="1148", control_type="Edit")
        if not field.exists(timeout=2):
            edits = dialog.descendants(control_type="Edit")
            field = edits[-1] if edits else None
        if field is None:
            raise RuntimeError("No se encontró el campo Nombre")
        field.set_focus()
        field.set_edit_text(self.path)
        try:
            current = field.get_value()
        except Exception:
            current = self.path
        if str(current).strip('"').casefold() != self.path.casefold():
            raise RuntimeError("El selector no aceptó la ruta exacta del archivo")
        button = dialog.child_window(auto_id="1", control_type="Button")
        if not button.exists(timeout=2):
            button = dialog.child_window(title_re=r"^(Abrir|Open)$", control_type="Button")
        button.wait("visible enabled", 5)
        button.click_input()
        self.progress("Archivo seleccionado: " + Path(self.path).name)
    def validate(self, controls):
        names = [item[0] for item in controls]
        errors = []
        address = "0019" if self.ecu == "GW" else "0009"
        container = next((re.sub(r"\s*\(\d+/\d+\)$", "", n.split(":", 1)[1].strip())
                          for n in names if n.lower().startswith("flash container:")), "")
        if not any(re.match(rf"^{address}\s*-", n) for n in names):
            errors.append("No se confirma la ECU esperada")
        if container.casefold() != Path(self.path).name.casefold():
            errors.append("Contenedor incorrecto: " + (container or "no detectado"))
        if not any(name == "Starts flashing" and enabled for name, _, enabled, _ in controls):
            errors.append("No se confirma Starts flashing habilitado")
        return FlashCheck(not errors, ["Contenedor: " + container, "ECU esperada: " + address], errors)

class InstallationAssistantPanel(ttk.Frame):
    """Vista integrada. No crea un Tk propio ni un bucle gráfico secundario."""
    def __init__(self, parent):
        super().__init__(parent)
        self.host = self.winfo_toplevel()
        self.vehicle: VehicleContext | None = None
        self.extended: ExtendedReport | None = None
        self.ecu: ECUInfo | None = None
        self.ecu_key = ""
        self.transition: TransitionPreview | None = None
        self.artifact: SoftwareArtifact | None = None
        self.selection: SoftwareSelection | None = None
        self.plan: InstallationPlan | None = None
        self.snapshot: Snapshot | None = None
        self.repo = MatrixRepository()
        self.transition_service = TransitionService(self.repo)
        self.planner = PlannerEngine()
        self.event_queue: queue.Queue = queue.Queue()
        self.worker: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.protocol = tk.StringVar(master=self, value=self._pref("protocol", "VINFO_SE38XPACANFD"))
        self.poll_interval = 3000
        try:
            self.calibration = (float(self._pref("calibration_x", "0")),
                                float(self._pref("calibration_y", "0")))
            if not all(0.0 <= value <= 1.0 for value in self.calibration):
                self.calibration = (0.0, 0.0)
        except (TypeError, ValueError):
            self.calibration = (0.0, 0.0)
        self.ecu_var = tk.StringVar(master=self, value="Selecciona ECU")
        self.target_var = tk.StringVar(master=self)
        self.manual_var = tk.StringVar(master=self)
        self.summary_var = tk.StringVar(master=self, value="VIN —   |   ECU —   |   SW actual —   |   SW objetivo —")
        self.odis_status = tk.StringVar(master=self, value="ODIS Engineering: sin comprobar")
        self.odis_detail = tk.StringVar(master=self, value="Abre ODIS Engineering para detectar la ventana.")
        self._build_ui()
        self.after(150, self._consume_worker_events)
        self.after(700, self._poll_odis)

    def _pref(self, name: str, default: str) -> str:
        store = getattr(self.host, "store", None)
        if store is None or not hasattr(store, "get_tool_preference"):
            return default
        try:
            return store.get_tool_preference("installation." + name, default)
        except Exception:
            return default

    def _save_pref(self, name: str, value: str):
        store = getattr(self.host, "store", None)
        if store is None or not hasattr(store, "set_tool_preference"):
            return
        try:
            store.set_tool_preference("installation." + name, value)
        except Exception as exc:
            self._log(f"No se pudo guardar la preferencia: {exc}")

    @staticmethod
    def _label(parent, text="", **kwargs):
        return ttk.Label(parent, text=text, **kwargs)

    def _text(self, parent, height=15):
        container = ttk.Frame(parent)
        box = tk.Text(container, wrap="word", height=height, font=("Consolas", 10))
        scroll = ttk.Scrollbar(container, orient="vertical", command=box.yview)
        box.configure(yscrollcommand=scroll.set, state="disabled")
        box.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        container.pack(fill="both", expand=True, pady=(7, 0))
        return box

    @staticmethod
    def _write(box, text: str):
        box.configure(state="normal")
        box.delete("1.0", "end")
        box.insert("1.0", text)
        box.configure(state="disabled")

    def _log(self, line: str):
        if not hasattr(self, "log_box"):
            return
        self.log_box.configure(state="normal")
        self.log_box.insert("end", line + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def _build_ui(self):
        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)
        title = ttk.Frame(root)
        title.pack(fill="x")
        self._label(title, text=APP_NAME, font=("Segoe UI", 13, "bold")).pack(side="left")
        self._label(title, text=APP_VERSION).pack(side="right")
        self._label(root, textvariable=self.summary_var).pack(fill="x", pady=(7, 10))
        self.tabs = ttk.Notebook(root)
        self.tabs.pack(fill="both", expand=True)
        reports = ttk.Frame(self.tabs, padding=10)
        software = ttk.Frame(self.tabs, padding=10)
        plan = ttk.Frame(self.tabs, padding=10)
        odis = ttk.Frame(self.tabs, padding=10)
        for panel, label in ((reports, "Report"), (software, "Software"), (plan, "Plan"), (odis, "ODIS Engineering")):
            self.tabs.add(panel, text=label)
        bar = ttk.Frame(reports)
        bar.pack(fill="x")
        ttk.Button(bar, text="Cargar report principal", command=self.load_report).pack(side="left", padx=(0, 8))
        ttk.Button(bar, text="Cargar report extendido", command=self.load_extended).pack(side="left")
        self.report_text = self._text(reports)

        row = ttk.Frame(software)
        row.pack(fill="x")
        self.ecu_combo = ttk.Combobox(row, textvariable=self.ecu_var,
                                      values=("Selecciona ECU", "GW", "BCM"), state="readonly", width=19)
        self.ecu_combo.pack(side="left", padx=(0, 7))
        self.ecu_combo.bind("<<ComboboxSelected>>", self.pick_ecu)
        self.target_combo = ttk.Combobox(row, textvariable=self.target_var, state="readonly", width=18)
        self.target_combo.pack(side="left", padx=(0, 7))
        self.target_combo.bind("<<ComboboxSelected>>", self.pick_target)
        ttk.Entry(row, textvariable=self.manual_var, width=17).pack(side="left", padx=(0, 7))
        ttk.Button(row, text="Objetivo manual", command=self.use_manual_target).pack(side="left")
        bar2 = ttk.Frame(software)
        bar2.pack(fill="x", pady=(10, 0))
        ttk.Button(bar2, text="Seleccionar archivo PDX / ODX", command=self.pick_file).pack(side="left")
        ttk.Button(bar2, text="Generar plan", command=self.gen_plan).pack(side="right")
        self.software_text = self._text(software)
        self.plan_text = self._text(plan)

        state = ttk.LabelFrame(odis, text="Detección de ODIS Engineering", padding=10)
        state.pack(fill="x")
        self._label(state, textvariable=self.odis_status, font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self._label(state, textvariable=self.odis_detail, wraplength=760).pack(anchor="w", pady=(6, 0))
        actions = ttk.Frame(odis)
        actions.pack(fill="x", pady=10)
        self._label(actions, text="Protocolo:").pack(side="left")
        self.protocol_entry = ttk.Entry(actions, textvariable=self.protocol, width=29)
        self.protocol_entry.pack(side="left", padx=(6, 10))
        ttk.Button(actions, text="Guardar protocolo", command=lambda: self._save_pref("protocol", self.protocol.get().strip())).pack(side="left")
        buttons = ttk.Frame(odis)
        buttons.pack(fill="x", pady=(0, 9))
        ttk.Button(buttons, text="Detectar ODIS", command=self.poll_odis).pack(side="left", padx=(0, 6))
        ttk.Button(buttons, text="Calibrar Diagnostic Entry", command=self.calibrate).pack(side="left", padx=(0, 6))
        self.auto_button = ttk.Button(buttons, text="Preparar hasta PRE-FLASH", command=self.start_auto)
        self.auto_button.pack(side="left", padx=(0, 6))
        self.stop_button = ttk.Button(buttons, text="Cancelar", command=self.cancel_auto, state="disabled")
        self.stop_button.pack(side="left")
        self.progress = ttk.Progressbar(odis, mode="indeterminate")
        self.progress.pack(fill="x", pady=(0, 6))
        self._label(odis, text="El programa nunca pulsa Starts flashing; requiere confirmación humana.").pack(anchor="w")
        self.log_box = self._text(odis, height=10)

    def _error(self, title, error):
        messagebox.showerror(title, str(error), parent=self.winfo_toplevel())

    def load_report(self):
        path = filedialog.askopenfilename(parent=self, title="Report ODIS", filetypes=[("HTML", "*.html *.htm")])
        if not path:
            return
        try:
            self.vehicle = ODISReportParser().parse(path)
            self.ecu = self.transition = self.artifact = self.selection = self.plan = None
            self.ecu_key = ""
            self.ecu_var.set("Selecciona ECU")
            self.target_var.set("")
            self.target_combo.configure(values=[])
            lines = [f"VIN: {self.vehicle.vin}", "", "ECUs:"]
            for address, info in self.vehicle.ecus.items():
                lines.append(f"{address} - {info.name} | Part: {info.part_number} | SW: {info.sw} | HW: {info.hw} | {info.vendor}")
            lines += ["", *self.vehicle.warnings]
            self._write(self.report_text, "\n".join(lines))
            self.summary_var.set(f"VIN {self.vehicle.vin}  |  Report cargado")
        except Exception as exc:
            self._error("Error de report", exc)

    def load_extended(self):
        path = filedialog.askopenfilename(parent=self, title="Report ODIS extendido", filetypes=[("HTML", "*.html *.htm")])
        if not path:
            return
        try:
            result = ExtendedReportParser().parse(path)
            if self.vehicle and self.vehicle.vin != "-" and result.vin != "-" and self.vehicle.vin != result.vin:
                raise ValueError("El VIN del report extendido no coincide con el principal")
            self.extended = result
            lines = [f"VIN: {result.vin}", ""] + [
                f"{address}: APP {profile.application} | FBL {profile.fbl} | HSM BL {profile.hsm_bl} | HSM FW {profile.hsm_fw} | Marvell {profile.marvell}"
                for address, profile in result.profiles.items()
            ] + result.warnings
            self._write(self.report_text, "\n".join(lines))
        except Exception as exc:
            self._error("Error de report extendido", exc)

    def pick_ecu(self, _event=None):
        key = self.ecu_var.get()
        self.ecu = self.vehicle.gw if self.vehicle and key == "GW" else self.vehicle.bcm if self.vehicle and key == "BCM" else None
        self.ecu_key = key if self.ecu else ""
        self.transition = self.artifact = self.selection = self.plan = None
        self.target_var.set("")
        self.target_combo.configure(values=[])
        if key in ("GW", "BCM") and not self.ecu:
            self._error("ECU", "No se encuentra esa ECU en el report principal")
            return
        if self.ecu:
            targets = self.transition_service.targets(key, self.ecu.sw)
            self.target_combo.configure(values=targets)
            self._write(self.software_text, f"SW actual: {self.ecu.sw}\nObjetivos documentados: {', '.join(targets) if targets else 'ninguno'}")
            self.summary_var.set(f"VIN {self.vehicle.vin}  |  {key} ({self.ecu.address})  |  SW {self.ecu.sw}  |  objetivo —")

    def pick_target(self, _event=None):
        self._set_target(self.target_var.get())

    def use_manual_target(self):
        self._set_target(self.manual_var.get())

    def _set_target(self, target):
        target = target.strip().upper()
        if not self.ecu or not target:
            return
        self.target_var.set(target)
        self.transition = self.transition_service.preview(self.ecu_key, self.ecu.sw, target)
        self.artifact = None  # Un archivo previo no puede validarse para otra versión.
        self._refresh_selection()

    def pick_file(self):
        if not self.transition:
            self._error("Software", "Selecciona primero una ECU y una SW objetivo")
            return
        path = filedialog.askopenfilename(parent=self, title="Software ODIS", filetypes=[("ODIS", "*.pdx *.odx")])
        if not path:
            return
        try:
            self.artifact = SoftwareArtifactParser.parse(path)
            self._refresh_selection()
        except Exception as exc:
            self._error("Software", exc)

    def _refresh_selection(self):
        if not self.transition or not self.ecu:
            return
        self.selection = SelectionValidator.validate(self.ecu_key, self.ecu, self.transition, self.artifact)
        tr, sel = self.transition, self.selection
        artifact = self.artifact
        lines = [f"ECU {self.ecu_key} ({self.ecu.address})", f"Ruta: {tr.current_sw} → {tr.target_sw}",
                 f"Estado de ruta: {tr.status}", f"Regla: {tr.rule_id or 'sin identificador'}", f"Documentada: {'SÍ' if tr.documented else 'NO'}",
                 f"{tr.message}", "", f"Archivo: {artifact.file_name if artifact else 'sin seleccionar'}",
                 f"Validación: {sel.state.value}", ""]
        lines += ["ERRORES:"] + (["• " + x for x in sel.errors] or ["Ninguno"])
        lines += ["", "ADVERTENCIAS:"] + (["• " + x for x in sel.warnings] or ["Ninguna"])
        if tr.requirements:
            lines += ["", "DEPENDENCIAS:"] + ["• " + json.dumps(x, ensure_ascii=False) for x in tr.requirements]
        self._write(self.software_text, "\n".join(lines))
        self.summary_var.set(f"VIN {self.vehicle.vin if self.vehicle else '-'}  |  {self.ecu_key} SW {tr.current_sw} → {tr.target_sw}  |  {sel.state.value}")

    def gen_plan(self):
        if not self.selection:
            self._error("Plan", "Selecciona primero una ECU y una transición")
            return
        profile = self.extended.profiles.get(self.ecu.address) if self.extended and self.ecu else None
        self.plan = self.planner.build(self.selection, profile)
        lines = [f"ESTADO: {self.plan.status}", f"{self.plan.ecu}: {self.plan.current_sw} → {self.plan.target_sw}",
                 self.plan.rationale, "", "PRECONDICIONES:"]
        lines += ["• " + x for x in self.plan.preconditions]
        lines += ["", "PASOS:"]
        for step in self.plan.steps:
            lines.append(f"{step.order}. [{step.action}] {step.title}  |  actual={step.current or '-'}  |  objetivo={step.target or '-'}" + ("  ⚠ REVISIÓN" if step.blocking else ""))
            if step.notes:
                lines.append("    " + step.notes)
        lines += ["", "ADVERTENCIAS:"] + (self.plan.warnings or ["Ninguna"])
        self._write(self.plan_text, "\n".join(lines))
        self.tabs.select(2)

    def _poll_odis(self):
        if not self.winfo_exists():
            return
        if not self.worker or not self.worker.is_alive():
            # Poll solo cuando la pestaña ODIS está abierta para no ralentizar la ventana.
            if self.tabs.index("current") == 3:
                self.poll_odis()
        self.after(self.poll_interval, self._poll_odis)

    def poll_odis(self):
        if self.worker and self.worker.is_alive():
            return
        try:
            self.snapshot = Monitor().snapshot()
            status = "READY" if self.snapshot.ready else "NOT_RUNNING"
            self.odis_status.set(status)
            self.odis_detail.set(f"{self.snapshot.message}\nProceso: {self.snapshot.process or '-'} · PID: {self.snapshot.pid or '-'}\nVentana: {self.snapshot.title or '-'}")
        except Exception as exc:
            self.odis_status.set("ERROR")
            self.odis_detail.set(str(exc))

    def calibrate(self):
        self.poll_odis()
        if not self.snapshot or not self.snapshot.ready:
            self._error("ODIS", "Abre ODIS Engineering antes de calibrar")
            return
        if not messagebox.askokcancel("Calibración", "Coloca el cursor sobre Diagnostic Entry en ODIS y pulsa Aceptar. No pulses ODIS todavía.", parent=self):
            return
        try:
            if os.name != "nt":
                raise RuntimeError("Función disponible solo en Windows")
            from ctypes import wintypes
            point = wintypes.POINT()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(point))
            from pywinauto import Desktop
            window = Desktop(backend="uia").window(handle=self.snapshot.handle)
            rect = window.rectangle()
            if not (rect.left <= point.x <= rect.right and rect.top <= point.y <= rect.bottom):
                raise RuntimeError("El cursor no está en la ventana de ODIS")
            self.calibration = ((point.x - rect.left) / max(1, rect.width()),
                                (point.y - rect.top) / max(1, rect.height()))
            self._save_pref("calibration_x", str(self.calibration[0]))
            self._save_pref("calibration_y", str(self.calibration[1]))
            messagebox.showinfo("Calibración", f"Posición guardada: {self.calibration[0]:.3f}, {self.calibration[1]:.3f}", parent=self)
        except Exception as exc:
            self._error("Calibración", exc)

    def start_auto(self):
        if self.worker and self.worker.is_alive():
            return
        self.poll_odis()
        if not self.snapshot or not self.snapshot.ready:
            self._error("ODIS", "ODIS Engineering no está abierto")
            return
        if not self.selection or not self.artifact or not self.ecu:
            self._error("Preparación", "Primero carga report, transición y software")
            return
        if self.selection.state in (ValidationState.BLOCKED, ValidationState.REVIEW_REQUIRED):
            self._error("Preparación bloqueada", "La transición o el archivo necesitan revisión; no se automatizará ODIS")
            return
        if not self.plan:
            self.gen_plan()
        if self.plan and self.plan.status == "BLOCKED":
            self._error("Preparación bloqueada", "El plan contiene errores que impiden preparar la operación")
            return
        if self.plan and self.plan.status == "REVIEW_REQUIRED":
            if not messagebox.askyesno(
                "Plan pendiente de revisión",
                "Hay verificaciones de componentes que el report no acredita o requieren comprobación manual.\n\n"
                "Solo se preparará la pantalla PRE-FLASH; no se instalará software.\n"
                "¿Has revisado las dependencias con la documentación técnica y deseas continuar?",
                parent=self,
            ):
                return
        if self.selection.warnings and not messagebox.askyesno("Advertencias", "El plan tiene advertencias pendientes:\n\n" + "\n".join(self.selection.warnings) + "\n\n¿Continuar exclusivamente hasta PRE-FLASH, sin flashear?", parent=self):
            return
        if not messagebox.askyesno("Confirmación PRE-FLASH", f"ECU: {self.ecu_key} ({self.ecu.address})\nSW actual: {self.ecu.sw}\nSW objetivo: {self.transition.target_sw}\nContenedor: {self.artifact.file_name}\n\nSe navegará por ODIS, sin pulsar Starts flashing. ¿Continuar?", parent=self):
            return
        self.stop_event.clear()
        self._save_pref("protocol", self.protocol.get().strip())
        self.auto_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.progress.start(14)
        self._log("Iniciando preparación hasta PRE-FLASH...")
        snapshot, ecu, path, proto, calibration = self.snapshot, self.ecu_key, self.artifact.path, self.protocol.get().strip(), self.calibration
        def run():
            pythoncom = None
            try:
                if os.name == "nt":
                    import pythoncom
                    pythoncom.CoInitialize()
                result = AutonomousEngine(snapshot, ecu, path, proto, calibration,
                                          lambda text: self.event_queue.put(("log", text)), self.stop_event).run()
                self.event_queue.put(("done", result))
            except Exception as exc:
                self.event_queue.put(("fail", f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=3)}"))
            finally:
                if pythoncom is not None:
                    pythoncom.CoUninitialize()
                self.event_queue.put(("finished", None))
        self.worker = threading.Thread(target=run, daemon=True, name="EVO_ODIS_PreFlash")
        self.worker.start()

    def cancel_auto(self):
        if self.worker and self.worker.is_alive():
            self.stop_event.set()
            self._log("Cancelación solicitada. Esperando a finalizar acción ODIS actual...")

    def _consume_worker_events(self):
        if not self.winfo_exists():
            return
        while True:
            try:
                event, value = self.event_queue.get_nowait()
            except queue.Empty:
                break
            if event == "log":
                self._log(value)
            elif event == "fail":
                self._log("ERROR: " + value)
                self._error("Preparación detenida", value)
            elif event == "done":
                self._log("PRE-FLASH verificado" if value.ready else "PRE-FLASH: verificación incompleta")
                messagebox.showinfo("Revisión manual PRE-FLASH", ("TODO OK" if value.ready else "BLOQUEADO") + "\n" + "\n".join(value.details + value.errors) + "\n\nStarts flashing NO se pulsa automáticamente.", parent=self)
            elif event == "finished":
                self.progress.stop()
                self.auto_button.configure(state="normal")
                self.stop_button.configure(state="disabled")
                self.worker = None
        self.after(150, self._consume_worker_events)

    def can_close(self) -> bool:
        return not (self.worker and self.worker.is_alive())
