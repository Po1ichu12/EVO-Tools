@echo off
setlocal
cd /d "%~dp0"
python -m pip install -r requirements_EVO_Tools.txt
if errorlevel 1 (
  echo Error instalando dependencias.
  pause
  exit /b 1
)
python -m PyInstaller --noconfirm --clean --onefile --windowed --name "EVO_Tools" --icon "EVO_Tools_Icono.ico" --add-data "EVO_Tools_Icono.ico;." --add-data "EVO_Modo_Oscuro_Golem.jpeg;." --add-data "EVO_Modo_Claro_LeBron.jpeg;." --hidden-import pythoncom --hidden-import psutil --hidden-import pywinauto Control_VRs_BCM_Unificado.py
if errorlevel 1 (
  echo Error durante la compilacion.
  pause
  exit /b 1
)
echo.
echo EJECUTABLE CREADO EN dist\EVO_Tools.exe
pause
