# EVO Tools — paquete completo (23/10/2026)

Contiene las **últimas versiones disponibles en esta conversación**:

- `Control_VRs_BCM_Unificado.py`: manager, login, perfiles, modo claro/oscuro, navegación, historial versionado.
- `Control_VRs_Manager_Mejorado.py`: Control de VRs.
- `BCM_Email_Change_Detector_Mejorado.py`: Cambios de ECU BCM y Gateway.
- `GW_BCM_Installation_Assistant.py`: asistente integrado, matrices GW/BCM incluidas, historial 0.3.9-evo.
- `EVO_Tools_Icono.ico`, `EVO_Modo_Oscuro_Golem.jpeg`, `EVO_Modo_Claro_LeBron.jpeg`: recursos gráficos.
- `requirements_EVO_Tools.txt`: dependencias Python.
- `compilar_windows.bat`: instalación de dependencias y compilación a un EXE mediante PyInstaller.

## Uso en PyCharm

Mantén todos los archivos en la misma carpeta. Instala las dependencias:

```powershell
python -m pip install -r requirements_EVO_Tools.txt
```

Ejecuta `Control_VRs_BCM_Unificado.py`.

## Crear EXE

En Windows, abre `compilar_windows.bat` desde la carpeta del proyecto. El EXE se generará en `dist\EVO_Tools.exe`.

## Configuración personal y seguridad

No se incluye `EVO_Tools_State.db`, porque contiene los perfiles y ajustes de **tu instalación**. Si ya tienes esa base de datos, haz copia de seguridad y consérvala: debe acompañar al EXE al moverlo de ordenador para mantener la configuración compartida. La app puede generar una nueva al inicializarla si no existe.

Tampoco se incluye `EVO_Tools_Config.json` de versiones antiguas ni informes o Excels de trabajo. No es necesario copiar esos documentos dentro del paquete.

## Notas

Las reglas de las matrices GW/BCM están integradas en `GW_BCM_Installation_Assistant.py`; no hace falta distribuir JSON adicionales. La automatización de ODIS Engineering **no se ha validado físicamente en un entorno Windows con ODIS real**. No utilizarla en vehículos sin validación técnica específica y copias de seguridad adecuadas.

Los historiales anteriores a las versiones actuales de VRs, Cambios de ECU y Manager se indican como retrospectivos orientativos, no como releases oficiales.
