"""EVO Tools: Control de VRs, Cambios de ECU y GW/BCM Installation Assistant.

Mantiene ambas herramientas separadas dentro de una única ventana de Tkinter.
Cada sección conserva sus campos, resultados y estado al cambiar de pantalla.

Este archivo debe estar en la misma carpeta que:
    Control_VRs_Manager_Mejorado.py
    BCM_Email_Change_Detector_Mejorado.py
    GW_BCM_Installation_Assistant.py
"""

from __future__ import annotations

import ctypes
from contextlib import contextmanager
import getpass
import hashlib
import json
import os
import sqlite3
import sys
from dataclasses import dataclass
from ctypes import wintypes
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey,
)
from cryptography.exceptions import InvalidSignature
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, simpledialog

try:
    from PIL import Image, ImageOps, ImageTk
except ImportError:
    Image = ImageOps = ImageTk = None

import BCM_Email_Change_Detector_Mejorado as bcm
import Control_VRs_Manager_Mejorado as vr
from GW_BCM_Installation_Assistant import (
    InstallationAssistantPanel,
    APP_NAME as INSTALL_ASSISTANT_NAME,
    APP_VERSION as INSTALL_ASSISTANT_VERSION,
    CHANGELOG as INSTALL_ASSISTANT_CHANGELOG,
)


class ControlVRsPanel(ttk.Frame):
    """Adapta los métodos existentes de ControlVRsApp a un Frame embebido.

    Los métodos de la aplicación original usan únicamente propiedades y widgets
    que proporciona este Frame. Se reutilizan en vez de duplicar la lógica,
    con lo que cualquier corrección del módulo sigue llegando a esta pantalla.
    """

    build_ui = vr.ControlVRsApp.build_ui
    update_swap_state = vr.ControlVRsApp.update_swap_state
    assign_data = vr.ControlVRsApp.assign_data
    choose_file = vr.ControlVRsApp.choose_file
    analyze = vr.ControlVRsApp.analyze
    sync = vr.ControlVRsApp.sync
    show_error = vr.ControlVRsApp.show_error

    def __init__(self, parent: tk.Misc):
        super().__init__(parent)
        self.excel_path = tk.StringVar(master=self)
        self.assign_pv = tk.StringVar(master=self, value="PV9")
        self.assign_model = tk.StringVar(master=self, value="Formentor")
        self.assign_vr = tk.StringVar(master=self, value="42")
        self.assign_ecu = tk.StringVar(master=self, value="GW")
        self.assign_sw = tk.StringVar(master=self)
        self.assign_zdc = tk.StringVar(master=self)
        self.assign_zdc_version = tk.StringVar(master=self)
        self.assign_swap = tk.StringVar(master=self)
        self.assign_swap_version = tk.StringVar(master=self)
        self.status = tk.StringVar(
            master=self,
            value="Selecciona Control VRs.xlsx y analiza la planificación.",
        )
        self.build_ui()


class BCMPanel(ttk.Frame):
    """Adapta los métodos existentes de BCMChangeApp a un Frame embebido."""

    _build_ui = bcm.BCMChangeApp._build_ui
    _file_row = bcm.BCMChangeApp._file_row
    choose_eml = bcm.BCMChangeApp.choose_eml
    choose_excel = bcm.BCMChangeApp.choose_excel
    analyze = bcm.BCMChangeApp.analyze
    import_changes = bcm.BCMChangeApp.import_changes
    assign_zdc_action = bcm.BCMChangeApp.assign_zdc_action
    show_error = bcm.BCMChangeApp.show_error

    def __init__(self, parent: tk.Misc):
        super().__init__(parent)
        self.eml_path = tk.StringVar(master=self)
        self.excel_path = tk.StringVar(master=self)
        self.detected_pv = tk.StringVar(master=self)
        self.assign_pv = tk.StringVar(master=self, value="PV9")
        self.assign_model = tk.StringVar(master=self, value="Formentor")
        self.assign_vr = tk.StringVar(master=self, value="42")
        self.assign_zdc = tk.StringVar(master=self)
        self.status = tk.StringVar(
            master=self,
            value="Selecciona un EML y el Excel de control. El Excel se modificará directamente.",
        )
        self.last_email_data: bcm.EmailData | None = None
        self._build_ui()


# Catálogo central: para agregar otra aplicación, registrar aquí su identificador,
# nombre, descripción y clase de panel. Los perfiles se actualizan automáticamente.
APP_CATALOG = {
    "vr": {
        "title": "Control de VRs",
        "subtitle": "Planificación, sincronización y asignación de SW, ZDC y SWAP",
        "menu": "▣",
        "panel": ControlVRsPanel,
    },
    "bcm": {
        "title": "Cambios de ECU",
        "subtitle": "Análisis de EML de BCM/Gateway, importación y asignación de ZDC",
        "menu": "▤",
        "panel": BCMPanel,
    },
    "install": {
        "title": "GW / BCM Installation Assistant",
        "subtitle": "Reports ODIS, matrices, validación, planes y preparación PRE-FLASH",
        "menu": "▥",
        "panel": InstallationAssistantPanel,
    },
}

# Versionado retrospectivo orientativo: reconstruido a partir de la evolución
# funcional conocida. Las numeraciones antiguas no proceden de releases oficiales.
# Mantener el historial de Installation Assistant enlazado a su CHANGELOG original.
TOOL_CHANGELOGS = {
    "vr": (
        "Control de VRs",
        "Versión de referencia: v1.0.0 · Historial retrospectivo orientativo",
        [
            ("v1.0.0 · Integración en EVO Tools",
             "Incorporación al gestor centralizado, con acceso según perfil, navegación unificada y presentación consistente de resultados."),
            ("v0.9.0 · Validación de datos y prevención de duplicados",
             "Comprobaciones estrictas de VR y estados, identificación de registros repetidos y mensajes de error específicos para inconsistencias del Excel."),
            ("v0.8.0 · Protección de archivos Excel",
             "Copias de seguridad previas a los cambios, validación del libro generado y avisos ante estructuras que pueden verse afectadas por nuevas filas."),
            ("v0.7.0 · Optimización de consultas",
             "Indexación de registros por modelo, PV y VR para agilizar comparaciones, sincronizaciones y asignaciones en hojas extensas."),
            ("v0.6.0 · Asignación manual de datos técnicos",
             "Introducción de SW, ZDC y SWAP en registros concretos, respetando las diferencias entre Gateway y BCM y conservando campos no indicados."),
            ("v0.5.0 · Matriz de hardware",
             "Consulta de referencias HW por ECU, modelo, PV y VR para completar la información disponible durante la sincronización."),
            ("v0.4.0 · Sincronización de VR",
             "Creación de registros pendientes en GW EVO y BCM EVO, con conservación del formato y notificación de datos aún no disponibles."),
            ("v0.3.0 · Comparación de planificación y seguimiento",
             "Contraste de la hoja VRs EVO con los registros existentes y detección de estados o versiones discrepantes."),
            ("v0.2.0 · Tratamiento de estados y proyectos",
             "Normalización de estados SI, HO y AGT, agrupación de coincidencias por SOP e identificación de modelos de vehículo."),
            ("v0.1.0 · Primera versión de análisis",
             "Lectura de la planificación de VR y presentación inicial de la información de seguimiento."),
        ],
    ),
    "bcm": (
        "Cambios de ECU",
        "Versión de referencia: v1.0.0 · Historial retrospectivo orientativo",
        [
            ("v1.0.0 · Consolidación BCM y Gateway",
             "Gestión de ambas ECUs desde una herramienta integrada en EVO Tools, con flujos de trabajo y destinos diferenciados."),
            ("v0.9.0 · Separación segura de ECU",
             "Identificación inequívoca de BCM/0009 y GW/0019, filtrado de correos mixtos y prevención de cruces de RDID entre archivos."),
            ("v0.8.0 · Incorporación de Gateway",
             "Ampliación del importador para tratar cambios de GW con la misma estructura de columnas que BCM y con Excel independiente."),
            ("v0.7.0 · Integración en el manager",
             "Adaptación del detector a la interfaz compartida de EVO Tools, conservando las funciones de análisis, importación y asignación."),
            ("v0.6.0 · Robustez del procesamiento",
             "Validación de PV, VR y RDID, búsqueda indexada, detección de duplicados y copias de seguridad al modificar libros Excel."),
            ("v0.5.0 · Interpretación flexible del correo",
             "Reconocimiento de columnas por encabezado, normalización de datos y manejo más seguro de mensajes EML con estructuras variables."),
            ("v0.4.0 · Gestión posterior de ZDC",
             "Asignación de nombres ZDC por modelo y versión; preservación de los ZDC existentes al importar nuevos cambios."),
            ("v0.3.0 · Importación y actualización de registros",
             "Altas y actualizaciones de filas en las tablas Excel por combinación de VR y RDID, evitando duplicados al repetir la importación."),
            ("v0.2.0 · Identificación de cambios técnicos",
             "Extracción de PV, VR, proyecto y RDID desde correos, con organización de información de problema, impacto y solución."),
            ("v0.1.0 · Primer detector BCM",
             "Lectura inicial de archivos EML y presentación de cambios técnicos relacionados con BCM."),
        ],
    ),
    "install": (
        INSTALL_ASSISTANT_NAME,
        f"Versión actual: {INSTALL_ASSISTANT_VERSION}",
        list(reversed(INSTALL_ASSISTANT_CHANGELOG)),
    ),
    "admin": (
        "EVO Tools",
        "Versión de referencia: v1.0.0 · Historial retrospectivo orientativo",
        [
            ("v1.0.0 · Historiales centralizados",
             "Consulta bajo demanda del historial de la herramienta activa, sin interrupciones al abrir las aplicaciones."),
            ("v0.9.0 · Incorporación de Installation Assistant",
             "Tercera herramienta con análisis de reports ODIS, matrices de actualización, planificación de software y preparación supervisada PRE-FLASH."),
            ("v0.8.0 · Configuración portátil protegida",
             "Evolución hacia almacenamiento local portable con comprobación criptográfica de la configuración administrativa."),
            ("v0.7.0 · Acceso y gestión de sesiones",
             "Pantalla de inicio con selección de perfil, solicitud de contraseña para Admin y conservación del último perfil usado."),
            ("v0.6.0 · Permisos y administración",
             "Creación de perfiles, control de herramientas visibles y edición administrada de nombres y pie de página."),
            ("v0.5.0 · Preferencias de interfaz",
             "Temas claro y oscuro, persistencia de preferencias y accesos rápidos a las secciones del manager."),
            ("v0.4.0 · Navegación entre aplicaciones",
             "Incorporación de Control de VRs y Cambios de ECU en una sola ventana, manteniendo separados sus procesos y formularios."),
            ("v0.1.0 · Primera estructura de EVO Tools",
             "Base modular del gestor para centralizar herramientas técnicas y preparar nuevas integraciones."),
        ],
    ),
}


DEFAULT_PROFILES = {
    "Paula": ["vr", "bcm"],
    "Polichu": ["vr"],
    "Eloi": ["bcm"],
    "Admin": list(APP_CATALOG),
}


# Clave pública incrustada: verifica políticas sin guardar la contraseña de Admin.
# El par de firma se deriva de la contraseña de Admin mediante scrypt.
# Copiar .exe + EVO_Tools_State.db permite llevar los ajustes entre equipos.
_ADMIN_KDF_SALT = bytes.fromhex("21b932cab078115dd2ca94163f19bd2e")
_ADMIN_PUBLIC_KEY = bytes.fromhex(
    "d89306e4cfa29f55fd76cb8afc2278229085cd1bf761be4d24f021df999d51e7"
)
DEFAULT_FOOTER = "EVO Tools · Intern Tool"


def admin_signer(password: str) -> Ed25519PrivateKey | None:
    """Verifica la contraseña por su clave pública; nunca guardamos el secreto."""
    seed = hashlib.scrypt(
        password.encode("utf-8"), salt=_ADMIN_KDF_SALT,
        n=2**15, r=8, p=1, dklen=32, maxmem=128 * 1024 * 1024,
    )
    private_key = Ed25519PrivateKey.from_private_bytes(seed)
    from cryptography.hazmat.primitives import serialization
    public = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    from hmac import compare_digest
    return private_key if compare_digest(public, _ADMIN_PUBLIC_KEY) else None


def verify_admin_password(candidate: str) -> bool:
    return admin_signer(candidate) is not None


def default_settings() -> dict:
    return {"theme": "light", "memes_visible": False, "active_profile": "Paula"}


def validate_profiles(data: object) -> dict[str, list[str]]:
    if not isinstance(data, dict) or not 1 <= len(data) <= 64:
        raise ValueError("Estructura de perfiles no válida")
    result = {}
    for name, apps in data.items():
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 32 or not isinstance(apps, list):
            raise ValueError("Perfil no válido")
        name = name.strip()
        if any(existing.casefold() == name.casefold() for existing in result):
            raise ValueError("Nombres de perfil repetidos")
        if any(not isinstance(x, str) or x not in APP_CATALOG for x in apps):
            raise ValueError("Aplicación no reconocida")
        result[name] = [key for key in APP_CATALOG if key in apps]
    result["Admin"] = list(APP_CATALOG)
    return result


def default_policy() -> dict:
    return {
        "version": 1,
        "profiles": validate_profiles(DEFAULT_PROFILES),
        "app_labels": {},
        "footer_text": DEFAULT_FOOTER,
        "windows_accounts": {},
    }


def validate_policy(document: object) -> dict:
    if not isinstance(document, dict) or document.get("version") != 1:
        raise ValueError("Versión o formato de política no válido")
    profiles = validate_profiles(document.get("profiles"))
    labels = document.get("app_labels", {})
    if not isinstance(labels, dict):
        raise ValueError("Nombres de aplicación inválidos")
    valid_labels = {}
    for key, value in labels.items():
        if key not in APP_CATALOG or not isinstance(value, str) or not 1 <= len(value.strip()) <= 48:
            raise ValueError("Nombre de aplicación no válido")
        valid_labels[key] = value.strip()
    footer = document.get("footer_text", DEFAULT_FOOTER)
    if not isinstance(footer, str) or len(footer) > 200:
        raise ValueError("Pie de página no válido")
    bindings = document.get("windows_accounts", {})
    if not isinstance(bindings, dict):
        raise ValueError("Vínculos de cuentas Windows inválidos")
    valid_bindings = {}
    for name, value in bindings.items():
        if name not in profiles or name == "Admin" or not isinstance(value, str) or len(value) > 128:
            raise ValueError("Vínculo de cuenta Windows no válido")
        if value.strip():
            valid_bindings[name] = value.strip()
    return {
        "version": 1, "profiles": profiles,
        "app_labels": valid_labels, "footer_text": footer,
        "windows_accounts": valid_bindings,
    }


def canonical_policy(policy: dict) -> bytes:
    data = validate_policy(policy)
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


class PortableState:
    """Base de datos transportable; autorización Ed25519, preferencias no críticas.

    El archivo es *accesible* a Windows: el objetivo es detectar la alteración,
    no ocultar de Windows un fichero que el propio usuario puede copiar.
    """
    def __init__(self, path: Path, user: str | None = None):
        self.path = Path(path)
        self.user = user or getpass.getuser().casefold()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS preference (
                user TEXT NOT NULL, name TEXT NOT NULL, value TEXT NOT NULL,
                PRIMARY KEY (user, name))""")
            db.execute("""CREATE TABLE IF NOT EXISTS access_policy (
                id INTEGER PRIMARY KEY CHECK(id = 1),
                payload BLOB NOT NULL, signature BLOB NOT NULL)""")

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(self.path, timeout=5.0)
        try:
            db.execute("PRAGMA journal_mode=DELETE")
            db.execute("PRAGMA synchronous=FULL")
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def get_tool_preference(self, name: str, default: str = "") -> str:
        if not name.startswith("installation."):
            raise ValueError("Preferencia de módulo desconocida")
        with self._connect() as db:
            row = db.execute("SELECT value FROM preference WHERE user=? AND name=?",
                             (self.user, name)).fetchone()
        return row[0] if row else default

    def set_tool_preference(self, name: str, value: str) -> None:
        if not name.startswith("installation.") or len(value) > 512:
            raise ValueError("Preferencia de módulo incorrecta")
        with self._connect() as db:
            db.execute("""INSERT INTO preference(user,name,value) VALUES(?,?,?)
                ON CONFLICT(user,name) DO UPDATE SET value=excluded.value""",
                (self.user, name, value))

    def load_preferences(self) -> dict:
        with self._connect() as db:
            records = dict(db.execute(
                "SELECT name, value FROM preference WHERE user=?", (self.user,),
            ))
        settings = default_settings()
        if records.get("theme") in ("light", "dark"):
            settings["theme"] = records["theme"]
        if records.get("memes_visible") in ("true", "false"):
            settings["memes_visible"] = records["memes_visible"] == "true"
        if isinstance(records.get("active_profile"), str) and len(records["active_profile"]) <= 32:
            settings["active_profile"] = records["active_profile"]
        return settings

    def save_preferences(self, config: dict):
        data = {
            "theme": config["theme"],
            "memes_visible": "true" if config["memes_visible"] else "false",
            "active_profile": config["active_profile"],
        }
        with self._connect() as db:
            db.executemany("""INSERT INTO preference(user,name,value) VALUES(?,?,?)
                ON CONFLICT(user,name) DO UPDATE SET value=excluded.value""",
                [(self.user, key, value) for key, value in data.items()])

    def read_policy(self) -> dict | None:
        """None = sin política; un fichero corrupto o firma inválida eleva error."""
        with self._connect() as db:
            row = db.execute("SELECT payload, signature FROM access_policy WHERE id=1").fetchone()
        if row is None:
            return None
        payload, signature = row
        if len(payload) > 1024 * 1024 or len(signature) != 64:
            raise ValueError("Política demasiado grande o firma inválida")
        try:
            Ed25519PublicKey.from_public_bytes(_ADMIN_PUBLIC_KEY).verify(signature, payload)
        except InvalidSignature as exc:
            raise ValueError("La política ha sido modificada o su firma no es válida") from exc
        return validate_policy(json.loads(payload.decode("utf-8")))

    def sign_and_save_policy(self, proposed: dict, signer: Ed25519PrivateKey):
        payload = canonical_policy(proposed)
        signature = signer.sign(payload)
        # Evitar guardar una política cuya firma no corresponda a la app.
        Ed25519PublicKey.from_public_bytes(_ADMIN_PUBLIC_KEY).verify(signature, payload)
        with self._connect() as db:
            db.execute("""INSERT INTO access_policy(id,payload,signature) VALUES(1,?,?)
                 ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,signature=excluded.signature""",
                 (payload, signature))


def current_windows_identity() -> str:
    """Devuelve la identidad real de Windows, no la variable USERNAME editable."""
    if sys.platform == "win32":
        # NameSamCompatible=2: DOMINIO\usuario; tampoco depende del entorno.
        buffer = ctypes.create_unicode_buffer(512)
        size = wintypes.ULONG(len(buffer))
        secur32 = ctypes.WinDLL("secur32", use_last_error=True)
        func = secur32.GetUserNameExW
        func.argtypes = [ctypes.c_int, wintypes.LPWSTR, ctypes.POINTER(wintypes.ULONG)]
        func.restype = wintypes.BOOLEAN
        if func(2, buffer, ctypes.byref(size)):
            return buffer.value
        # En caso de no poder resolverlo, no autorizar perfiles vinculados.
        return ""
    return getpass.getuser()


def account_matches(expected: str, actual: str) -> bool:
    if not expected:
        return True
    expected = expected.strip().casefold()
    actual = actual.strip().casefold()
    return expected == actual or ("\\" not in expected and actual.split("\\")[-1] == expected)


class EVOUnifiedApp(tk.Tk):
    """Gestor de herramientas con perfiles, navegación y configuración local."""

    SETTINGS_FILE = "EVO_Tools_State.db"
    NAV_BG = "#16283B"
    NAV_ACTIVE = "#277DAD"
    NAV_TEXT = "#F0F6FB"
    MAIN_BG = "#E6E6E6"

    THEMES = {
        "light": {
            "background": "#E6E6E6", "surface": "#E6E6E6", "field": "#FFFFFF",
            "foreground": "#202020", "muted": "#516578", "nav": "#16283B",
            "nav_active": "#277DAD", "nav_text": "#F0F6FB", "nav_muted": "#A3C4D7",
            "button": "#DEDEDE", "button_active": "#CECECE", "border": "#B5B5B5",
            "selection": "#277DAD", "warning": "#9A4D00", "disabled": "#767676",
        },
        "dark": {
            "background": "#303030", "surface": "#303030", "field": "#4A4A4A",
            "foreground": "#F3F3F3", "muted": "#CCCCCC", "nav": "#0D0D0D",
            "nav_active": "#4A4A4A", "nav_text": "#F3F3F3", "nav_muted": "#BDBDBD",
            "button": "#4A4A4A", "button_active": "#303030", "border": "#4A4A4A",
            "selection": "#6D91B4", "warning": "#FFCC85", "disabled": "#B0B0B0",
        },
    }

    def __init__(self):
        super().__init__()
        self.title("EVO Tools | Manager")
        self.geometry("1270x780")
        self.minsize(1060, 640)
        self.configure(background=self.MAIN_BG)

        # sys.executable apunta al .exe final, no a _MEIPASS de PyInstaller.
        self.app_dir = (
            Path(sys.executable).resolve().parent
            if getattr(sys, "frozen", False)
            else Path(__file__).resolve().parent
        )
        self.settings_path = self.app_dir / self.SETTINGS_FILE
        first_open = not self.settings_path.exists()
        self.access_recovery_required = False
        self._policy_corrupted = False
        self._admin_signing_key: Ed25519PrivateKey | None = None
        self._settings_error: str | None = None
        try:
            self.store = PortableState(self.settings_path)
            if first_open:
                self._migrate_visual_preferences_only()
            self.config = self.store.load_preferences()
        except (sqlite3.Error, OSError) as exc:
            # No usar permisos de otro archivo si no se puede verificar el estado.
            self._settings_error = str(exc)
            self.store = None
            self.config = default_settings()
        policy = self._load_verified_policy()
        self.config.update(policy)
        self.theme_name = self.config["theme"]
        self.memes_visible = self.config["memes_visible"]
        self.current_profile: str | None = None
        self.authenticated = False
        self.login_window: tk.Toplevel | None = None
        self.active_section: str | None = None
        self.panels: dict[str, ttk.Frame] = {}
        self.withdraw()  # No mostrar ninguna herramienta hasta pasar la entrada.

        icon_path = self._resource_path("EVO_Tools_Icono.ico")
        if sys.platform == "win32" and icon_path.is_file():
            try:
                self.iconbitmap(str(icon_path))
            except tk.TclError:
                pass

        self.style = ttk.Style(self)
        if "clam" in self.style.theme_names():
            self.style.theme_use("clam")
        self.theme_icons = self._load_theme_icons()
        self._build_shell()
        self._apply_theme()

        self.bind_all("<F1>", lambda _event: self._keyboard_section("vr"))
        self.bind_all("<F2>", lambda _event: self._keyboard_section("bcm"))
        self.bind_all("<F3>", lambda _event: self._keyboard_section("install"))
        self.bind_all("<Shift-F11>", self.toggle_memes)

        self.protocol("WM_DELETE_WINDOW", self._close_manager)
        self.after(0, self._show_login)

    def _close_manager(self):
        if self._active_tasks_running():
            messagebox.showwarning("ODIS activo", "Primero cancela o termina la preparación ODIS.", parent=self)
            return
        self.destroy()

    def _resource_path(self, name: str) -> Path:
        external = self.app_dir / name
        if external.is_file():
            return external
        return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent)) / name

    def _migrate_visual_preferences_only(self):
        """Importa únicamente preferencias sin privilegios desde el JSON anterior.

        Nunca importa permisos, nombres, ni pie de página: esos campos necesitan
        revisión y una firma de Admin para evitar confiar en un archivo editable.
        """
        old_file = self.app_dir / "EVO_Tools_Config.json"
        if not old_file.is_file():
            return
        try:
            if old_file.stat().st_size > 64 * 1024:
                return
            old = json.loads(old_file.read_text(encoding="utf-8"))
            if not isinstance(old, dict):
                return
            prefs = default_settings()
            if old.get("theme") in ("light", "dark"):
                prefs["theme"] = old["theme"]
            if isinstance(old.get("memes_visible"), bool):
                prefs["memes_visible"] = old["memes_visible"]
            if isinstance(old.get("active_profile"), str) and len(old["active_profile"]) <= 32:
                prefs["active_profile"] = old["active_profile"]
            self.store.save_preferences(prefs)
        except (OSError, UnicodeError, ValueError, sqlite3.Error):
            # El JSON viejo no es fiable ni necesario para arrancar.
            return

    def _load_verified_policy(self) -> dict:
        # Sin firma verificable no se habilita ningún perfil común.
        safe = {"profiles": {"Admin": list(APP_CATALOG)},
                "app_labels": {}, "footer_text": DEFAULT_FOOTER,
                "windows_accounts": {}}
        if self.store is None:
            self.access_recovery_required = True
            return safe
        try:
            policy = self.store.read_policy()
            if policy is None:
                self.access_recovery_required = True
                return safe
            return policy
        except (sqlite3.Error, ValueError, OSError, UnicodeError, KeyError, TypeError) as exc:
            print(f"Aviso: política inválida: {exc}", file=sys.stderr)
            self._policy_corrupted = True
            self.access_recovery_required = True
            return safe

    def _save_settings(self, show_error: bool = True) -> bool:
        if self.store is None:
            return False
        try:
            self.store.save_preferences(self.config | {
                "theme": self.theme_name, "memes_visible": self.memes_visible,
            })
            return True
        except (sqlite3.Error, OSError, ValueError) as exc:
            print(f"Aviso: no se pudieron guardar las preferencias: {exc}", file=sys.stderr)
            if show_error:
                messagebox.showwarning("Preferencias", f"No se pudo guardar la configuración:\n{exc}", parent=self)
            return False

    def _save_access_profiles(self, proposed: dict[str, list[str]]) -> bool:
        """Guarda política completa, no solo perfiles; requiere sesión Admin autenticada."""
        bindings = {name: value for name, value in self.config.get("windows_accounts", {}).items()
                    if name in proposed}
        policy = {
            "version": 1, "profiles": proposed,
            "app_labels": self.config.get("app_labels", {}),
            "footer_text": self.config.get("footer_text", DEFAULT_FOOTER),
            "windows_accounts": bindings,
        }
        saved = self._sign_and_save_policy(policy)
        if saved:
            self.config["windows_accounts"] = bindings
        return saved

    def _sign_and_save_policy(self, policy: dict) -> bool:
        if not (self.authenticated and self.current_profile == "Admin"
                and self._admin_signing_key is not None and self.store is not None):
            return False
        try:
            self.store.sign_and_save_policy(policy, self._admin_signing_key)
            return True
        except (sqlite3.Error, OSError, ValueError, InvalidSignature) as exc:
            messagebox.showerror("Política", f"Los cambios NO se han guardado:\n{exc}", parent=self)
            return False

    def _initialize_after_admin_login(self) -> bool:
        """Admin inicializa/recupera el estado que no tenga firma válida."""
        if not self.access_recovery_required:
            return True
        if self.store is None:
            messagebox.showerror(
                "Configuración inaccesible",
                "No se puede acceder al archivo de estado junto al programa. "
                "Comprueba que la carpeta tenga permisos de escritura.", parent=self.login_window)
            return False
        if self._policy_corrupted and not messagebox.askyesno(
            "Recuperar permisos",
            "El estado administrativo no tiene una firma válida.\n\n"
            "¿Restaurar los cuatro perfiles y los ajustes administrativos "
            "iniciales? Se perderán los cambios anteriores.", parent=self.login_window,
        ):
            return False
        policy = default_policy()
        try:
            self.store.sign_and_save_policy(policy, self._admin_signing_key)
        except (sqlite3.Error, OSError, ValueError, InvalidSignature) as exc:
            messagebox.showerror("Inicialización", f"No se pudo inicializar la política:\n{exc}", parent=self.login_window)
            return False
        self.config.update(policy)
        self.access_recovery_required = False
        self._policy_corrupted = False
        return True

    def _get_allowed_apps(self, profile: str | None = None) -> list[str]:
        if not self.authenticated:
            return []
        profile = self.current_profile if profile is None else profile
        if profile == "Admin":
            return list(APP_CATALOG)
        entries = self.config["profiles"].get(profile, [])
        return [key for key in APP_CATALOG if key in entries]

    def _app_title(self, key: str) -> str:
        return self.config["app_labels"].get(key, APP_CATALOG[key]["title"])

    def _can_open(self, section: str) -> bool:
        if not self.authenticated:
            return False
        return ((section == "admin" and self.current_profile == "Admin")
                or section in self._get_allowed_apps())

    def _keyboard_section(self, section: str):
        if self._can_open(section):
            self.show_section(section)
        return "break"

    def _active_tasks_running(self) -> bool:
        return any(hasattr(widget, "can_close") and not widget.can_close()
                   for widget in self.panels.values())

    def _on_profile_selected(self, _event=None):
        if self._active_tasks_running():
            messagebox.showwarning("ODIS activo", "Cancela o termina primero la preparación ODIS.", parent=self)
            return
        self._show_login()

    def _show_login(self):
        """Pantalla de acceso: diseño moderno, con la autorización original intacta."""
        if self._active_tasks_running():
            messagebox.showwarning("ODIS activo", "Finaliza o cancela la preparación antes de cambiar perfil.", parent=self)
            return
        if self.login_window is not None and self.login_window.winfo_exists():
            self.login_window.lift()
            return
        self.authenticated = False
        self.current_profile = None
        self._admin_signing_key = None
        self._close_history_window()
        for widget in self.panels.values():
            widget.destroy()
        self.panels.clear()
        self.active_section = None
        self.withdraw()

        # Paleta exclusiva del login. Los tonos oscuros mantienen los colores
        # solicitados para EVO Tools; no altera el tema del resto del manager.
        login_palettes = {
            "dark": {
                "hero": "#0D0D0D", "panel": "#303030", "field": "#4A4A4A",
                "title": "#F5F5F5", "muted": "#C2C2C2", "line": "#555555",
                "accent": "#477CA9", "accent_hover": "#3D6D95",
                "hero_muted": "#B8B8B8", "error": "#FF9D9D",
            },
            "light": {
                "hero": "#16283B", "panel": "#F5F6F8", "field": "#FFFFFF",
                "title": "#1C2936", "muted": "#647385", "line": "#D5DBE3",
                "accent": "#277DAD", "accent_hover": "#1C638A",
                "hero_muted": "#BBCFDF", "error": "#B33B35",
            },
        }
        palette = login_palettes[self.theme_name]

        dialog = tk.Toplevel(self)
        self.login_window = dialog
        dialog.title("EVO Tools | Acceso")
        width, height = 920, 630
        screen_w, screen_h = dialog.winfo_screenwidth(), dialog.winfo_screenheight()
        dialog.geometry(f"{width}x{height}+{max(0, (screen_w-width)//2)}+{max(0, (screen_h-height)//2)}")
        # Permite maximizar desde Windows, restaurar y redimensionar con el ratón.
        dialog.resizable(True, True)
        dialog.minsize(850, 580)
        dialog.configure(bg=palette["panel"])

        # F11 activa pantalla completa; Escape vuelve a la ventana normal.
        def toggle_login_fullscreen(event=None):
            # Shift+F11 mantiene su función secreta de mostrar/ocultar memes.
            if event is not None and event.state & 0x0001:
                return None
            dialog.attributes("-fullscreen", not bool(dialog.attributes("-fullscreen")))
            return "break"

        def exit_login_fullscreen(_event=None):
            if bool(dialog.attributes("-fullscreen")):
                dialog.attributes("-fullscreen", False)
                return "break"
            return None

        dialog.bind("<F11>", toggle_login_fullscreen)
        dialog.bind("<Escape>", exit_login_fullscreen)
        dialog.protocol("WM_DELETE_WINDOW", self._close_manager)
        icon_path = self._resource_path("EVO_Tools_Icono.ico")
        if sys.platform == "win32" and icon_path.is_file():
            try:
                dialog.iconbitmap(str(icon_path))
            except tk.TclError:
                pass

        # Pie de página compartido con el manager; se actualiza con la
        # personalización definida por Admin en el JSON de preferencias.
        login_footer_bar = tk.Frame(dialog, bg=palette["panel"])
        login_footer_bar.pack(side="bottom", fill="x")
        login_footer_bar.grid_columnconfigure(0, weight=2, uniform="login_columns")
        login_footer_bar.grid_columnconfigure(1, weight=3, uniform="login_columns")
        tk.Frame(login_footer_bar, bg=palette["hero"]).grid(
            row=0, column=0, sticky="nsew")
        login_footer_right = tk.Frame(login_footer_bar, bg=palette["panel"])
        login_footer_right.grid(row=0, column=1, sticky="nsew")
        login_footer = tk.Label(
            login_footer_right, text=self.config["footer_text"],
            bg=palette["panel"], fg=palette["muted"],
            anchor="e", font=("Segoe UI", 9), padx=16, pady=8,
        )
        login_footer.pack(fill="x")

        # Dos zonas que se adaptan cuando se maximiza la ventana.
        content = tk.Frame(dialog, bg=palette["panel"])
        content.pack(side="top", fill="both", expand=True)
        content.grid_columnconfigure(0, weight=2, uniform="login_columns")
        content.grid_columnconfigure(1, weight=3, uniform="login_columns")
        content.grid_rowconfigure(0, weight=1)

        # Identidad visual centrada horizontal y verticalmente.
        hero = tk.Frame(content, bg=palette["hero"])
        hero.grid(row=0, column=0, sticky="nsew")
        identity = tk.Frame(hero, bg=palette["hero"])
        identity.pack(expand=True, padx=18, pady=24)
        symbol = tk.Canvas(identity, width=65, height=65, highlightthickness=0,
                           bd=0, bg=palette["hero"])
        # El icono decorativo se conserva para el futuro, pero queda oculto.
        # symbol.pack(anchor="center")
        symbol.create_oval(2, 2, 62, 62, fill=palette["accent"], outline="")
        # Reutiliza el icono de la aplicación si Pillow está disponible.
        loaded_symbol = False
        if Image is not None and ImageTk is not None and icon_path.is_file():
            try:
                with Image.open(icon_path) as original:
                    logo = ImageOps.contain(original.convert("RGBA"), (49, 49),
                                            method=Image.Resampling.LANCZOS)
                    dialog._login_brand_icon = ImageTk.PhotoImage(logo, master=dialog)
                    symbol.create_image(32, 32, image=dialog._login_brand_icon)
                    loaded_symbol = True
            except (OSError, ValueError, tk.TclError):
                pass
        if not loaded_symbol:
            symbol.create_text(32, 32, text="E", font=("Segoe UI", 27, "bold"),
                               fill="#FFFFFF")

        tk.Label(identity, text="EVO TOOLS", bg=palette["hero"], fg="#FFFFFF",
                 font=("Segoe UI", 21, "bold"), justify="left",
                 anchor="w").pack(anchor="w")
        tk.Frame(identity, bg=palette["accent"], height=3, width=180).pack(
            anchor="w", pady=(18, 24))
        tk.Label(identity, text="Todas tus herramientas.\nUn solo lugar.",
                 bg=palette["hero"], fg="#FFFFFF", font=("Segoe UI", 16, "bold"),
                 justify="left", anchor="w").pack(anchor="w")
        tk.Label(identity, text="Tu espacio de trabajo, organizado\nsegún el perfil que elijas.",
                 bg=palette["hero"], fg=palette["hero_muted"],
                 font=("Segoe UI", 10), justify="left", anchor="w").pack(
                     anchor="w", pady=(15, 0))

        # Panel derecho: formulario sin diálogos anidados de error.
        right = tk.Frame(content, bg=palette["panel"])
        right.grid(row=0, column=1, sticky="nsew")

        # Se puede cambiar el tema incluso antes de autenticarse.
        login_theme_button = tk.Button(
            right, text="Modo claro" if self.theme_name == "dark" else "Modo oscuro",
            bg=palette["field"], fg=palette["title"],
            activebackground=palette["line"], activeforeground=palette["title"],
            font=("Segoe UI", 9, "bold"), relief="flat", bd=0,
            highlightthickness=0, cursor="hand2", padx=15, pady=9,
        )
        login_theme_button.pack(anchor="ne", padx=(0, 26), pady=(22, 0))
        # Mantiene el formulario con una anchura cómoda incluso a pantalla completa.
        body = tk.Frame(right, bg=palette["panel"], width=430, height=455)
        body.pack(expand=True, padx=18, pady=(0, 15))
        body.pack_propagate(False)

        tk.Label(body, text="INICIAR SESIÓN", bg=palette["panel"],
                 fg=palette["accent"], font=("Segoe UI", 9, "bold"),
                 anchor="center").pack(fill="x")
        tk.Label(body, text="Bienvenido de nuevo", bg=palette["panel"],
                 fg=palette["title"], font=("Segoe UI", 23, "bold"),
                 anchor="center").pack(fill="x", pady=(12, 7))
        tk.Label(body, text="Selecciona tu perfil para acceder a EVO Tools.",
                 bg=palette["panel"], fg=palette["muted"],
                 font=("Segoe UI", 10), anchor="center",
                 justify="center").pack(fill="x")

        form = tk.Frame(body, bg=palette["panel"])
        form.pack(fill="x", pady=(35, 0))

        tk.Label(form, text="PERFIL", bg=palette["panel"],
                 fg=palette["title"], font=("Segoe UI", 9, "bold"),
                 anchor="w").pack(fill="x", pady=(0, 9))
        suggestion = self.config.get("active_profile")
        if suggestion not in self.config["profiles"]:
            suggestion = next(iter(self.config["profiles"]))
        selected = tk.StringVar(master=dialog, value=suggestion)

        profile_select = ttk.Combobox(form, state="readonly", textvariable=selected,
                                      values=list(self.config["profiles"]),
                                      style="EVOLogin.TCombobox", font=("Segoe UI", 11))
        profile_select.pack(fill="x")

        # El campo únicamente existe visualmente para los perfiles protegidos.
        credential_area = tk.Frame(form, bg=palette["panel"])
        password_block = tk.Frame(credential_area, bg=palette["panel"])
        password_block.pack(fill="x")
        tk.Label(password_block, text="CONTRASEÑA", bg=palette["panel"],
                 fg=palette["title"], font=("Segoe UI", 9, "bold"),
                 anchor="w").pack(fill="x", pady=(0, 9))
        password_row = tk.Frame(password_block, bg=palette["line"], padx=1, pady=1)
        password_row.pack(fill="x")
        password = tk.StringVar(master=dialog)
        pass_entry = ttk.Entry(password_row, textvariable=password, show="•",
                               font=("Segoe UI", 11))
        pass_entry.configure(style="EVOLogin.TEntry")
        pass_entry.pack(side="left", fill="both", expand=True)
        visible = tk.BooleanVar(master=dialog, value=False)

        def toggle_password():
            visible.set(not visible.get())
            pass_entry.configure(show="" if visible.get() else "•")
            reveal_button.configure(text="Ocultar" if visible.get() else "Mostrar")
            pass_entry.focus_set()

        reveal_button = tk.Button(password_row, text="Mostrar", command=toggle_password,
                                  bg=palette["field"], fg=palette["muted"],
                                  activebackground=palette["field"],
                                  activeforeground=palette["title"],
                                  font=("Segoe UI", 9), relief="flat", bd=0,
                                  cursor="hand2", padx=13)
        reveal_button.pack(side="right", fill="y")

        # Espacio permanente para mensajes: evita que se desplace el botón.
        error_label = tk.Label(form, text="", bg=palette["panel"],
                               fg=palette["error"], font=("Segoe UI", 9),
                               wraplength=450, justify="left", anchor="nw",
                               height=2)
        error_label.pack(fill="x", pady=(0, 7))

        enter_button = ttk.Button(form, text="Entrar", style="EVOLoginPrimary.TButton")
        enter_button.pack(fill="x")
        tk.Label(body, text="Al cambiar de perfil se cerrará la sesión actual.",
                 bg=palette["panel"], fg=palette["muted"],
                 font=("Segoe UI", 9), anchor="center",
                 justify="center").pack(side="bottom", fill="x")
        attempts = {"count": 0, "blocked": False}

        def update_password(_event=None):
            password.set("")
            visible.set(False)
            pass_entry.configure(show="•")
            reveal_button.configure(text="Mostrar")
            error_label.configure(text=(
                "Configuración sin inicializar o alterada. Accede como Admin para restaurarla."
                if self.access_recovery_required else ""
            ))
            if selected.get() == "Admin":
                credential_area.pack(fill="x", pady=(20, 0), before=error_label)
            else:
                credential_area.pack_forget()
            # No quitar el foco del selector: flechas para cambiar y Tab para avanzar.

        def reset_attempts():
            attempts.update(count=0, blocked=False)
            if dialog.winfo_exists():
                error_label.configure(text="")

        def login(_event=None):
            chosen = selected.get()
            if chosen not in self.config["profiles"]:
                error_label.configure(text="Selecciona un perfil válido.")
                return "break"
            if attempts["blocked"]:
                error_label.configure(text="Demasiados intentos. Espera 30 segundos.")
                return "break"
            if chosen != "Admin":
                linked_account = self.config.get("windows_accounts", {}).get(chosen, "")
                if not account_matches(linked_account, current_windows_identity()):
                    error_label.configure(text="Este perfil está asignado a otra cuenta de Windows.")
                    return "break"
            if chosen == "Admin":
                key = admin_signer(password.get())
                if key is None:
                    attempts["count"] += 1
                    password.set("")
                    if attempts["count"] >= 5:
                        attempts["blocked"] = True
                        error_label.configure(text="Demasiados intentos. Espera 30 segundos.")
                        dialog.after(30000, reset_attempts)
                    else:
                        error_label.configure(text="Contraseña incorrecta.")
                    pass_entry.focus_set()
                    return "break"
                self._admin_signing_key = key
                if not self._initialize_after_admin_login():
                    self._admin_signing_key = None
                    return "break"
            password.set("")
            dialog.unbind("<Return>")
            # Cancelar el foco diferido si Entrar se pulsó enseguida.
            dialog.after_cancel(focus_job)
            dialog.destroy()
            self.login_window = None
            self.current_profile = chosen
            self.authenticated = True
            self.config["active_profile"] = chosen
            self._refresh_navigation()
            self._show_first_allowed()
            self._save_settings(show_error=False)
            self.deiconify()
            if sys.platform == "win32":
                try:
                    self.state("zoomed")
                except tk.TclError:
                    pass
            self.lift()
            return "break"

        def cycle_profile(event):
            """Las flechas cambian el perfil sin abrir el desplegable ni perder foco."""
            profiles = list(self.config["profiles"])
            if not profiles:
                return "break"
            try:
                index = profiles.index(selected.get())
            except ValueError:
                index = 0
            step = -1 if event.keysym in ("Up", "Left") else 1
            profile_select.current((index + step) % len(profiles))
            update_password()
            return "break"

        def configure_login_styles():
            self.style.configure(
                "EVOLogin.TCombobox", padding=(12, 8),
                fieldbackground=palette["field"], background=palette["field"],
                foreground=palette["title"], arrowcolor=palette["title"],
                bordercolor=palette["line"], lightcolor=palette["line"],
                darkcolor=palette["line"],
            )
            self.style.map(
                "EVOLogin.TCombobox",
                fieldbackground=[("readonly", palette["field"])],
                foreground=[("readonly", palette["title"])],
                selectbackground=[("readonly", palette["field"])],
                selectforeground=[("readonly", palette["title"])],
            )
            self.style.configure(
                "EVOLogin.TEntry", padding=(10, 9),
                fieldbackground=palette["field"], foreground=palette["title"],
                insertcolor=palette["title"], bordercolor=palette["field"],
                lightcolor=palette["field"], darkcolor=palette["field"],
            )
            self.style.configure(
                "EVOLoginPrimary.TButton", background=palette["accent"],
                foreground="#FFFFFF", font=("Segoe UI", 11, "bold"),
                padding=(20, 12), borderwidth=0, relief="flat",
            )
            self.style.map(
                "EVOLoginPrimary.TButton",
                background=[("active", palette["accent_hover"]),
                            ("pressed", palette["accent_hover"])],
                foreground=[("disabled", "#BBBBBB"), ("!disabled", "#FFFFFF")],
            )

        def change_login_theme():
            nonlocal palette
            old_palette = palette
            self.theme_name = "dark" if self.theme_name == "light" else "light"
            palette = login_palettes[self.theme_name]
            self._apply_theme()  # El manager se abrirá con el mismo tema.
            configure_login_styles()
            # Recolorear los widgets existentes mantiene el perfil, contraseña,
            # mensajes y contador de intentos. No se reconstruye el diálogo.
            bg_mapping = {
                old_palette[key].lower(): palette[key] for key in old_palette
            }
            # El blanco de la marca es un color fijo. No hay que confundirlo
            # con el blanco del campo de entrada del tema claro.
            fg_mapping = {
                old_palette[key].lower(): palette[key]
                for key in ("title", "muted", "hero_muted", "error", "accent")
            }
            for widget in (dialog, *self._walk_widgets(dialog)):
                if isinstance(widget, ttk.Widget):
                    continue
                for option in ("background", "foreground",
                               "activebackground", "activeforeground"):
                    try:
                        old_color = str(widget.cget(option)).lower()
                    except tk.TclError:
                        continue
                    mapping = (bg_mapping if option.endswith("background")
                               else fg_mapping)
                    if old_color in mapping:
                        widget.configure(**{option: mapping[old_color]})
            symbol.itemconfigure(1, fill=palette["accent"])
            login_theme_button.configure(
                text="Modo claro" if self.theme_name == "dark" else "Modo oscuro"
            )
            self._save_settings(show_error=False)

        profile_select.bind("<<ComboboxSelected>>", update_password)
        for key in ("<Up>", "<Down>", "<Left>", "<Right>"):
            profile_select.bind(key, cycle_profile)
        enter_button.configure(command=login)
        login_theme_button.configure(command=change_login_theme)
        configure_login_styles()
        dialog.bind("<Return>", login)
        update_password()
        dialog.lift()
        # Siempre empieza en el selector, incluso si quedó Admin seleccionado.
        focus_job = dialog.after(
            100,
            lambda: profile_select.focus_force() if dialog.winfo_exists() else None,
        )

    def _refresh_navigation(self):
        if not self.authenticated:
            return
        self.profile_var.set(self.current_profile)
        for button in self.nav_buttons.values():
            button.destroy()
        self.nav_buttons.clear()
        for key in self._get_allowed_apps():
            self._make_nav_button(key, f"{APP_CATALOG[key]['menu']}  {self._app_title(key)}")
        if self.current_profile == "Admin":
            self._make_nav_button("admin", "⚙  Administración")
        if not self.nav_buttons:
            self.nav_empty.configure(text="Sin herramientas asignadas.")
            self.nav_empty.pack(fill="x", padx=16, pady=8)
        else:
            self.nav_empty.pack_forget()
        self._refresh_nav_colors()

    def _make_nav_button(self, key: str, title: str):
        button = tk.Button(
            self.nav_container, text=title,
            font=("Segoe UI", 11), fg=self.NAV_TEXT, bg=self.NAV_BG,
            activeforeground="#FFFFFF", activebackground=self.NAV_ACTIVE,
            relief="flat", bd=0, padx=16, pady=13, anchor="w",
            cursor="hand2", command=lambda selected=key: self.show_section(selected),
            wraplength=194, justify="left",
        )
        button.pack(fill="x", padx=(0, 7), pady=(0, 3))
        self.nav_buttons[key] = button

    def _show_first_allowed(self):
        available = self._get_allowed_apps()
        if available:
            self.show_section(available[0])
        elif self.current_profile == "Admin":
            self.show_section("admin")
        else:
            self._show_empty_page()

    def _show_empty_page(self):
        for panel in self.panels.values():
            panel.pack_forget()
        self.active_section = None
        self.page_title.configure(text="Sin herramientas")
        self.page_subtitle.configure(text="Contacta con Admin para habilitar alguna aplicación.")
        self._refresh_nav_colors()

    def show_section(self, section: str):
        if not self._can_open(section):
            return False
        if section != self.active_section:
            self._close_history_window()
        if self.active_section in self.panels:
            self.panels[self.active_section].pack_forget()
        if section not in self.panels:
            if section == "admin":
                self.panels[section] = self._build_admin_panel()
            else:
                self.panels[section] = APP_CATALOG[section]["panel"](self.work_area)
                self._style_panel(self.panels[section], self.THEMES[self.theme_name])
        self.panels[section].pack(fill="both", expand=True)
        self.active_section = section
        if section == "admin":
            self.page_title.configure(text="Administración")
            self.page_subtitle.configure(text="Perfiles, visibilidad de aplicaciones y opciones del manager")
        else:
            self.page_title.configure(text=self._app_title(section))
            self.page_subtitle.configure(text=APP_CATALOG[section]["subtitle"])
        self._refresh_nav_colors()
        return True

    def _refresh_nav_colors(self):
        colors = self.THEMES[self.theme_name]
        for key, button in self.nav_buttons.items():
            selected = key == self.active_section
            button.configure(
                bg=colors["nav_active"] if selected else colors["nav"],
                fg=colors["nav_text"], activebackground=colors["nav_active"],
                activeforeground=colors["nav_text"],
                font=("Segoe UI", 11, "bold" if selected else "normal"),
            )

    def _build_shell(self):
        self.sidebar = tk.Frame(self, bg=self.NAV_BG, width=238)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        self.brand_label = tk.Label(
            self.sidebar, text="EVO TOOLS", font=("Segoe UI", 17, "bold"),
            fg="#FFFFFF", bg=self.NAV_BG, anchor="w", padx=16, pady=22,
        )
        self.brand_label.pack(fill="x")
        self.profile_heading = tk.Label(
            self.sidebar, text="PERFIL ACTIVO", font=("Segoe UI", 9, "bold"),
            fg="#A3C4D7", bg=self.NAV_BG, anchor="w", padx=16, pady=4,
        )
        self.profile_heading.pack(fill="x")
        self.profile_var = tk.StringVar(master=self, value="")
        ttk.Label(self.sidebar, textvariable=self.profile_var,
                  style="EVOProfile.TLabel", anchor="w").pack(fill="x", padx=16)
        self.profile_box = ttk.Button(self.sidebar, text="Cambiar perfil...",
                                      command=self._on_profile_selected)
        self.profile_box.pack(fill="x", padx=14, pady=(10, 18))

        self.nav_heading = tk.Label(
            self.sidebar, text="HERRAMIENTAS", font=("Segoe UI", 9, "bold"),
            fg="#A3C4D7", bg=self.NAV_BG, anchor="w", padx=16, pady=10,
        )
        self.nav_heading.pack(fill="x")
        self.nav_container = tk.Frame(self.sidebar, bg=self.NAV_BG)
        self.nav_container.pack(fill="x")
        self.nav_buttons: dict[str, tk.Button] = {}
        self.nav_empty = tk.Label(
            self.nav_container, text="", font=("Segoe UI", 9), justify="left",
            anchor="w", bg=self.NAV_BG, fg="#A3C4D7",
        )
        self.nav_footer = tk.Label(
            self.sidebar, text="F1 · VRs   F2 · ECU   F3 · ODIS",
            font=("Segoe UI", 9), fg="#9AB6C9", bg=self.NAV_BG,
            justify="left", anchor="sw", padx=16, pady=18,
        )
        self.nav_footer.pack(side="bottom", fill="x")

        main = ttk.Frame(self, style="EVO.TFrame")
        main.pack(side="left", fill="both", expand=True)
        header = ttk.Frame(main, style="EVO.TFrame", padding=(16, 16, 16, 8))
        header.pack(fill="x")
        self.theme_button = tk.Button(
            header, command=self.toggle_theme, font=("Segoe UI", 10, "bold"),
            relief="flat", cursor="hand2", padx=14, pady=9,
        )
        self.theme_button.pack(side="right", anchor="ne", padx=(12, 0))
        self.theme_image_label = tk.Label(
            header, borderwidth=0, padx=0, pady=0, cursor="hand2"
        )
        self.theme_image_label.bind("<Button-1>", lambda _event: self.toggle_theme())
        self.page_title = ttk.Label(header, style="EVOTitle.TLabel")
        self.page_title.pack(anchor="w")
        self.page_subtitle = ttk.Label(header, style="EVOSubtitle.TLabel")
        self.page_subtitle.pack(anchor="w", pady=(3, 0))

        self.footer = ttk.Label(
            main, text=self.config["footer_text"], style="EVO.TLabel",
            anchor="e", padding=(16, 8), font=("Segoe UI", 9),
        )
        self.footer.pack(side="bottom", fill="x")

        # Un botón común que muestra el historial de la sección activa.
        # Se sitúa encima del pie de página, en la esquina inferior derecha.
        self.history_bar = ttk.Frame(main, style="EVO.TFrame", padding=(16, 0, 16, 4))
        self.history_bar.pack(side="bottom", fill="x")
        self.history_button = ttk.Button(
            self.history_bar, text="Historial de cambios",
            style="EVOHistory.TButton", command=self.show_active_changelog,
        )
        self.history_button.pack(side="right")
        self._history_window = None
        self._history_text = None
        self.work_area = ttk.Frame(main, style="EVO.TFrame")
        self.work_area.pack(side="top", fill="both", expand=True)

    def _close_history_window(self):
        win = getattr(self, "_history_window", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.destroy()
            except tk.TclError:
                pass
        self._history_window = None
        self._history_text = None

    def _refresh_history_theme(self):
        win = getattr(self, "_history_window", None)
        text_widget = getattr(self, "_history_text", None)
        if win is None or text_widget is None or not win.winfo_exists():
            return
        colors = self.THEMES[self.theme_name]
        win.configure(background=colors["background"])
        text_widget.configure(
            background=colors["field"], foreground=colors["foreground"],
            selectbackground=colors["selection"], selectforeground="#FFFFFF",
            highlightbackground=colors["border"], insertbackground=colors["foreground"],
        )
        text_widget.tag_configure("entry_title", foreground=colors["foreground"])
        text_widget.tag_configure("entry_body", foreground=colors["muted"])

    def show_active_changelog(self):
        """Consulta informativa; nunca abre el historial al entrar a una herramienta."""
        if not self.authenticated:
            return
        section = self.active_section
        if section not in TOOL_CHANGELOGS or not self._can_open(section):
            return

        self._close_history_window()
        title, subtitle, entries = TOOL_CHANGELOGS[section]
        win = tk.Toplevel(self)
        self._history_window = win
        win.title(f"Historial de cambios · {title}")
        win.geometry("760x530")
        win.minsize(540, 350)
        win.transient(self)
        win.protocol("WM_DELETE_WINDOW", self._close_history_window)
        win.bind("<Escape>", lambda _event: self._close_history_window())

        header = ttk.Frame(win, padding=(20, 18, 20, 10))
        header.pack(fill="x")
        ttk.Label(header, text=title, style="EVOTitle.TLabel").pack(anchor="w")
        ttk.Label(header, text=subtitle, style="EVOSubtitle.TLabel").pack(anchor="w", pady=(3, 0))
        body = ttk.Frame(win, padding=(20, 0, 20, 12))
        body.pack(fill="both", expand=True)
        scrollbar = ttk.Scrollbar(body, orient="vertical")
        view = tk.Text(
            body, wrap="word", font=("Segoe UI", 10), relief="flat",
            borderwidth=0, padx=14, pady=12, spacing1=3, spacing3=9,
            yscrollcommand=scrollbar.set, cursor="arrow",
        )
        self._history_text = view
        scrollbar.configure(command=view.yview)
        scrollbar.pack(side="right", fill="y")
        view.pack(side="left", fill="both", expand=True)

        for label, description in entries:
            view.insert("end", f"{label}\n", "entry_title")
            view.insert("end", f"{description}\n\n", "entry_body")
        view.configure(state="disabled")
        actions = ttk.Frame(win, padding=(20, 0, 20, 16))
        actions.pack(fill="x")
        ttk.Button(actions, text="Cerrar", command=self._close_history_window).pack(side="right")
        self._refresh_history_theme()
        win.lift()
        win.focus_set()

    def _load_theme_icons(self):
        icons = {}
        if Image is None:
            return icons
        for mode, filename in {
            "dark": "EVO_Modo_Claro_LeBron.jpeg",
            "light": "EVO_Modo_Oscuro_Golem.jpeg",
        }.items():
            path = self._resource_path(filename)
            if not path.is_file():
                continue
            try:
                with Image.open(path) as original:
                    thumbnail = ImageOps.contain(
                        original.convert("RGB"), (34, 34),
                        method=Image.Resampling.LANCZOS,
                    )
                    icons[mode] = ImageTk.PhotoImage(thumbnail, master=self)
            except (OSError, ValueError, tk.TclError) as exc:
                print(f"Aviso: no se pudo cargar {filename}: {exc}", file=sys.stderr)
        return icons

    def toggle_theme(self):
        self.theme_name = "dark" if self.theme_name == "light" else "light"
        self._apply_theme()
        self._save_settings()

    def toggle_memes(self, _event=None):
        self.memes_visible = not self.memes_visible
        self._refresh_meme_visibility()
        self._save_settings()
        return "break"

    def _refresh_meme_visibility(self):
        if self.memes_visible and self.theme_icons:
            self.theme_image_label.pack(
                side="right", anchor="ne", padx=(0, 6), pady=5,
                after=self.theme_button,
            )
        else:
            self.theme_image_label.pack_forget()

    def _apply_theme(self):
        colors = self.THEMES[self.theme_name]
        self.configure(background=colors["background"])
        self._configure_style(colors)
        self.sidebar.configure(bg=colors["nav"])
        self.nav_container.configure(bg=colors["nav"])
        for label in (
            self.brand_label, self.profile_heading, self.nav_heading, self.nav_footer,
            self.nav_empty,
        ):
            label.configure(
                bg=colors["nav"],
                fg=colors["nav_text"] if label is self.brand_label else colors["nav_muted"],
            )
        self.theme_button.configure(
            text="Modo claro" if self.theme_name == "dark" else "Modo oscuro",
            bg=colors["button"], fg=colors["foreground"],
            activebackground=colors["button_active"],
            activeforeground=colors["foreground"],
            highlightbackground=colors["background"],
        )
        self.theme_image_label.configure(
            image=self.theme_icons.get("light" if self.theme_name == "dark" else "dark", ""),
            background=colors["background"],
        )
        self._refresh_meme_visibility()
        self._refresh_nav_colors()
        for panel in self.panels.values():
            self._style_panel(panel, colors)
        self._refresh_history_theme()

    def _style_panel(self, panel: ttk.Frame, colors: dict[str, str]):
        for widget in self._walk_widgets(panel):
            if isinstance(widget, tk.Text):
                widget.configure(
                    background=colors["field"], foreground=colors["foreground"],
                    insertbackground=colors["foreground"],
                    selectbackground=colors["selection"], selectforeground="#FFFFFF",
                    highlightbackground=colors["border"],
                )
            elif isinstance(widget, ttk.Label):
                current_fg = str(widget.cget("foreground")).lower()
                if current_fg in {"#9a4d00", "#ffcc85"}:
                    widget.configure(foreground=colors["warning"])

    @staticmethod
    def _walk_widgets(parent: tk.Misc):
        for child in parent.winfo_children():
            yield child
            yield from EVOUnifiedApp._walk_widgets(child)

    def _build_admin_panel(self) -> ttk.Frame:
        """Administrador de acceso visible y opciones del gestor."""
        if not self.authenticated or self.current_profile != "Admin":
            raise PermissionError("Solo Admin puede editar perfiles.")
        panel = ttk.Frame(self.work_area, style="EVO.TFrame", padding=16)
        self.admin_permission_vars = {}
        self.admin_title_vars = {}
        self.admin_windows_vars = {}

        box = ttk.LabelFrame(panel, text="Permisos por perfil", padding=12)
        box.pack(fill="x", pady=(0, 12))
        ttk.Label(box, text="Perfil", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, padx=8, sticky="w")
        for column, key in enumerate(APP_CATALOG, start=1):
            ttk.Label(box, text=self._app_title(key), font=("Segoe UI", 10, "bold")).grid(
                row=0, column=column, padx=14, sticky="w")
        ttk.Label(box, text="Usuario Windows (opcional)", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=len(APP_CATALOG) + 1, padx=14, sticky="w")
        for r, (name, apps) in enumerate(self.config["profiles"].items(), start=1):
            ttk.Label(box, text=name).grid(row=r, column=0, padx=8, pady=5, sticky="w")
            account_var = tk.StringVar(master=panel, value=self.config.get("windows_accounts", {}).get(name, ""))
            self.admin_windows_vars[name] = account_var
            if name != "Admin":
                ttk.Entry(box, textvariable=account_var, width=22).grid(
                    row=r, column=len(APP_CATALOG) + 1, padx=14, pady=5, sticky="w")
            self.admin_permission_vars[name] = {}
            for c, key in enumerate(APP_CATALOG, start=1):
                variable = tk.BooleanVar(master=panel, value=(name == "Admin" or key in apps))
                self.admin_permission_vars[name][key] = variable
                ttk.Checkbutton(
                    box, variable=variable,
                    state="disabled" if name == "Admin" else "normal",
                ).grid(row=r, column=c, padx=14, pady=5, sticky="w")

        actions = ttk.Frame(panel)
        actions.pack(fill="x", pady=(0, 12))
        ttk.Button(actions, text="Añadir perfil", command=self._admin_add_profile).pack(
            side="left", padx=(0, 8))
        ttk.Button(actions, text="Eliminar perfil", command=self._admin_remove_profile).pack(
            side="left")
        ttk.Button(actions, text="Restaurar perfiles iniciales",
                   command=self._admin_restore_defaults).pack(side="left", padx=(8, 0))

        config_box = ttk.LabelFrame(panel, text="Personalización del manager", padding=12)
        config_box.pack(fill="x", pady=(0, 12))
        for index, key in enumerate(APP_CATALOG):
            ttk.Label(config_box, text=f"Nombre · {APP_CATALOG[key]['title']}:").grid(
                row=index, column=0, sticky="w", padx=(0, 8), pady=4)
            namevar = tk.StringVar(master=panel, value=self._app_title(key))
            self.admin_title_vars[key] = namevar
            ttk.Entry(config_box, textvariable=namevar, width=48).grid(
                row=index, column=1, sticky="ew", pady=4)
        ttk.Label(config_box, text="Pie de página:").grid(
            row=len(APP_CATALOG), column=0, sticky="w", padx=(0, 8), pady=4)
        self.admin_footer_var = tk.StringVar(master=panel, value=self.config["footer_text"])
        ttk.Entry(config_box, textvariable=self.admin_footer_var, width=48).grid(
            row=len(APP_CATALOG), column=1, sticky="ew", pady=4)
        config_box.columnconfigure(1, weight=1)

        ttk.Button(panel, text="Guardar cambios", command=self._admin_save).pack(anchor="e")
        ttk.Label(
            panel,
            text="Los permisos, los nombres y el pie se guardan firmados. Vincular perfiles a usuarios Windows es opcional.",
            style="EVO.TLabel", wraplength=750, justify="left",
        ).pack(fill="x", pady=(18, 0))
        return panel

    def _rebuild_admin_panel(self):
        old = self.panels.pop("admin", None)
        if old is not None:
            old.destroy()
        self.active_section = None
        self.show_section("admin")

    def _admin_save(self, quiet: bool = False):
        if not self.authenticated or self.current_profile != "Admin":
            return False
        titles = {}
        for key, var in self.admin_title_vars.items():
            title = var.get().strip()
            if not 1 <= len(title) <= 48:
                messagebox.showerror("Nombre no válido", f"El nombre de {key} debe tener 1-48 caracteres.", parent=self)
                return False
            if title != APP_CATALOG[key]["title"]:
                titles[key] = title
        proposed = {name: ([key for key in APP_CATALOG if self.admin_permission_vars[name][key].get()]
                           if name != "Admin" else list(APP_CATALOG))
                    for name in self.config["profiles"]}
        links = {name: var.get().strip() for name, var in self.admin_windows_vars.items()
                 if name != "Admin" and var.get().strip()}
        policy = {"version": 1, "profiles": proposed, "app_labels": titles,
                  "footer_text": self.admin_footer_var.get()[:200],
                  "windows_accounts": links}
        if not self._sign_and_save_policy(policy):
            return False
        self.config.update(validate_policy(policy))
        self.footer.configure(text=self.config["footer_text"])
        self._refresh_navigation()
        self._rebuild_admin_panel()
        if not quiet:
            messagebox.showinfo("EVO Tools", "Permisos y personalización firmados y guardados.", parent=self)
        return True

    def _admin_add_profile(self):
        if not self.authenticated or self.current_profile != "Admin":
            return
        if not self._admin_save(quiet=True):
            return
        name = simpledialog.askstring("Nuevo perfil", "Nombre del nuevo perfil:", parent=self)
        if name is None:
            return
        name = name.strip()
        if not 1 <= len(name) <= 32 or name.casefold() == "admin":
            messagebox.showerror("Nombre no válido", "Usa un nombre de entre 1 y 32 caracteres.", parent=self)
            return
        if any(item.casefold() == name.casefold() for item in self.config["profiles"]):
            messagebox.showerror("Perfil duplicado", "Ya existe un perfil con ese nombre.", parent=self)
            return
        proposed = dict(self.config["profiles"])
        proposed[name] = []
        if not self._save_access_profiles(proposed):
            return
        self.config["profiles"] = proposed
        self._refresh_navigation()
        self._rebuild_admin_panel()
        messagebox.showinfo("Perfil añadido", "Perfil creado sin herramientas. Marca sus permisos y guarda.", parent=self)

    def _admin_remove_profile(self):
        if not self.authenticated or self.current_profile != "Admin":
            return
        if not self._admin_save(quiet=True):
            return
        options = [p for p in self.config["profiles"] if p != "Admin"]
        if not options:
            return
        name = simpledialog.askstring(
            "Eliminar perfil", "Escribe exactamente el nombre del perfil que quieres eliminar:\n"
            + ", ".join(options), parent=self)
        if name is None:
            return
        if name not in options:
            messagebox.showerror("Perfil no encontrado", "El nombre no coincide con ningún perfil eliminable.", parent=self)
            return
        if not messagebox.askyesno("Confirmar eliminación", f"¿Eliminar el perfil '{name}'?", parent=self):
            return
        proposed = dict(self.config["profiles"])
        del proposed[name]
        if not self._save_access_profiles(proposed):
            return
        self.config["profiles"] = proposed
        self._refresh_navigation()
        self._rebuild_admin_panel()

    def _admin_restore_defaults(self):
        if not self.authenticated or self.current_profile != "Admin":
            return
        if not messagebox.askyesno(
            "Restaurar perfiles",
            "¿Restaurar Paula, Polichu, Eloi y Admin con sus permisos iniciales?\n"
            "Se perderán los perfiles y permisos personalizados.", parent=self,
        ):
            return
        policy = default_policy()
        if not self._sign_and_save_policy(policy):
            return
        self.config.update(policy)
        self.access_recovery_required = False
        self._refresh_navigation()
        self._rebuild_admin_panel()

    def _configure_style(self, colors: dict[str, str]):
        """Actualiza los estilos globales de ttk, incluidos inputs y listas."""
        style = self.style
        bg = colors["background"]
        surface = colors["surface"]
        field = colors["field"]
        fg = colors["foreground"]
        border = colors["border"]
        button = colors["button"]
        hover = colors["button_active"]

        style.configure("TFrame", background=surface)
        style.configure("TLabel", background=surface, foreground=fg)
        style.configure(
            "TLabelframe",
            background=surface,
            bordercolor=border,
            lightcolor=border,
            darkcolor=border,
        )
        style.configure(
            "TLabelframe.Label", background=surface, foreground=fg
        )
        style.configure(
            "TButton",
            background=button,
            foreground=fg,
            bordercolor=border,
            lightcolor=border,
            darkcolor=border,
            padding=(8, 4),
        )
        style.map(
            "TButton",
            background=[("pressed", hover), ("active", hover)],
            foreground=[("disabled", colors["disabled"]), ("!disabled", fg)],
        )
        # Acción secundaria, discreta respecto a los botones operativos.
        style.configure(
            "EVOHistory.TButton",
            background=surface, foreground=colors["muted"],
            bordercolor=border, padding=(11, 5),
            font=("Segoe UI", 9),
        )
        style.map(
            "EVOHistory.TButton",
            background=[("active", button), ("pressed", hover)],
            foreground=[("disabled", colors["disabled"]), ("!disabled", fg)],
        )
        style.configure(
            "TEntry",
            fieldbackground=field,
            foreground=fg,
            insertcolor=fg,
            bordercolor=border,
            lightcolor=border,
            darkcolor=border,
        )
        style.map(
            "TEntry",
            fieldbackground=[("disabled", surface), ("readonly", field)],
            foreground=[("disabled", colors["disabled"])],
        )
        style.configure(
            "TCombobox",
            fieldbackground=field,
            background=button,
            foreground=fg,
            arrowcolor=fg,
            selectbackground=field,
            selectforeground=fg,
            bordercolor=border,
            lightcolor=border,
            darkcolor=border,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", field), ("disabled", surface)],
            foreground=[("readonly", fg), ("disabled", colors["disabled"])],
            selectbackground=[("readonly", field)],
            selectforeground=[("readonly", fg)],
            background=[("active", button), ("readonly", button)],
            arrowcolor=[("disabled", colors["disabled"]), ("!disabled", fg)],
        )
        style.configure(
            "TScrollbar",
            background=button,
            troughcolor=surface,
            arrowcolor=fg,
            bordercolor=border,
        )
        style.map("TScrollbar", background=[("active", hover)])
        style.configure("TCheckbutton", background=surface, foreground=fg)
        style.configure("TRadiobutton", background=surface, foreground=fg)
        style.configure("EVOProfile.TLabel", background=colors["nav"], foreground=colors["nav_text"],
                        font=("Segoe UI", 12, "bold"))
        style.configure("EVO.TFrame", background=bg)
        style.configure("EVO.TLabel", background=bg, foreground=fg)
        style.configure(
            "EVOTitle.TLabel",
            background=bg,
            foreground=fg,
            font=("Segoe UI", 19, "bold"),
        )
        style.configure(
            "EVOSubtitle.TLabel",
            background=bg,
            foreground=colors["muted"],
            font=("Segoe UI", 10),
        )

        # Tk usa un Listbox en el menú desplegable interno del Combobox.
        self.option_add("*TCombobox*Listbox.background", field)
        self.option_add("*TCombobox*Listbox.foreground", fg)
        self.option_add("*TCombobox*Listbox.selectBackground", colors["selection"])
        self.option_add("*TCombobox*Listbox.selectForeground", "#FFFFFF")


if __name__ == "__main__":
    if sys.platform == "win32":
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "EVOTools.ControlVRs.BCM"
        )
    EVOUnifiedApp().mainloop()

