from __future__ import annotations

import copy
import html
import os
import shutil
import tempfile
import re
import traceback
from dataclasses import dataclass
from datetime import datetime
from email import policy
from email.parser import BytesParser
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from uuid import uuid4
from zipfile import ZipFile

from bs4 import BeautifulSoup
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, range_boundaries


# -----------------------------------------------------------------------------
# Configuracion
# -----------------------------------------------------------------------------
PROJECTS = {
    "57S": {"model": "Terramar", "sheet_tokens": ("57S", "Terramar")},
    "5FF": {"model": "Formentor", "sheet_tokens": ("5FF", "Formentor")},
    "5FN": {"model": "Leon", "sheet_tokens": ("5FN", "Leon")},
}
MODEL_TO_PROJECT = {cfg["model"]: code for code, cfg in PROJECTS.items()}
# Identificadores exactos de la columna "Affected ECU". No usar coincidencias
# parciales: "0019" no debe confundirse con "00019" ni "GW" con otros nombres.
ECU_ALIASES = {
    "BCM": frozenset(("BCM", "0009")),
    "Gateway": frozenset(("GW", "GATEWAY", "0019")),
}
ECU_TYPES = tuple(ECU_ALIASES)
EXCEL_COLUMNS = {
    "zdc": 1,
    "rdid": 2,
    "vr": 3,
    "zdc_created": 4,
    "zdc_released": 5,
    "change_ok": 6,
    "requester": 7,
    "email_subject": 8,
    "problem": 9,
    "impact": 10,
    "solution": 11,
    "function_id": 12,
    "homologation": 13,
}

# Cabeceras equivalentes del correo. Se identifican por nombre, no por posicion.
HEADER_ALIASES = {
    "number": ("number", "no", "nr", "change number"),
    "ecu": ("affected ecu", "ecu"),
    "change_type": ("type of change", "change type", "type"),
    "rdid": ("rdid",),
    "problem": ("problem", "problem description"),
    "impact": ("impact",),
    "solution": ("solution",),
    "project": ("project", "project code"),
    "function_id": ("function id", "functionid", "function identifier"),
    "homologation": ("homologation",),
    "un_r": ("un r", "un r regulation", "unr"),
}


@dataclass(frozen=True)
class Change:
    number: str
    ecu: str
    change_type: str
    rdid: str
    problem: str
    impact: str
    solution: str
    project: str
    function_id: str
    homologation: str
    un_r: str


@dataclass
class EmailData:
    subject: str
    pv: str
    vr: str
    changes: list[Change]
    ignored_ecus: tuple[str, ...] = ()


# -----------------------------------------------------------------------------
# Utilidades de texto y privacidad
# -----------------------------------------------------------------------------
def clean_text(value: str | None) -> str:
    if value is None:
        return ""
    value = html.unescape(str(value)).replace("\xa0", " ")
    value = value.replace("\\-", "-").replace("\\_", "_")
    value = value.replace("\\---", "---")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r" *\n *", "\n", value)
    return value.strip()


def normalize_rdid(value: object) -> str:
    text = clean_text(str(value) if value is not None else "").upper()
    if re.fullmatch(r"\d+\.0", text):
        text = text[:-2]
    return text


def classify_ecu(value: object) -> str | None:
    """Interpreta BCM/0009 y Gateway/GW/0019 sin falsos positivos.

    Si una celda menciona las dos ECUs no se puede decidir a cuál pertenece
    el RDID: detener la lectura es más seguro que escribirlo en el Excel erróneo.
    """
    tokens = set(re.findall(r"[A-Z0-9]+", clean_text(value).upper()))
    matches = [kind for kind, aliases in ECU_ALIASES.items() if tokens & aliases]
    if len(matches) > 1:
        raise ValueError(
            f"Identificacion de ECU ambigua en el EML: {value!r} "
            "(coincide con BCM y Gateway)."
        )
    return matches[0] if matches else None


def changes_for_ecu(data: EmailData, ecu_type: str) -> list[Change]:
    if ecu_type not in ECU_TYPES:
        raise ValueError(f"ECU no valida: {ecu_type!r}.")
    selected = [change for change in data.changes if change.ecu == ecu_type]
    if not selected:
        found = ", ".join(sorted({change.ecu for change in data.changes})) or "ninguna"
        raise ValueError(
            f"El EML no contiene cambios de {ecu_type}. "
            f"ECUs reconocidas en el correo: {found}."
        )
    return selected


def normalize_vr(value: object) -> str:
    text = clean_text(str(value) if value is not None else "").upper()
    text = re.sub(r"^VR", "", text).strip()
    if re.fullmatch(r"\d+\.0", text):
        text = text[:-2]
    if text.isdigit():
        text = str(int(text))
    return text


def normalize_pv(value: object) -> str:
    value = clean_text(str(value) if value is not None else "").upper().replace(" ", "")
    value = value.replace(",", ".")
    if not re.fullmatch(r"PV\d+(?:\.\d+)?", value):
        raise ValueError(f"PV no valida: {value!r}. Usa un formato como PV9 o PV7.1.")
    return value


def set_text_cell(ws, row: int, col: int, value: str | None) -> bool:
    """Escribe texto literal, incluso cuando comienza por = (sin formula Excel)."""
    cell = ws.cell(row, col)
    normalized = None if value is None else str(value)
    if cell.value == normalized and cell.data_type != "f":
        return False
    cell.value = normalized
    if normalized is not None:
        cell.data_type = "s"
    return True


def header_key(value: str) -> str | None:
    normalized = re.sub(r"[^a-z0-9]+", " ", clean_text(value).lower()).strip()
    for key, aliases in HEADER_ALIASES.items():
        if normalized in aliases or any(
            len(alias) >= 4 and normalized.startswith(alias + " ") for alias in aliases
        ):
            return key
    return None


def table_column_index(cells) -> dict[str, int]:
    result = {}
    for position, cell in enumerate(cells):
        key = header_key(cell.get_text(" ", strip=True))
        if key:
            if key in result:
                raise ValueError(f"Cabecera duplicada en el correo: {key}.")
            result[key] = position
    return result


def safe_subject(subject: str) -> str:
    """Conserva el asunto tecnico. No lee ni expone From, To, Cc o firmas."""
    return clean_text(subject)


# -----------------------------------------------------------------------------
# Lectura del EML
# -----------------------------------------------------------------------------
def read_eml(path: str | Path) -> EmailData:
    path = Path(path)
    with path.open("rb") as fh:
        message = BytesParser(policy=policy.default).parse(fh)

    subject = safe_subject(str(message.get("subject", "")))
    html_parts: list[str] = []
    text_parts: list[str] = []

    for part in message.walk():
        if part.get_content_disposition() == "attachment":
            continue
        content_type = part.get_content_type()
        if content_type not in ("text/html", "text/plain"):
            continue
        try:
            content = part.get_content()
        except Exception:
            payload = part.get_payload(decode=True) or b""
            content = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
        if content_type == "text/html":
            html_parts.append(str(content))
        else:
            text_parts.append(str(content))

    # El asunto tiene prioridad: los correos reenviados pueden citar VR antiguas.
    fallback_text = "\n".join([*text_parts, *(
        BeautifulSoup(body, "html.parser").get_text(" ", strip=True) for body in html_parts
    )])
    pv_pattern = r"\bPV\s*(\d+(?:[.,]\d+)?)\b"
    vr_pattern = r"\bVR\s*(\d{1,3})\b"
    pv_match = re.search(pv_pattern, subject, re.I) or re.search(pv_pattern, fallback_text, re.I)
    vr_match = re.search(vr_pattern, subject, re.I) or re.search(vr_pattern, fallback_text, re.I)
    pv = normalize_pv("PV" + pv_match.group(1)) if pv_match else ""
    vr = normalize_vr(vr_match.group(1)) if vr_match else ""

    changes: list[Change] = []
    seen: dict[tuple[str, str, str], Change] = {}
    ignored_ecus: set[str] = set()

    for html_body in html_parts:
        soup = BeautifulSoup(html_body, "html.parser")
        for table in soup.find_all("table"):
            rows = table.find_all("tr")
            if len(rows) < 2:
                continue
            header_index = None
            columns = {}
            for i, row in enumerate(rows[:8]):
                possible = table_column_index(row.find_all(["th", "td"], recursive=False))
                required = {
                    "ecu", "rdid", "solution", "project", "problem", "impact",
                    "function_id", "homologation",
                }
                if required.issubset(possible):
                    header_index, columns = i, possible
                    break
            if header_index is None:
                continue

            for row in rows[header_index + 1:]:
                cells = row.find_all(["th", "td"], recursive=False)
                if not cells or all(not cell.get_text(" ", strip=True) for cell in cells):
                    continue
                if max(columns.values()) >= len(cells):
                    raise ValueError("Una fila del correo tiene menos columnas que su cabecera.")
                values = {
                    key: clean_text(cells[pos].get_text("\n", strip=True))
                    for key, pos in columns.items()
                }
                number = values.get("number", "")
                ecu = values.get("ecu", "")
                change_type = values.get("change_type", "")
                rdid = values["rdid"]
                problem = values.get("problem", "")
                impact = values.get("impact", "")
                solution = values["solution"]
                project = values["project"]
                function_id = values.get("function_id", "")
                homologation = values.get("homologation", "")
                un_r = values.get("un_r", "")
                project = project.upper().strip()
                rdid = normalize_rdid(rdid)
                if project not in PROJECTS or not rdid:
                    continue
                ecu_type = classify_ecu(ecu)
                if ecu_type is None:
                    ignored_ecus.add(ecu or "(sin identificar)")
                    continue
                change = Change(
                    number=number,
                    ecu=ecu_type,
                    change_type=change_type,
                    rdid=rdid,
                    problem=problem,
                    impact=impact,
                    solution=solution,
                    project=project,
                    function_id=function_id or "---",
                    homologation=homologation,
                    un_r=un_r,
                )
                # Un mismo RDID puede existir en BCM y en Gateway.
                key = (project, ecu_type, rdid)
                if key in seen:
                    if seen[key] != change:
                        raise ValueError(
                            f"El correo contiene datos distintos para RDID {rdid} "
                            f"del proyecto {project} y ECU {ecu_type}. "
                            "Revisa las filas duplicadas."
                        )
                    continue
                seen[key] = change
                changes.append(change)

    if not changes:
        raise ValueError(
            "No se han encontrado cambios de BCM/0009 ni Gateway/GW/0019 "
            "en las tablas tecnicas del EML."
        )
    return EmailData(
        subject=subject, pv=pv, vr=vr, changes=changes,
        ignored_ecus=tuple(sorted(ignored_ecus)),
    )


# -----------------------------------------------------------------------------
# Localizacion de hojas y tablas
# -----------------------------------------------------------------------------
def find_project_sheet(workbook, pv: str, project: str):
    pv_upper = normalize_pv(pv)
    cfg = PROJECTS[project]
    candidates = []
    for ws in workbook.worksheets:
        normalized = ws.title.upper().replace(" ", "")
        # PV9 no debe coincidir por accidente con PV90 o PV9.1.
        pv_matches = re.search(rf"(?<![A-Z0-9.]){re.escape(pv_upper)}(?![0-9.])", normalized)
        project_matches = any(
            re.search(rf"(?<![A-Z0-9]){re.escape(token.upper())}(?![A-Z0-9])", normalized)
            for token in cfg["sheet_tokens"]
        )
        if pv_matches and project_matches:
            candidates.append(ws)
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise ValueError(f"No se ha encontrado una hoja para {pv} / {project} - {cfg['model']}.")
    raise ValueError(f"Hay varias hojas posibles para {pv} / {project}: {', '.join(w.title for w in candidates)}")


def get_main_table(ws):
    tables = list(ws.tables.values())
    if not tables:
        raise ValueError(f"La hoja '{ws.title}' no contiene ninguna tabla de Excel.")
    for table in tables:
        min_col, min_row, max_col, max_row = range_boundaries(table.ref)
        if min_col == 1 and min_row == 1 and max_col >= 13:
            return table
    raise ValueError(
        f"La hoja '{ws.title}' tiene tablas, pero ninguna comienza en A1 "
        "y contiene las 13 columnas esperadas. No se modificara por seguridad."
    )


def copy_row_style(ws, source_row: int, target_row: int, max_col: int) -> None:
    if source_row == 1:
        return  # No copiar cabeceras sobre la primera fila de datos.
    ws.row_dimensions[target_row].height = ws.row_dimensions[source_row].height
    for col in range(1, max_col + 1):
        src = ws.cell(source_row, col)
        dst = ws.cell(target_row, col)
        dst._style = copy.copy(src._style)


def structural_risks(ws) -> list[str]:
    issues = []
    if len(ws.tables) > 1:
        issues.append("otras tablas de Excel")
    if ws._charts or ws._images:
        issues.append("graficos/imagenes")
    if ws.merged_cells.ranges:
        issues.append("celdas combinadas")
    if ws.conditional_formatting or ws.data_validations.dataValidation:
        issues.append("rangos de validacion o formato condicional")
    if any(cell.data_type == "f" for cell in ws._cells.values()):
        issues.append("formulas")
    return issues


def extend_table_with_new_row(ws, table, allow_risky_insertions: bool = False) -> int:
    min_col, min_row, max_col, max_row = range_boundaries(table.ref)
    new_row = max_row + 1
    # Si la fila siguiente ya esta libre, ampliamos sin desplazar formulas ni rangos.
    has_content = any(ws.cell(new_row, col).value is not None for col in range(1, ws.max_column + 1))
    if has_content:
        issues = structural_risks(ws)
        if issues and not allow_risky_insertions:
            raise ValueError(
                "INSERT_RISK: Hay contenido debajo de la tabla y su desplazamiento "
                f"puede afectar a {', '.join(issues)} en '{ws.title}'."
            )
        ws.insert_rows(new_row, 1)
    copy_row_style(ws, max_row, new_row, max_col)
    new_ref = f"{get_column_letter(min_col)}{min_row}:{get_column_letter(max_col)}{new_row}"
    table.ref = new_ref
    if table.autoFilter is not None:
        table.autoFilter.ref = new_ref
    return new_row


def find_existing_row(ws, table, vr: str, rdid: str) -> int | None:
    _, min_row, _, max_row = range_boundaries(table.ref)
    for row in range(min_row + 1, max_row + 1):
        if normalize_vr(ws.cell(row, EXCEL_COLUMNS["vr"]).value) == normalize_vr(vr) and normalize_rdid(ws.cell(row, EXCEL_COLUMNS["rdid"]).value) == normalize_rdid(rdid):
            return row
    return None


def index_change_rows(ws, table) -> dict[tuple[str, str], int]:
    _, min_row, _, max_row = range_boundaries(table.ref)
    index = {}
    for row in range(min_row + 1, max_row + 1):
        vr = normalize_vr(ws.cell(row, EXCEL_COLUMNS["vr"]).value)
        rdid = normalize_rdid(ws.cell(row, EXCEL_COLUMNS["rdid"]).value)
        if not vr or not rdid:
            continue
        key = (vr, rdid)
        if key in index:
            raise ValueError(
                f"{ws.title}: VR{vr} / RDID {rdid} duplicados "
                f"en las filas {index[key]} y {row}."
            )
        index[key] = row
    return index


def save_workbook_in_place(workbook, source: str | Path) -> tuple[Path, Path]:
    """Valida el archivo y crea un backup antes de sustituirlo atomicamente."""
    source = Path(source).resolve()
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError("Selecciona un archivo .xlsx o .xlsm.")
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{source.stem}_tmp_", suffix=source.suffix, dir=source.parent
    )
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        workbook.save(temp_path)
        with ZipFile(temp_path) as archive:
            if archive.testzip() is not None:
                raise ValueError("La comprobacion de integridad del Excel ha fallado.")
            if source.suffix.lower() == ".xlsm":
                with ZipFile(source) as original:
                    vba_parts = [n for n in original.namelist() if n.lower().endswith("vbaproject.bin")]
                    for name in vba_parts:
                        if name not in archive.namelist() or original.read(name) != archive.read(name):
                            raise ValueError("No se ha conservado intacto el proyecto VBA del Excel.")
        verification = load_workbook(
            temp_path, read_only=True, keep_vba=source.suffix.lower() == ".xlsm"
        )
        try:
            if verification.sheetnames != workbook.sheetnames:
                raise ValueError("No se han conservado todas las hojas al guardar.")
        finally:
            verification.close()
        backup = source.with_name(
            f"{source.stem}_backup_{datetime.now():%Y%m%d_%H%M%S}_{uuid4().hex[:6]}{source.suffix}"
        )
        shutil.copy2(source, backup)
        os.replace(temp_path, source)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise
    return source, backup


# -----------------------------------------------------------------------------
# Escritura de cambios y asignacion posterior del ZDC
# -----------------------------------------------------------------------------
def import_changes_to_excel(
    eml_path: str, excel_path: str, selected_pv: str = "",
    allow_risky_insertions: bool = False,
    email_data: EmailData | None = None,
    ecu_type: str = "BCM",
) -> tuple[Path, dict]:
    data = email_data if email_data is not None else read_eml(eml_path)
    selected_changes = changes_for_ecu(data, ecu_type)
    pv_raw = selected_pv.strip() or data.pv
    if not pv_raw:
        raise ValueError("No se ha podido detectar la PV. Indicala manualmente.")
    pv = normalize_pv(pv_raw)
    if not data.vr:
        raise ValueError("No se ha podido detectar la VR del correo.")

    workbook = load_workbook(excel_path, keep_vba=Path(excel_path).suffix.lower() == ".xlsm")
    stats = {"new": 0, "updated": 0, "projects": {}, "backup": None, "ecu": ecu_type}

    for project in PROJECTS:
        project_changes = [
            change for change in selected_changes if change.project == project
        ]
        if not project_changes:
            continue
        ws = find_project_sheet(workbook, pv, project)
        table = get_main_table(ws)
        rows_index = index_change_rows(ws, table)
        pstats = {"new": 0, "updated": 0, "sheet": ws.title}

        for change in project_changes:
            key = (normalize_vr(data.vr), normalize_rdid(change.rdid))
            row = rows_index.get(key)
            was_existing = row is not None
            if row is None:
                row = extend_table_with_new_row(ws, table, allow_risky_insertions)
                rows_index[key] = row
                pstats["new"] += 1
                stats["new"] += 1
                # El ZDC todavia no se conoce: se deja vacio deliberadamente.
                ws.cell(row, EXCEL_COLUMNS["zdc"]).value = None
                set_text_cell(ws, row, EXCEL_COLUMNS["rdid"], change.rdid)
                ws.cell(row, EXCEL_COLUMNS["vr"]).value = int(data.vr) if data.vr.isdigit() else data.vr
                ws.cell(row, EXCEL_COLUMNS["zdc_created"]).value = None
                ws.cell(row, EXCEL_COLUMNS["zdc_released"]).value = None
                ws.cell(row, EXCEL_COLUMNS["change_ok"]).value = None
                ws.cell(row, EXCEL_COLUMNS["requester"]).value = None

            # Nunca se toca A en la importacion si ya contiene un ZDC.
            modified = False
            for col, value in (
                (EXCEL_COLUMNS["email_subject"], data.subject),
                (EXCEL_COLUMNS["problem"], change.problem),
                (EXCEL_COLUMNS["impact"], change.impact),
                (EXCEL_COLUMNS["solution"], change.solution),
                (EXCEL_COLUMNS["function_id"], change.function_id),
                (EXCEL_COLUMNS["homologation"], change.homologation),
            ):
                modified = set_text_cell(ws, row, col, value) or modified
            if was_existing and modified:
                pstats["updated"] += 1
                stats["updated"] += 1
            ws.cell(row, EXCEL_COLUMNS["rdid"]).number_format = "@"
            ws.cell(row, EXCEL_COLUMNS["function_id"]).number_format = "@"

        stats["projects"][project] = pstats

    if stats["new"] == 0 and stats["updated"] == 0:
        return Path(excel_path).resolve(), stats
    output, backup = save_workbook_in_place(workbook, excel_path)
    stats["backup"] = backup
    return output, stats


def assign_zdc_to_excel(
    excel_path: str, pv: str, model: str, vr: str, zdc_name: str,
    allow_overwrite: bool = False,
) -> tuple[Path, int, str, Path | None]:
    pv = normalize_pv(pv)
    vr = normalize_vr(vr)
    zdc_name = clean_text(zdc_name)
    if model not in MODEL_TO_PROJECT:
        raise ValueError("Selecciona un modelo valido.")
    if not pv or not vr or not zdc_name:
        raise ValueError("PV, modelo, VR y nombre del ZDC son obligatorios.")
    if not vr.isdigit():
        raise ValueError("La VR debe ser un numero entero, por ejemplo 42.")

    project = MODEL_TO_PROJECT[model]
    workbook = load_workbook(excel_path, keep_vba=Path(excel_path).suffix.lower() == ".xlsm")
    ws = find_project_sheet(workbook, pv, project)
    table = get_main_table(ws)
    _, min_row, _, max_row = range_boundaries(table.ref)

    modified = 0
    matches = 0
    conflicts = []
    for row in range(min_row + 1, max_row + 1):
        row_vr = normalize_vr(ws.cell(row, EXCEL_COLUMNS["vr"]).value)
        rdid = normalize_rdid(ws.cell(row, EXCEL_COLUMNS["rdid"]).value)
        if row_vr == vr and rdid:
            matches += 1
            old_zdc = clean_text(ws.cell(row, EXCEL_COLUMNS["zdc"]).value)
            if old_zdc and old_zdc != zdc_name:
                conflicts.append(row)
            if old_zdc != zdc_name or ws.cell(row, EXCEL_COLUMNS["zdc"]).data_type == "f":
                set_text_cell(ws, row, EXCEL_COLUMNS["zdc"], zdc_name)
                modified += 1

    if conflicts and not allow_overwrite:
        raise ValueError(
            f"ZDC_OVERWRITE: Hay {len(conflicts)} filas que ya tienen otro ZDC "
            f"en '{ws.title}' (filas {', '.join(map(str, conflicts[:10]))})."
        )
    if matches == 0:
        raise ValueError(f"No existen filas con VR{vr} en la hoja '{ws.title}'.")
    if modified == 0:
        return Path(excel_path).resolve(), 0, ws.title, None

    output, backup = save_workbook_in_place(workbook, excel_path)
    return output, modified, ws.title, backup


# -----------------------------------------------------------------------------
# Interfaz grafica
# -----------------------------------------------------------------------------
class BCMChangeApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BCM / Gateway - Importador de cambios ZDC desde EML")
        self.geometry("980x700")
        self.minsize(900, 620)

        self.eml_path = tk.StringVar()
        self.excel_path = tk.StringVar()
        self.detected_pv = tk.StringVar(value="")
        self.assign_pv = tk.StringVar(value="PV9")
        self.assign_model = tk.StringVar(value="Formentor")
        self.assign_vr = tk.StringVar(value="42")
        self.assign_zdc = tk.StringVar()
        self.status = tk.StringVar(value="Selecciona un EML y el Excel de control. El Excel se modificara directamente.")
        self.last_email_data: EmailData | None = None

        self._build_ui()

    def _build_ui(self):
        # El panel de la ventana unificada reutiliza este método sin llamar a
        # BCMChangeApp.__init__; por eso inicializamos aquí el nuevo selector.
        if not hasattr(self, "ecu_type"):
            self.ecu_type = tk.StringVar(master=self, value="BCM")

        root = ttk.Frame(self, padding=14)
        root.pack(fill="both", expand=True)

        files = ttk.LabelFrame(root, text="1. Archivos", padding=10)
        files.pack(fill="x")
        ttk.Label(files, text="ECU destino:").grid(row=0, column=0, sticky="w", pady=3)
        ecu_box = ttk.Combobox(
            files, textvariable=self.ecu_type, values=ECU_TYPES,
            state="readonly", width=15,
        )
        ecu_box.grid(row=0, column=1, sticky="w", padx=7, pady=3)
        ecu_box.bind(
            "<<ComboboxSelected>>",
            lambda _event: self.analyze() if self.eml_path.get()
            else self.status.set(f"Selecciona el EML y el Excel de {self.ecu_type.get()}."),
        )
        self._file_row(files, 1, "Correo EML:", self.eml_path, self.choose_eml)
        self._file_row(files, 2, "Excel XLSM:", self.excel_path, self.choose_excel)
        ttk.Label(
            files,
            text="Selecciona el Excel de la ECU elegida; BCM y Gateway usan archivos distintos.",
        ).grid(row=3, column=0, columnspan=3, sticky="w", pady=(7, 0))

        detect = ttk.LabelFrame(root, text="2. Detectar e importar cambios", padding=10)
        detect.pack(fill="x", pady=(10, 0))
        ttk.Label(detect, text="PV:").grid(row=0, column=0, sticky="w")
        ttk.Entry(detect, textvariable=self.detected_pv, width=12).grid(row=0, column=1, padx=(6, 16), sticky="w")
        ttk.Button(detect, text="Analizar EML", command=self.analyze).grid(row=0, column=2, padx=4)
        ttk.Button(detect, text="Importar y modificar Excel", command=self.import_changes).grid(row=0, column=3, padx=4)
        ttk.Label(detect, text="Al importar, ZDC Afectado queda vacio si aun no se conoce.").grid(row=1, column=0, columnspan=4, pady=(8, 0), sticky="w")
        ttk.Label(detect, text="IMPORTANTE: el archivo XLSM seleccionado se modifica directamente.", foreground="#9a4d00").grid(row=2, column=0, columnspan=4, pady=(4, 0), sticky="w")

        assign = ttk.LabelFrame(root, text="3. Asignar nombre de ZDC cuando ya este disponible", padding=10)
        assign.pack(fill="x", pady=(10, 0))
        ttk.Label(assign, text="PV:").grid(row=0, column=0, sticky="w")
        ttk.Entry(assign, textvariable=self.assign_pv, width=10).grid(row=0, column=1, padx=(5, 12))
        ttk.Label(assign, text="Modelo:").grid(row=0, column=2, sticky="w")
        ttk.Combobox(assign, textvariable=self.assign_model, values=list(MODEL_TO_PROJECT), state="readonly", width=14).grid(row=0, column=3, padx=(5, 12))
        ttk.Label(assign, text="VR:").grid(row=0, column=4, sticky="w")
        ttk.Entry(assign, textvariable=self.assign_vr, width=8).grid(row=0, column=5, padx=(5, 12))
        ttk.Label(assign, text="ZDC:").grid(row=0, column=6, sticky="w")
        ttk.Entry(assign, textvariable=self.assign_zdc, width=25).grid(row=0, column=7, padx=(5, 12))
        ttk.Button(assign, text="Asignar ZDC", command=self.assign_zdc_action).grid(row=0, column=8)
        ttk.Label(assign, text="Este boton modifica el Excel seleccionado y actualiza la columna A de las filas del modelo y VR seleccionados.").grid(row=1, column=0, columnspan=9, pady=(8, 0), sticky="w")

        preview_frame = ttk.LabelFrame(root, text="Vista previa tecnica (sin remitentes, destinatarios, CC ni firmas)", padding=8)
        preview_frame.pack(fill="both", expand=True, pady=(10, 0))
        self.preview = tk.Text(preview_frame, wrap="word", height=20)
        scroll = ttk.Scrollbar(preview_frame, orient="vertical", command=self.preview.yview)
        self.preview.configure(yscrollcommand=scroll.set)
        self.preview.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        ttk.Label(root, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x", pady=(10, 0))

    def _file_row(self, parent, row, label, variable, command):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=7, pady=3)
        ttk.Button(parent, text="Seleccionar...", command=command).grid(row=row, column=2, pady=3)
        parent.columnconfigure(1, weight=1)

    def choose_eml(self):
        path = filedialog.askopenfilename(filetypes=[("Correo EML", "*.eml"), ("Todos", "*.*")])
        if path:
            self.eml_path.set(path)
            self.detected_pv.set("")
            self.last_email_data = None

    def choose_excel(self):
        path = filedialog.askopenfilename(filetypes=[("Excel con macros", "*.xlsm"), ("Excel", "*.xlsx"), ("Todos", "*.*")])
        if path:
            self.excel_path.set(path)

    def analyze(self):
        try:
            if not self.eml_path.get():
                raise ValueError("Selecciona primero un archivo EML.")
            data = read_eml(self.eml_path.get())
            selected_changes = changes_for_ecu(data, self.ecu_type.get())
            self.last_email_data = data
            self.detected_pv.set(data.pv)
            if data.pv:
                self.assign_pv.set(data.pv)
            if data.vr:
                self.assign_vr.set(data.vr)

            counts = {project: 0 for project in PROJECTS}
            for change in selected_changes:
                counts[change.project] += 1

            lines = [
                f"ECU seleccionada: {self.ecu_type.get()}",
                f"PV detectada: {data.pv or 'No detectada'}",
                f"VR detectada: VR{data.vr or '?'}",
                f"Cambios de {self.ecu_type.get()} detectados: {len(selected_changes)}",
                "Cambios identificados en el EML: "
                + " | ".join(
                    f"{ecu}: {sum(c.ecu == ecu for c in data.changes)}"
                    for ecu in ECU_TYPES
                ),
                "",
            ]
            if data.ignored_ecus:
                lines.extend([
                    "Otros identificadores ECU ignorados: " + ", ".join(data.ignored_ecus),
                    "",
                ])
            for project, count in counts.items():
                if count:
                    lines.append(f"{project} - {PROJECTS[project]['model']}: {count} cambios")
            lines.extend(["", "Primeros cambios:"])
            for change in selected_changes[:15]:
                lines.append(f"- {change.project} | RDID {change.rdid} | {change.problem}")
            if len(selected_changes) > 15:
                lines.append(f"... y {len(selected_changes) - 15} cambios mas.")

            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", "\n".join(lines))
            self.status.set(f"EML analizado correctamente para {self.ecu_type.get()}.")
        except Exception as exc:
            self.show_error(exc)

    def import_changes(self):
        try:
            if not self.eml_path.get() or not self.excel_path.get():
                raise ValueError("Selecciona el EML y el Excel.")
            data = read_eml(self.eml_path.get())
            ecu_type = self.ecu_type.get()
            selected_changes = changes_for_ecu(data, ecu_type)
            supplied_pv = self.detected_pv.get().strip()
            if supplied_pv and data.pv and normalize_pv(supplied_pv) != data.pv:
                if not messagebox.askyesno(
                    "PV diferente",
                    f"El correo indica {data.pv}, pero has seleccionado {supplied_pv}. "
                    "¿Quieres importar en la PV indicada manualmente?",
                ):
                    return
            if not supplied_pv and not data.pv:
                raise ValueError("No se detecta la PV. Escribela antes de importar.")
            if not messagebox.askyesno(
                "Confirmar ECU y Excel",
                f"Se importaran {len(selected_changes)} cambios de {ecu_type} en:\n"
                f"{self.excel_path.get()}\n\n"
                f"¿Confirmas que este es el Excel de {ecu_type}?",
            ):
                return
            try:
                output, stats = import_changes_to_excel(
                    self.eml_path.get(), self.excel_path.get(), supplied_pv,
                    email_data=data, ecu_type=ecu_type,
                )
            except ValueError as exc:
                if not str(exc).startswith("INSERT_RISK:"):
                    raise
                if not messagebox.askyesno(
                    "Riesgo al desplazar filas",
                    f"{str(exc).removeprefix('INSERT_RISK:').strip()}\n\n"
                    "Se guardara un backup, pero deberas revisar las referencias "
                    "de Excel. ¿Quieres continuar?",
                ):
                    return
                output, stats = import_changes_to_excel(
                    self.eml_path.get(), self.excel_path.get(), supplied_pv,
                    allow_risky_insertions=True,
                    email_data=data, ecu_type=ecu_type,
                )
            lines = [
                f"Importacion de {ecu_type} completada.",
                f"Filas nuevas: {stats['new']}",
                f"Filas existentes actualizadas: {stats['updated']}",
                "",
            ]
            for project, pstats in stats["projects"].items():
                lines.append(f"{project} | {pstats['sheet']} | nuevas {pstats['new']} | actualizadas {pstats['updated']}")
            lines.append(f"\nExcel modificado:\n{output}")
            if stats["backup"]:
                lines.append(f"\nCopia de seguridad:\n{stats['backup']}")
            else:
                lines.append("\nNo ha habido cambios en el archivo.")
            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", "\n".join(lines))
            self.status.set(f"Modificado: {output.name}")
            messagebox.showinfo("Proceso completado", f"Excel modificado correctamente:\n{output}")
        except Exception as exc:
            self.show_error(exc)

    def assign_zdc_action(self):
        try:
            if not self.excel_path.get():
                raise ValueError("Selecciona el Excel que deseas actualizar.")
            if not messagebox.askyesno(
                "Confirmar ECU y Excel",
                f"Se asignara un ZDC a las filas de la VR elegida en:\n"
                f"{self.excel_path.get()}\n\n"
                f"¿Confirmas que este es el Excel de {self.ecu_type.get()}?",
            ):
                return
            try:
                output, modified, sheet, backup = assign_zdc_to_excel(
                    self.excel_path.get(), self.assign_pv.get(), self.assign_model.get(),
                    self.assign_vr.get(), self.assign_zdc.get(),
                )
            except ValueError as exc:
                if not str(exc).startswith("ZDC_OVERWRITE:"):
                    raise
                if not messagebox.askyesno(
                    "Reemplazar ZDC existente",
                    f"{str(exc).removeprefix('ZDC_OVERWRITE:').strip()}\n\n"
                    "¿Quieres sustituir esos ZDC por el nuevo valor?",
                ):
                    return
                output, modified, sheet, backup = assign_zdc_to_excel(
                    self.excel_path.get(), self.assign_pv.get(), self.assign_model.get(),
                    self.assign_vr.get(), self.assign_zdc.get(), allow_overwrite=True,
                )
            text = (
                f"ZDC asignado correctamente.\n\n"
                f"Hoja: {sheet}\n"
                f"Filas modificadas: {modified}\n"
                f"ZDC: {self.assign_zdc.get()}\n\n"
                f"Excel modificado:\n{output}\n\n"
                f"Copia de seguridad: {backup if backup else 'No necesaria (sin cambios)'}"
            )
            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", text)
            self.status.set(f"Modificado: {output.name}")
            messagebox.showinfo("ZDC asignado", text)
        except Exception as exc:
            self.show_error(exc)

    def show_error(self, exc: Exception):
        self.status.set(f"Error: {exc}")
        messagebox.showerror("Error", f"{exc}\n\nDetalles tecnicos:\n{traceback.format_exc(limit=3)}")


if __name__ == "__main__":
    BCMChangeApp().mainloop()
